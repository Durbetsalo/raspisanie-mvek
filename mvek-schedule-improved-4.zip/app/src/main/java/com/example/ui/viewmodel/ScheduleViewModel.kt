package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppThemeMode
import com.example.data.local.PreferencesManager
import com.example.data.model.Group
import com.example.data.model.WeekSchedule
import com.example.data.repository.ScheduleRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

sealed interface ScheduleUiState {
    data object Loading : ScheduleUiState

    /**
     * @param isOffline обновить с сервера не удалось — показаны сохранённые данные
     * @param lastUpdatedMillis когда показанное расписание последний раз сверялось с сервером
     */
    data class Success(
        val schedule: WeekSchedule,
        val isRefreshing: Boolean = false,
        val isOffline: Boolean = false,
        val lastUpdatedMillis: Long? = null
    ) : ScheduleUiState

    data class Error(val message: String) : ScheduleUiState
}

data class GroupsUiState(
    val groups: List<Group> = emptyList(),
    val isLoading: Boolean = false
)

class ScheduleViewModel(
    private val repository: ScheduleRepository,
    private val prefs: PreferencesManager,
    // Вызывается, когда расписание, группа или тема изменились (обновляет виджеты)
    private val onScheduleChanged: () -> Unit = {}
) : ViewModel() {

    val selectedGroup: StateFlow<String?> = prefs.selectedGroup
    val recentGroups: StateFlow<List<String>> = prefs.recentGroups
    val themeMode: StateFlow<AppThemeMode> = prefs.themeMode

    // Only 0 = Эта неделя, 1 = Следующая неделя
    private val _selectedWeekIndex = MutableStateFlow(0)
    val selectedWeekIndex: StateFlow<Int> = _selectedWeekIndex.asStateFlow()

    private val _selectedDayIndex = MutableStateFlow(getCurrentDayOfWeekIndex())
    val selectedDayIndex: StateFlow<Int> = _selectedDayIndex.asStateFlow()

    private val _currentTimeMinutes = MutableStateFlow(calculateCurrentMinutes())
    val currentTimeMinutes: StateFlow<Int> = _currentTimeMinutes.asStateFlow()

    private val _scheduleUiState = MutableStateFlow<ScheduleUiState>(ScheduleUiState.Loading)
    val scheduleUiState: StateFlow<ScheduleUiState> = _scheduleUiState.asStateFlow()

    private val _groupsUiState = MutableStateFlow(
        GroupsUiState(groups = repository.getInstantGroups(), isLoading = false)
    )
    val groupsUiState: StateFlow<GroupsUiState> = _groupsUiState.asStateFlow()

    // Tracks which "group_skip" keys were already refreshed from network in this session
    private val syncedInSession = mutableSetOf<String>()
    // Когда каждая неделя последний раз успешно сверялась с сервером (для автообновления при возврате в приложение)
    private val lastSyncAt = mutableMapOf<String, Long>()
    private var groupsLoadedFromNetwork = false
    private var userSelectedDayManually = false
    private var lastDayKey = currentDayKey()
    private var activeLoadJob: Job? = null
    private var prefetchJob: Job? = null

    init {
        // Strip legacy SharedPreferences HTML blobs off the main thread
        viewModelScope.launch {
            repository.clearLegacyCacheIfNeeded()
        }

        // Тикер по границе минуты: статус пары («идёт», «следующая») меняется ровно в :00,
        // а не с задержкой до минуты, как при delay(60_000) от момента запуска.
        viewModelScope.launch {
            while (true) {
                delay(MINUTE_MS - System.currentTimeMillis() % MINUTE_MS + 50)
                syncClock()
            }
        }

        // Load only the selected group's schedule for this week (skip = 0)
        selectedGroup.value?.let { grp ->
            loadSchedule(grp, skip = 0, forceRefresh = false)
        }
    }

    private fun calculateCurrentMinutes(): Int {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    private fun currentDayKey(now: Calendar = Calendar.getInstance()): Int =
        now.get(Calendar.YEAR) * 1000 + now.get(Calendar.DAY_OF_YEAR)

    private fun getCurrentDayOfWeekIndex(): Int {
        val cal = Calendar.getInstance()
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            else -> 0
        }
    }

    /** Обновляет текущее время и, если наступил новый день, флаги «сегодня» и выбранный день. */
    private fun syncClock() {
        val now = Calendar.getInstance()
        _currentTimeMinutes.value = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        val dayKey = currentDayKey(now)
        if (dayKey != lastDayKey) {
            lastDayKey = dayKey
            userSelectedDayManually = false
            val state = _scheduleUiState.value
            if (state is ScheduleUiState.Success) {
                val week = _selectedWeekIndex.value
                val fixed = state.schedule.withAccurateTodayFlags(week, now)
                _scheduleUiState.value = state.copy(schedule = fixed)
                autoSelectBestDay(fixed, week)
            }
        }
    }

    /**
     * Вызывается, когда приложение возвращается на передний план. Delay в корутинах не идёт,
     * пока устройство спит, поэтому время и «сегодня» нужно пересчитать явно, а расписание —
     * обновить, если оно не сверялось с сервером дольше [STALE_AFTER_MS].
     */
    fun onAppForeground() {
        syncClock()
        val grp = selectedGroup.value ?: return
        if (activeLoadJob?.isActive == true) return
        val week = _selectedWeekIndex.value
        val last = lastSyncAt["${grp}_$week"]
        if (last == null || System.currentTimeMillis() - last > STALE_AFTER_MS) {
            loadSchedule(grp, week, forceRefresh = true)
        }
    }

    fun selectGroup(group: String) {
        prefs.setSelectedGroup(group)
        userSelectedDayManually = false
        _selectedWeekIndex.value = 0
        loadSchedule(group, skip = 0, forceRefresh = true)
        onScheduleChanged()
    }

    fun selectWeek(weekIndex: Int) {
        val clamped = weekIndex.coerceIn(0, 1)
        if (clamped == _selectedWeekIndex.value && _scheduleUiState.value is ScheduleUiState.Success) {
            return
        }
        userSelectedDayManually = false
        _selectedWeekIndex.value = clamped
        selectedGroup.value?.let { grp ->
            loadSchedule(grp, skip = clamped, forceRefresh = false)
        }
    }

    fun selectDay(index: Int) {
        userSelectedDayManually = true
        _selectedDayIndex.value = index
    }

    /** Возврат к сегодняшнему дню текущей недели. */
    fun goToToday() {
        userSelectedDayManually = false
        if (_selectedWeekIndex.value != 0) {
            selectWeek(0)
            return
        }
        val state = _scheduleUiState.value as? ScheduleUiState.Success ?: return
        val todayIdx = state.schedule.days.indexOfFirst { it.isToday }
        if (todayIdx != -1) {
            _selectedDayIndex.value = todayIdx
        } else {
            autoSelectBestDay(state.schedule, 0)
        }
    }

    fun refreshSchedule() {
        selectedGroup.value?.let { grp ->
            loadSchedule(grp, skip = _selectedWeekIndex.value, forceRefresh = true)
        }
    }

    fun loadSchedule(group: String, skip: Int, forceRefresh: Boolean = false) {
        val safeSkip = skip.coerceIn(0, 1)
        val sessionKey = "${group}_$safeSkip"

        // 1. Instant RAM hit
        val memSchedule = repository.getMemorySchedule(group, safeSkip)?.withAccurateTodayFlags(safeSkip)
        if (memSchedule != null && !forceRefresh && syncedInSession.contains(sessionKey)) {
            _scheduleUiState.value = ScheduleUiState.Success(
                schedule = memSchedule,
                lastUpdatedMillis = lastSyncAt[sessionKey]
            )
            if (!userSelectedDayManually) autoSelectBestDay(memSchedule, safeSkip)
            if (safeSkip == 0) prefetchNextWeek(group)
            return
        }

        activeLoadJob?.cancel()
        activeLoadJob = viewModelScope.launch {
            // 2. If not in RAM, check disk file cache (<10ms on IO)
            val cached: WeekSchedule? = memSchedule
                ?: repository.getDiskSchedule(group, safeSkip)?.withAccurateTodayFlags(safeSkip)

            if (cached != null) {
                val shouldRefresh = forceRefresh || !syncedInSession.contains(sessionKey)
                _scheduleUiState.value = ScheduleUiState.Success(
                    schedule = cached,
                    isRefreshing = shouldRefresh,
                    lastUpdatedMillis = repository.lastSyncMillis(group, safeSkip)
                )
                if (!userSelectedDayManually) autoSelectBestDay(cached, safeSkip)
                if (!shouldRefresh) {
                    if (safeSkip == 0) prefetchNextWeek(group)
                    return@launch
                }
            } else {
                _scheduleUiState.value = ScheduleUiState.Loading
            }

            // 3. Fetch fresh schedule from network without blanking existing screen
            val result = repository.fetchGroupScheduleFromNetwork(group, safeSkip)
            if (_selectedWeekIndex.value != safeSkip || selectedGroup.value != group) return@launch

            val fetched = result.getOrNull()
            if (fetched != null) {
                val fresh = fetched.schedule.withAccurateTodayFlags(safeSkip)
                if (fetched.isFresh) {
                    syncedInSession.add(sessionKey)
                    lastSyncAt[sessionKey] = fetched.syncedAtMillis ?: System.currentTimeMillis()
                    onScheduleChanged()
                }
                val changed = cached == null || fresh != cached
                _scheduleUiState.value = ScheduleUiState.Success(
                    schedule = fresh,
                    isRefreshing = false,
                    // Сеть не помогла: пользователь должен видеть, что расписание может быть устаревшим
                    isOffline = !fetched.isFresh,
                    lastUpdatedMillis = fetched.syncedAtMillis
                )
                if (changed && !userSelectedDayManually) autoSelectBestDay(fresh, safeSkip)
                if (safeSkip == 0 && fetched.isFresh) prefetchNextWeek(group)
            } else {
                // Нет ни сети, ни сохранённых данных. Раньше здесь показывалось выдуманное
                // «демо-расписание», которое студент мог принять за настоящее — теперь честная ошибка.
                _scheduleUiState.value = ScheduleUiState.Error(
                    result.exceptionOrNull()?.message ?: "Не удалось загрузить расписание"
                )
            }
        }
    }

    private fun prefetchNextWeek(group: String) {
        val nextKey = "${group}_1"
        if (syncedInSession.contains(nextKey) && repository.getMemorySchedule(group, 1) != null) return
        prefetchJob?.cancel()
        prefetchJob = viewModelScope.launch {
            delay(500)
            val fetched = repository.fetchGroupScheduleFromNetwork(group, 1).getOrNull()
            if (fetched != null && fetched.isFresh) {
                syncedInSession.add(nextKey)
                lastSyncAt[nextKey] = fetched.syncedAtMillis ?: System.currentTimeMillis()
                onScheduleChanged()
            }
        }
    }

    private fun autoSelectBestDay(schedule: WeekSchedule, skip: Int) {
        if (skip == 1) {
            // For next week, start at the first day with lessons (usually Monday)
            val firstWithLessons = schedule.days.indexOfFirst { it.lessons.isNotEmpty() }
            _selectedDayIndex.value = if (firstWithLessons != -1) firstWithLessons else 0
            return
        }

        val todayIdx = getCurrentDayOfWeekIndex()
        if (todayIdx in schedule.days.indices && schedule.days[todayIdx].lessons.isNotEmpty()) {
            _selectedDayIndex.value = todayIdx
            return
        }
        for (i in todayIdx until schedule.days.size) {
            if (schedule.days[i].lessons.isNotEmpty()) {
                _selectedDayIndex.value = i
                return
            }
        }
        val firstWithLessons = schedule.days.indexOfFirst { it.lessons.isNotEmpty() }
        if (firstWithLessons != -1) {
            _selectedDayIndex.value = firstWithLessons
        }
    }

    fun selectNearestStudyDay() {
        val state = _scheduleUiState.value
        if (state is ScheduleUiState.Success) {
            val days = state.schedule.days
            val todayIdx = getCurrentDayOfWeekIndex()
            for (i in (todayIdx + 1) until days.size) {
                if (days[i].lessons.isNotEmpty()) {
                    _selectedDayIndex.value = i
                    return
                }
            }
            val firstWithLessons = days.indexOfFirst { it.lessons.isNotEmpty() }
            if (firstWithLessons != -1) {
                _selectedDayIndex.value = firstWithLessons
            }
        }
    }

    fun loadGroupsIfNeeded(forceRefresh: Boolean = false) {
        if (groupsLoadedFromNetwork && !forceRefresh) return
        viewModelScope.launch {
            _groupsUiState.value = _groupsUiState.value.copy(isLoading = true)
            val result = repository.getGroups(forceRefresh)
            if (result.isSuccess) {
                groupsLoadedFromNetwork = true
                _groupsUiState.value = GroupsUiState(
                    groups = result.getOrThrow(),
                    isLoading = false
                )
            } else {
                _groupsUiState.value = _groupsUiState.value.copy(isLoading = false)
            }
        }
    }

    fun toggleTheme(currentlyDark: Boolean) {
        prefs.setThemeMode(if (currentlyDark) AppThemeMode.LIGHT else AppThemeMode.DARK)
        // Виджеты следуют теме приложения — перерисовываем сразу
        onScheduleChanged()
    }
}

private const val MINUTE_MS = 60_000L
private const val STALE_AFTER_MS = 15 * 60_000L

class ScheduleViewModelFactory(
    private val repository: ScheduleRepository,
    private val prefs: PreferencesManager,
    private val onScheduleChanged: () -> Unit = {}
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ScheduleViewModel::class.java)) {
            return ScheduleViewModel(repository, prefs, onScheduleChanged) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

private val DATE_DD_MM_REGEX = Regex("""^\d{2}\.\d{2}$""")

fun WeekSchedule.withAccurateTodayFlags(
    skip: Int,
    now: Calendar = Calendar.getInstance()
): WeekSchedule {
    val isSunday = now.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
    if (skip != 0 || isSunday) {
        return if (days.any { it.isToday }) {
            copy(days = days.map { if (it.isToday) it.copy(isToday = false) else it })
        } else {
            this
        }
    }

    val todayDateStr = String.format(
        Locale.US,
        "%02d.%02d",
        now.get(Calendar.DAY_OF_MONTH),
        now.get(Calendar.MONTH) + 1
    )
    val todayDowShort = when (now.get(Calendar.DAY_OF_WEEK)) {
        Calendar.MONDAY -> "Пн"
        Calendar.TUESDAY -> "Вт"
        Calendar.WEDNESDAY -> "Ср"
        Calendar.THURSDAY -> "Чт"
        Calendar.FRIDAY -> "Пт"
        Calendar.SATURDAY -> "Сб"
        else -> ""
    }

    val hasRealDates = days.any { DATE_DD_MM_REGEX.matches(it.dateString.trim()) }
    val updatedDays = days.map { day ->
        val shouldBeToday = if (hasRealDates) {
            day.dateString.trim() == todayDateStr
        } else {
            todayDowShort.isNotEmpty() && day.dayOfWeek.equals(todayDowShort, ignoreCase = true)
        }
        if (day.isToday != shouldBeToday) day.copy(isToday = shouldBeToday) else day
    }
    return if (updatedDays != days) copy(days = updatedDays) else this
}
