package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.update.UpdateInfo
import com.example.data.update.UpdateSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

sealed interface UpdateUiState {
    data object Idle : UpdateUiState
    data object Checking : UpdateUiState
    data class UpToDate(val version: String) : UpdateUiState
    data class Available(val info: UpdateInfo) : UpdateUiState

    /** [progress] от 0 до 1; -1 — размер файла неизвестен. */
    data class Downloading(val info: UpdateInfo, val progress: Float) : UpdateUiState
    data class ReadyToInstall(val info: UpdateInfo, val file: File) : UpdateUiState
    data class Error(val message: String) : UpdateUiState
}

class UpdateViewModel(
    private val source: UpdateSource,
    private val autoCheckDelayMs: Long = 3_000L,
    private val clock: () -> Long = { System.currentTimeMillis() }
) : ViewModel() {

    private val _state = MutableStateFlow<UpdateUiState>(UpdateUiState.Idle)
    val state: StateFlow<UpdateUiState> = _state.asStateFlow()

    /** Найденное обновление: остаётся, даже если пользователь закрыл окно, — для отметки в меню. */
    private val _pendingUpdate = MutableStateFlow<UpdateInfo?>(null)
    val pendingUpdate: StateFlow<UpdateInfo?> = _pendingUpdate.asStateFlow()

    val isConfigured: Boolean get() = source.isConfigured
    val currentVersion: String = source.currentVersionName()

    private var dismissedVersion: String? = null
    private var checkJob: Job? = null
    private var downloadJob: Job? = null

    init {
        // Остатки ранее скачанных обновлений не нужны
        viewModelScope.launch(Dispatchers.IO) { source.cleanup() }
    }

    /** Тихая проверка при запуске: не чаще раза в несколько часов, об ошибках не сообщает. */
    fun autoCheck() {
        if (!source.isConfigured) return
        if (_state.value != UpdateUiState.Idle) return
        if (checkJob?.isActive == true) return
        if (!source.shouldAutoCheck(clock())) return

        checkJob = viewModelScope.launch {
            // Сначала даём загрузиться расписанию
            delay(autoCheckDelayMs)
            val info = source.check().getOrNull()
            _pendingUpdate.value = info
            if (info != null && info.versionName != dismissedVersion && _state.value == UpdateUiState.Idle) {
                _state.value = UpdateUiState.Available(info)
            }
        }
    }

    /** Проверка по кнопке в меню: всегда показывает результат (в том числе «обновлений нет» и ошибки). */
    fun checkManually() {
        if (!source.isConfigured) {
            _state.value = UpdateUiState.Error(
                "Не указан репозиторий с обновлениями. Впишите его в UpdateConfig.kt (см. ОБНОВЛЕНИЯ.md)"
            )
            return
        }
        when (_state.value) {
            is UpdateUiState.Downloading, is UpdateUiState.ReadyToInstall -> return
            else -> Unit
        }
        // Обновление уже найдено — повторно в сеть ходить не нужно
        _pendingUpdate.value?.let { pending ->
            _state.value = UpdateUiState.Available(pending)
            return
        }
        checkJob?.cancel()
        _state.value = UpdateUiState.Checking
        checkJob = viewModelScope.launch {
            source.check().fold(
                onSuccess = { info ->
                    _pendingUpdate.value = info
                    _state.value = if (info != null) {
                        UpdateUiState.Available(info)
                    } else {
                        UpdateUiState.UpToDate(currentVersion)
                    }
                },
                onFailure = { e ->
                    _state.value = UpdateUiState.Error(e.message ?: "Не удалось проверить обновления")
                }
            )
        }
    }

    fun startDownload() {
        val info = (_state.value as? UpdateUiState.Available)?.info ?: return
        downloadJob?.cancel()
        _state.value = UpdateUiState.Downloading(info, 0f)
        downloadJob = viewModelScope.launch {
            var lastPercent = -1
            val result = source.download(info) { downloaded, total ->
                if (!isActive) return@download
                val progress = if (total > 0) (downloaded.toFloat() / total).coerceIn(0f, 1f) else -1f
                val percent = if (progress >= 0f) (progress * 100).toInt() else -1
                // Обновляем состояние только при изменении процента, а не на каждый буфер
                if (percent != lastPercent) {
                    lastPercent = percent
                    _state.value = UpdateUiState.Downloading(info, progress)
                }
            }
            result.fold(
                onSuccess = { file -> _state.value = UpdateUiState.ReadyToInstall(info, file) },
                onFailure = { e -> _state.value = UpdateUiState.Error(e.message ?: "Не удалось скачать обновление") }
            )
        }
    }

    fun cancelDownload() {
        downloadJob?.cancel()
        _state.value = UpdateUiState.Idle
    }

    /** «Позже» / «OK»: закрывает окно; эту версию автоматическая проверка больше не навязывает. */
    fun dismiss() {
        when (val s = _state.value) {
            is UpdateUiState.Available -> dismissedVersion = s.info.versionName
            is UpdateUiState.ReadyToInstall -> dismissedVersion = s.info.versionName
            else -> Unit
        }
        checkJob?.cancel()
        _state.value = UpdateUiState.Idle
    }
}

class UpdateViewModelFactory(private val source: UpdateSource) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UpdateViewModel::class.java)) {
            return UpdateViewModel(source) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
