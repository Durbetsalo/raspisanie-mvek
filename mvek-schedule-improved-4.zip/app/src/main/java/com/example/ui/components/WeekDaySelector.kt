package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DaySchedule
import com.example.ui.theme.StatusOngoing

private val DayItemShape = RoundedCornerShape(14.dp)

@Composable
fun WeekDaySelector(
    days: List<DaySchedule>,
    selectedIndex: Int,
    onDaySelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        days.forEachIndexed { index, day ->
            val isSelected = index == selectedIndex
            val hasLessons = day.lessons.isNotEmpty()
            val onDayClick = androidx.compose.runtime.remember(index, onDaySelected) {
                { onDaySelected(index) }
            }

            Surface(
                onClick = onDayClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("day_selector_$index"),
                shape = DayItemShape,
                color = when {
                    isSelected -> colorScheme.primary
                    day.isToday -> colorScheme.primaryContainer.copy(alpha = 0.5f)
                    else -> colorScheme.surfaceVariant.copy(alpha = 0.6f)
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = day.dayOfWeek,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = when {
                            isSelected -> Color.White
                            day.isToday -> colorScheme.primary
                            else -> colorScheme.onSurfaceVariant
                        }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = day.dateString.ifEmpty { "--" },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal,
                        color = if (isSelected) Color.White.copy(alpha = 0.85f) else colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(
                                color = when {
                                    !hasLessons -> Color.Transparent
                                    isSelected -> Color.White
                                    day.isToday -> StatusOngoing
                                    else -> colorScheme.primary.copy(alpha = 0.6f)
                                },
                                shape = CircleShape
                            )
                    )
                }
            }
        }
    }
}
