package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.example.data.update.ApkInstaller
import com.example.data.update.UpdateFormat
import com.example.ui.viewmodel.UpdateUiState

/** Окно обновления приложения: проверка → «Доступна версия» → загрузка → установка / ошибка. */
@Composable
fun UpdateDialog(
    state: UpdateUiState,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
    onDismiss: () -> Unit
) {
    when (state) {
        UpdateUiState.Idle -> Unit

        UpdateUiState.Checking -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Проверка обновлений") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Связываемся с сервером…")
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
        )

        is UpdateUiState.UpToDate -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Обновлений нет") },
            text = { Text("У вас установлена последняя версия (${state.version}).") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
        )

        is UpdateUiState.Error -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Не получилось") },
            text = { Text(state.message) },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
        )

        is UpdateUiState.Available -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Доступна версия ${state.info.versionName}") },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 280.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    val size = UpdateFormat.size(state.info.sizeBytes)
                    if (size.isNotEmpty()) {
                        Text(
                            text = "Размер: $size",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (state.info.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Что нового", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(state.info.notes)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = onDownload,
                    modifier = Modifier.testTag("update_download_button")
                ) { Text("Скачать") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Позже") } }
        )

        is UpdateUiState.Downloading -> AlertDialog(
            // Закрыть можно только кнопкой «Отмена», случайное касание вне окна загрузку не прервёт
            onDismissRequest = {},
            title = { Text("Загрузка обновления") },
            text = {
                Column {
                    if (state.progress >= 0f) {
                        LinearProgressIndicator(
                            progress = { state.progress },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (state.progress >= 0f) "${(state.progress * 100).toInt()}%" else "Загрузка…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onCancelDownload) { Text("Отмена") } }
        )

        is UpdateUiState.ReadyToInstall -> InstallDialog(state = state, onDismiss = onDismiss)
    }
}

@Composable
private fun InstallDialog(
    state: UpdateUiState.ReadyToInstall,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var awaitingPermission by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    fun install() {
        if (!ApkInstaller.canInstall(context)) {
            // Первый раз Android просит разрешить установку из этого приложения
            awaitingPermission = true
            errorText = ApkInstaller.openInstallPermissionSettings(context)
        } else {
            awaitingPermission = false
            errorText = ApkInstaller.install(context, state.file)
        }
    }

    // Вернулись из настроек с включённым разрешением — продолжаем установку сами
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        if (awaitingPermission && ApkInstaller.canInstall(context)) {
            awaitingPermission = false
            errorText = ApkInstaller.install(context, state.file)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Обновление готово") },
        text = {
            Column {
                Text(
                    "Версия ${state.info.versionName} скачана. Нажмите «Установить» и подтвердите " +
                        "установку в окне Android — приложение перезапустится."
                )
                if (awaitingPermission) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Разрешите приложению устанавливать обновления в открывшихся настройках, " +
                            "затем вернитесь сюда.",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                errorText?.let { message ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = message, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { install() },
                modifier = Modifier.testTag("update_install_button")
            ) { Text("Установить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Позже") } }
    )
}
