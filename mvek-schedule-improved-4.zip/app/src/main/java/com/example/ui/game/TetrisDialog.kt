package com.example.ui.game

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.game.TetrisEngine
import com.example.game.Tetromino
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Цвета фигур в порядке Tetromino.colorId: I, O, T, S, Z, J, L (индекс 0 — пустая клетка)
private val PieceColors = listOf(
    Color.Transparent,
    Color(0xFF22D3EE),
    Color(0xFFFACC15),
    Color(0xFFA855F7),
    Color(0xFF22C55E),
    Color(0xFFEF4444),
    Color(0xFF3B82F6),
    Color(0xFFF97316)
)
private val BoardColor = Color(0xFF111827)
private val MutedText = Color(0xFF94A3B8)

/** Пасхалка: тетрис на весь экран. Открывается десятью нажатиями на версию приложения. */
@Composable
fun TetrisDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tetris", Context.MODE_PRIVATE) }
    val engine = remember { TetrisEngine() }
    // Состояние игры для экрана — неизменяемый снимок. После каждого действия сохраняем новый снимок,
    // и Compose перерисовывает всё, что его читает (поле, счёт, «Дальше»).
    var game by remember { mutableStateOf(engine.snapshot()) }
    var paused by remember { mutableStateOf(false) }
    var best by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    val over = game.gameOver

    LaunchedEffect(over) {
        if (over && game.score > best) {
            best = game.score
            prefs.edit().putInt("best", best).apply()
        }
    }

    // Игровой таймер: чем выше уровень, тем чаще фигура опускается
    LaunchedEffect(paused, over) {
        while (!paused && !engine.gameOver) {
            delay(engine.dropIntervalMs())
            engine.tick()
            game = engine.snapshot()
        }
    }

    fun act(action: () -> Unit) {
        if (!paused && !engine.gameOver) {
            action()
            game = engine.snapshot()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Stat("Счёт", game.score.toString(), Modifier.weight(1f))
                    Stat("Рекорд", best.toString(), Modifier.weight(1f))
                    Stat("Линии", game.lines.toString(), Modifier.weight(1f))
                    Stat("Уровень", game.level.toString(), Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Дальше", color = MutedText, fontSize = 12.sp)
                    NextPiece(game.next)
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { if (!game.gameOver) paused = !paused }) {
                        Text(if (paused) "Продолжить" else "Пауза")
                    }
                    TextButton(onClick = onDismiss) { Text("Закрыть") }
                }

                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    // Клетка подбирается так, чтобы поле целиком помещалось и по ширине, и по высоте
                    val cellDp = minOf(maxWidth / engine.width, maxHeight / engine.height)
                    val snapshot = game
                    Canvas(modifier = Modifier.size(cellDp * engine.width, cellDp * engine.height)) {
                        val cell = size.width / snapshot.board[0].size
                        drawRect(BoardColor)
                        for (y in snapshot.board.indices) {
                            for (x in snapshot.board[y].indices) {
                                val id = snapshot.board[y][x]
                                if (id != 0) drawCell(x.toFloat(), y.toFloat(), cell, PieceColors[id])
                            }
                        }
                        if (!snapshot.gameOver) {
                            val color = PieceColors[snapshot.piece.colorId]
                            for ((x, y) in snapshot.ghost) {
                                drawCell(x.toFloat(), y.toFloat(), cell, color.copy(alpha = 0.25f))
                            }
                            for ((x, y) in snapshot.current) {
                                drawCell(x.toFloat(), y.toFloat(), cell, color)
                            }
                        }
                    }

                    if (over) {
                        Overlay {
                            Text("Игра окончена", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("Счёт: ${game.score}", color = MutedText, fontSize = 16.sp)
                            Button(onClick = {
                                engine.reset()
                                paused = false
                                game = engine.snapshot()
                            }) { Text("Заново") }
                        }
                    } else if (paused) {
                        Overlay {
                            Text("Пауза", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Button(onClick = { paused = false }) { Text("Продолжить") }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GameButton(Modifier.weight(1f), repeat = true, onAction = { act { engine.moveLeft() } }) {
                        ArrowIcon(Arrow.Left)
                    }
                    GameButton(Modifier.weight(1f), repeat = true, onAction = { act { engine.moveRight() } }) {
                        ArrowIcon(Arrow.Right)
                    }
                    GameButton(Modifier.weight(1f), repeat = false, onAction = { act { engine.rotate() } }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Повернуть",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    GameButton(Modifier.weight(1f), repeat = true, onAction = { act { engine.softDrop() } }) {
                        ArrowIcon(Arrow.Down)
                    }
                    GameButton(Modifier.weight(1f), repeat = false, onAction = { act { engine.hardDrop() } }) {
                        ArrowIcon(Arrow.DoubleDown)
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawCell(x: Float, y: Float, cell: Float, color: Color) {
    drawRect(
        color = color,
        topLeft = Offset(x * cell + 1f, y * cell + 1f),
        size = Size(cell - 2f, cell - 2f)
    )
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MutedText, fontSize = 12.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun NextPiece(kind: Tetromino) {
    Canvas(modifier = Modifier.size(52.dp)) {
        val cells = kind.rotations[0]
        val minX = cells.minOf { it.first }
        val maxX = cells.maxOf { it.first }
        val minY = cells.minOf { it.second }
        val maxY = cells.maxOf { it.second }
        val cell = size.width / 4f
        // Центрируем фигуру в квадрате 4×4
        val offsetX = (4 - (maxX - minX + 1)) / 2f
        val offsetY = (4 - (maxY - minY + 1)) / 2f
        for ((x, y) in cells) {
            drawCell(x - minX + offsetX, y - minY + offsetY, cell, PieceColors[kind.colorId])
        }
    }
}

@Composable
private fun Overlay(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xDD000000))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        content()
    }
}

private enum class Arrow { Left, Right, Down, DoubleDown }

/**
 * Стрелки рисуются самим приложением, а не символами шрифта: на части телефонов шрифт не содержит стрелок
 * «← → ↓», и вместо них показывались непонятные значки.
 */
@Composable
private fun ArrowIcon(arrow: Arrow) {
    Canvas(modifier = Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        fun triangle(ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float) {
            val path = Path().apply {
                moveTo(ax * w, ay * h)
                lineTo(bx * w, by * h)
                lineTo(cx * w, cy * h)
                close()
            }
            drawPath(path, Color.White)
        }
        when (arrow) {
            Arrow.Left -> triangle(0.75f, 0.15f, 0.75f, 0.85f, 0.2f, 0.5f)
            Arrow.Right -> triangle(0.25f, 0.15f, 0.25f, 0.85f, 0.8f, 0.5f)
            Arrow.Down -> triangle(0.15f, 0.25f, 0.85f, 0.25f, 0.5f, 0.8f)
            Arrow.DoubleDown -> {
                triangle(0.15f, 0.08f, 0.85f, 0.08f, 0.5f, 0.48f)
                triangle(0.15f, 0.52f, 0.85f, 0.52f, 0.5f, 0.92f)
            }
        }
    }
}

/** Кнопка управления; при удержании ([repeat] = true) действие повторяется. */
@Composable
private fun GameButton(
    modifier: Modifier = Modifier,
    repeat: Boolean,
    onAction: () -> Unit,
    content: @Composable () -> Unit
) {
    val scope = rememberCoroutineScope()
    val currentAction by rememberUpdatedState(onAction)
    Column(
        modifier = modifier
            .height(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1F2937))
            .pointerInput(repeat) {
                detectTapGestures(
                    onPress = {
                        currentAction()
                        if (repeat) {
                            val job = scope.launch {
                                delay(250)
                                while (true) {
                                    currentAction()
                                    delay(70)
                                }
                            }
                            tryAwaitRelease()
                            job.cancel()
                        } else {
                            tryAwaitRelease()
                        }
                    }
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        content()
    }
}
