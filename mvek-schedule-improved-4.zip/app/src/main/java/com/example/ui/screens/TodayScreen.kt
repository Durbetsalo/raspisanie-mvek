package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DaySchedule
import com.example.data.model.Lesson
import com.example.data.model.LessonTimeStatus
import com.example.data.model.LessonType
import com.example.ui.components.CommonEmptyState
import com.example.ui.components.CurrentLessonHeroCard
import com.example.ui.components.LessonCard
import com.example.ui.components.ScheduleSkeletonList
import com.example.ui.components.WeekDaySelector
import com.example.ui.game.TetrisDialog
import com.example.ui.theme.AppIcons
import com.example.ui.viewmodel.ScheduleUiState
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val HeaderChipShape = RoundedCornerShape(12.dp)
private val DayNavShape = RoundedCornerShape(16.dp)
private val EmptyDayCardShape = RoundedCornerShape(20.dp)
private val DaySwipeThreshold = 72.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    currentGroup: String?,
    uiState: ScheduleUiState,
    selectedWeekIndex: Int,
    selectedDayIndex: Int,
    currentTimeMinutesFlow: StateFlow<Int>,
    isDarkTheme: Boolean,
    onSelectWeek: (Int) -> Unit,
    onSelectDay: (Int) -> Unit,
    onChangeGroupClick: () -> Unit,
    onToggleThemeClick: () -> Unit,
    onRefresh: () -> Unit,
    onGoToToday: () -> Unit = {},
    appVersionName: String = "",
    updatesEnabled: Boolean = false,
    pendingUpdateVersion: String? = null,
    onCheckUpdates: () -> Unit = {}
) {
    val colorScheme = MaterialTheme.colorScheme
    var showTetris by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()
    var selectedLessonForDetails by remember { mutableStateOf<Lesson?>(null) }
    val onLessonClick = remember { { lesson: Lesson -> selectedLessonForDetails = lesson } }

    LaunchedEffect(selectedWeekIndex, selectedDayIndex) {
        if (scrollState.value != 0) {
            scrollState.scrollTo(0)
        }
    }

    val successState = uiState as? ScheduleUiState.Success
    val isRefreshing = successState?.isRefreshing == true

    Scaffold(
        containerColor = colorScheme.background,
        topBar = {
            TodayTopBar(
                currentGroup = currentGroup,
                isRefreshing = isRefreshing,
                isOffline = successState?.isOffline == true,
                lastUpdatedMillis = successState?.lastUpdatedMillis,
                isDarkTheme = isDarkTheme,
                onChangeGroupClick = onChangeGroupClick,
                onToggleThemeClick = onToggleThemeClick,
                onRefresh = onRefresh,
                appVersionName = appVersionName,
                updatesEnabled = updatesEnabled,
                pendingUpdateVersion = pendingUpdateVersion,
                onCheckUpdates = onCheckUpdates,
                onVersionEasterEgg = { showTetris = true }
            )
        },
        bottomBar = {
            WeekSwitcherBottomBar(
                selectedWeekIndex = selectedWeekIndex,
                onSelectWeek = onSelectWeek
            )
        }
    ) { padding ->
        when (uiState) {
            is ScheduleUiState.Loading -> {
                ScheduleSkeletonList(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                )
            }
            is ScheduleUiState.Error -> {
                CommonEmptyState(
                    title = "Не удалось загрузить расписание",
                    message = uiState.message,
                    actionButtonText = "Повторить попытку",
                    onActionClick = onRefresh,
                    secondaryActionText = "Сменить группу",
                    onSecondaryActionClick = onChangeGroupClick,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                )
            }
            is ScheduleUiState.Success -> {
                val schedule = uiState.schedule
                val days = schedule.days
                val safeDayIndex = selectedDayIndex.coerceIn(0, (days.size - 1).coerceAtLeast(0))
                val currentDay = days.getOrNull(safeDayIndex)
                val isActualToday = selectedWeekIndex == 0 && currentDay?.isToday == true
                // «К сегодня» нужна, только если мы ушли с сегодняшнего дня (в воскресенье «сегодня» в расписании нет)
                val showGoToToday = !isActualToday && (selectedWeekIndex != 0 || days.any { it.isToday })

                // Потянуть вниз — обновить расписание
                PullToRefreshBox(
                    isRefreshing = uiState.isRefreshing,
                    onRefresh = onRefresh,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    // A single day has at most ~6 lessons: Column + verticalScroll composes once
                    // and scrolls purely on GPU RenderNodes with zero LazyColumn disposal/recomposition jank.
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            // Свайп влево/вправо — следующий/предыдущий день
                            .pointerInput(safeDayIndex, days.size, onSelectDay) {
                                val threshold = DaySwipeThreshold.toPx()
                                var totalDrag = 0f
                                detectHorizontalDragGestures(
                                    onDragStart = { totalDrag = 0f },
                                    onDragEnd = {
                                        if (totalDrag <= -threshold && safeDayIndex < days.size - 1) {
                                            onSelectDay(safeDayIndex + 1)
                                        } else if (totalDrag >= threshold && safeDayIndex > 0) {
                                            onSelectDay(safeDayIndex - 1)
                                        }
                                        totalDrag = 0f
                                    },
                                    onDragCancel = { totalDrag = 0f },
                                    onHorizontalDrag = { change, dragAmount ->
                                        change.consume()
                                        totalDrag += dragAmount
                                    }
                                )
                            }
                            .verticalScroll(scrollState)
                            .padding(top = 8.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (schedule.weekRange.isNotBlank() || showGoToToday) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 18.dp, end = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = schedule.weekRange,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = colorScheme.onSurfaceVariant
                                )
                                if (showGoToToday) {
                                    TextButton(
                                        onClick = onGoToToday,
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                        modifier = Modifier
                                            .height(28.dp)
                                            .testTag("go_to_today_button")
                                    ) {
                                        Text(
                                            text = "К сегодня",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }

                        if (days.isNotEmpty()) {
                            WeekDaySelector(
                                days = days,
                                selectedIndex = safeDayIndex,
                                onDaySelected = onSelectDay
                            )
                        }

                        if (currentDay != null) {
                            DayNavigationBar(
                                currentDay = currentDay,
                                isActualToday = isActualToday,
                                canGoPrev = safeDayIndex > 0,
                                canGoNext = safeDayIndex < days.size - 1,
                                onPrevDay = { if (safeDayIndex > 0) onSelectDay(safeDayIndex - 1) },
                                onNextDay = { if (safeDayIndex < days.size - 1) onSelectDay(safeDayIndex + 1) }
                            )

                            DayLessonsSection(
                                currentDay = currentDay,
                                isActualToday = isActualToday,
                                currentTimeMinutesFlow = currentTimeMinutesFlow,
                                onLessonClick = onLessonClick
                            )
                        }
                    }
                }
            }
        }
    }

    selectedLessonForDetails?.let { lesson ->
        LessonDetailsDialog(
            lesson = lesson,
            onDismiss = { selectedLessonForDetails = null }
        )
    }

    if (showTetris) {
        TetrisDialog(onDismiss = { showTetris = false })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TodayTopBar(
    currentGroup: String?,
    isRefreshing: Boolean,
    isOffline: Boolean,
    lastUpdatedMillis: Long?,
    isDarkTheme: Boolean,
    onChangeGroupClick: () -> Unit,
    onToggleThemeClick: () -> Unit,
    onRefresh: () -> Unit,
    appVersionName: String,
    updatesEnabled: Boolean,
    pendingUpdateVersion: String?,
    onCheckUpdates: () -> Unit,
    onVersionEasterEgg: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    // Пасхалка: 10 нажатий подряд на версию (пауза между нажатиями — не больше 2 секунд)
    var versionTaps by remember { mutableIntStateOf(0) }
    var lastVersionTapAt by remember { mutableLongStateOf(0L) }
    var tapToast by remember { mutableStateOf<Toast?>(null) }
    val offlineSubtitle = remember(isOffline, lastUpdatedMillis) {
        if (isOffline) formatOfflineSubtitle(lastUpdatedMillis) else ""
    }
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(HeaderChipShape)
                    .clickable(onClick = onChangeGroupClick)
                    .padding(vertical = 4.dp, horizontal = 6.dp)
                    .testTag("group_header_chip")
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = currentGroup ?: "Выберите группу",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 19.sp,
                            color = colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = AppIcons.SwapHoriz,
                            contentDescription = "Сменить группу",
                            tint = colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = when {
                            isRefreshing -> "Обновление..."
                            isOffline -> offlineSubtitle
                            else -> "МВЕК • Расписание"
                        },
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = when {
                            isRefreshing -> colorScheme.primary
                            isOffline -> colorScheme.error
                            else -> colorScheme.onSurfaceVariant
                        }
                    )
                }
            }
        },
        actions = {
            IconButton(
                onClick = onToggleThemeClick,
                modifier = Modifier.testTag("theme_toggle_button")
            ) {
                Icon(
                    imageVector = if (isDarkTheme) AppIcons.LightMode else AppIcons.DarkMode,
                    contentDescription = if (isDarkTheme) "Включить светлую тему" else "Включить тёмную тему"
                )
            }
            IconButton(
                onClick = onRefresh,
                modifier = Modifier.testTag("today_refresh_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Обновить"
                )
            }
            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.testTag("overflow_menu_button")
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Меню"
                        )
                        // Красная точка: найдено обновление приложения
                        if (pendingUpdateVersion != null) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .align(Alignment.TopEnd)
                                    .background(colorScheme.error, CircleShape)
                            )
                        }
                    }
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    if (updatesEnabled) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (pendingUpdateVersion != null) {
                                        "Доступно обновление $pendingUpdateVersion"
                                    } else {
                                        "Проверить обновления"
                                    }
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                onCheckUpdates()
                            },
                            modifier = Modifier.testTag("check_updates_item")
                        )
                    }
                    if (appVersionName.isNotBlank()) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    "Версия $appVersionName",
                                    color = colorScheme.onSurfaceVariant
                                )
                            },
                            onClick = {
                                val now = System.currentTimeMillis()
                                versionTaps = if (now - lastVersionTapAt > 2_000L) 1 else versionTaps + 1
                                lastVersionTapAt = now
                                if (versionTaps >= 10) {
                                    versionTaps = 0
                                    tapToast?.cancel()
                                    menuExpanded = false
                                    onVersionEasterEgg()
                                } else if (versionTaps >= 6) {
                                    tapToast?.cancel()
                                    tapToast = Toast
                                        .makeText(context, "Ещё ${tapsWord(10 - versionTaps)}…", Toast.LENGTH_SHORT)
                                        .also { it.show() }
                                }
                            }
                        )
                    }
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = colorScheme.surface
        )
    )
}

@Composable
private fun WeekSwitcherBottomBar(
    selectedWeekIndex: Int,
    onSelectWeek: (Int) -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    val onSelectThisWeek = remember(onSelectWeek) { { onSelectWeek(0) } }
    val onSelectNextWeek = remember(onSelectWeek) { { onSelectWeek(1) } }

    Surface(
        color = colorScheme.background,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .testTag("week_segmented_row")
        ) {
            SegmentedButton(
                selected = selectedWeekIndex == 0,
                onClick = onSelectThisWeek,
                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                icon = {},
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("this_week_tab")
            ) {
                Text(
                    text = "Эта неделя",
                    fontWeight = if (selectedWeekIndex == 0) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            SegmentedButton(
                selected = selectedWeekIndex == 1,
                onClick = onSelectNextWeek,
                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                icon = {},
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("next_week_tab")
            ) {
                Text(
                    text = "Следующая неделя",
                    fontWeight = if (selectedWeekIndex == 1) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun DayNavigationBar(
    currentDay: DaySchedule,
    isActualToday: Boolean,
    canGoPrev: Boolean,
    canGoNext: Boolean,
    onPrevDay: () -> Unit,
    onNextDay: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .background(colorScheme.surfaceVariant.copy(alpha = 0.5f), DayNavShape)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onPrevDay,
            enabled = canGoPrev,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Предыдущий день",
                modifier = Modifier.size(18.dp)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${currentDay.dayNameFull} ${currentDay.dateString}".trim(),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = colorScheme.onSurface
            )
            if (isActualToday) {
                Text(
                    text = "Сегодня",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = colorScheme.primary
                )
            }
        }

        IconButton(
            onClick = onNextDay,
            enabled = canGoNext,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Следующий день",
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun DayLessonsSection(
    currentDay: DaySchedule,
    isActualToday: Boolean,
    currentTimeMinutesFlow: StateFlow<Int>,
    onLessonClick: (Lesson) -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme

    if (currentDay.lessons.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .background(colorScheme.surface, EmptyDayCardShape)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = AppIcons.Celebration,
                contentDescription = null,
                tint = colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Пар нет",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "В этот день занятия отсутствуют.",
                fontSize = 13.sp,
                color = colorScheme.onSurfaceVariant
            )
        }
        return
    }

    // Only subscribe to minute-tick updates when displaying Today's active lessons.
    val currentTimeMinutes = if (isActualToday) {
        currentTimeMinutesFlow.collectAsStateWithLifecycle().value
    } else {
        0
    }

    val nextLessonNumber = remember(currentDay, currentTimeMinutes, isActualToday) {
        if (isActualToday) {
            val hasOngoing = currentDay.lessons.any {
                it.getTimeStatus(currentTimeMinutes) == LessonTimeStatus.ONGOING
            }
            if (!hasOngoing) {
                currentDay.lessons.firstOrNull {
                    it.getTimeStatus(currentTimeMinutes) == LessonTimeStatus.UPCOMING
                }?.number
            } else null
        } else null
    }

    if (isActualToday) {
        CurrentLessonHeroCard(
            lessons = currentDay.lessons,
            currentTimeMinutes = currentTimeMinutes,
            isToday = true,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Расписание пар",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = colorScheme.onSurface
        )
        Text(
            text = "${currentDay.lessons.size} ${getLessonCountWord(currentDay.lessons.size)}",
            fontSize = 13.sp,
            color = colorScheme.onSurfaceVariant
        )
    }

    // Key by slot index so switching days reuses existing card nodes instead of rebuilding them
    currentDay.lessons.forEachIndexed { idx, lesson ->
        key(idx) {
            LessonCard(
                lesson = lesson,
                currentTimeMinutes = currentTimeMinutes,
                isToday = isActualToday,
                isNextLesson = lesson.number == nextLessonNumber,
                onLessonClick = onLessonClick,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
private fun LessonDetailsDialog(
    lesson: Lesson,
    onDismiss: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "${lesson.number} пара • ${lesson.timeRange}",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = lesson.subject,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = colorScheme.primary
                )
                if (lesson.topic.isNotBlank()) {
                    Text(text = "Тема: ${lesson.topic}", fontSize = 14.sp)
                }
                if (lesson.auditorium.isNotBlank()) {
                    Text(
                        text = "Аудитория: ${lesson.auditorium}",
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
                if (lesson.teacher.isNotBlank()) {
                    Text(text = "Преподаватель: ${lesson.teacher}", fontSize = 14.sp)
                }
                if (lesson.groups.isNotBlank()) {
                    Text(text = "Группы: ${lesson.groups}", fontSize = 14.sp)
                }
                if (lesson.lessonType != LessonType.OTHER) {
                    Text(text = "Тип занятия: ${lesson.lessonType.displayName}", fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )
}

/** «1 нажатие», «2–4 нажатия», «5+ нажатий». */
private fun tapsWord(n: Int): String = when {
    n % 10 == 1 && n % 100 != 11 -> "$n нажатие"
    n % 10 in 2..4 && n % 100 !in 12..14 -> "$n нажатия"
    else -> "$n нажатий"
}

/** Подпись под названием группы, когда обновить расписание не удалось и показаны сохранённые данные. */
private fun formatOfflineSubtitle(lastUpdatedMillis: Long?): String {
    if (lastUpdatedMillis == null) return "Не удалось обновить • данные могли устареть"
    val updated = Calendar.getInstance().apply { timeInMillis = lastUpdatedMillis }
    val now = Calendar.getInstance()
    val sameDay = updated.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
        updated.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "HH:mm" else "dd.MM HH:mm"
    val formatted = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(lastUpdatedMillis))
    return "Не удалось обновить • данные от $formatted"
}

private fun getLessonCountWord(count: Int): String {
    val lastDigit = count % 10
    val lastTwoDigits = count % 100
    return when {
        lastTwoDigits in 11..19 -> "пар"
        lastDigit == 1 -> "пара"
        lastDigit in 2..4 -> "пары"
        else -> "пар"
    }
}
