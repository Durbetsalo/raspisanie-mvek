package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Lesson
import com.example.data.model.LessonTimeStatus
import com.example.data.model.LessonType
import com.example.ui.theme.AppIcons
import com.example.ui.theme.BadgeCredit
import com.example.ui.theme.BadgeExam
import com.example.ui.theme.BadgeLab
import com.example.ui.theme.BadgeLecture
import com.example.ui.theme.BadgePractice
import com.example.ui.theme.StatusFinished
import com.example.ui.theme.StatusOngoing

private val LessonCardShape = RoundedCornerShape(20.dp)
private val StatusPillShape = RoundedCornerShape(12.dp)
private val TagShape = RoundedCornerShape(8.dp)

@Composable
fun LessonCard(
    lesson: Lesson,
    currentTimeMinutes: Int,
    isToday: Boolean,
    onLessonClick: (Lesson) -> Unit,
    modifier: Modifier = Modifier,
    isNextLesson: Boolean = false
) {
    val status = if (isToday) lesson.getTimeStatus(currentTimeMinutes) else LessonTimeStatus.UPCOMING
    val isOngoing = isToday && status == LessonTimeStatus.ONGOING
    val isFinished = isToday && status == LessonTimeStatus.FINISHED

    val colorScheme = MaterialTheme.colorScheme
    val borderStroke = remember(isOngoing, isNextLesson, isToday, colorScheme.primary, colorScheme.outline) {
        when {
            isOngoing -> BorderStroke(2.dp, StatusOngoing)
            isNextLesson && isToday -> BorderStroke(2.dp, colorScheme.primary)
            else -> BorderStroke(1.dp, colorScheme.outline.copy(alpha = 0.4f))
        }
    }

    val containerColor = when {
        isOngoing -> colorScheme.primaryContainer.copy(alpha = 0.35f)
        isNextLesson && isToday -> colorScheme.secondaryContainer.copy(alpha = 0.3f)
        else -> colorScheme.surface
    }

    val cardAlpha = if (isFinished) 0.65f else 1.0f
    val tagBackground = colorScheme.surfaceVariant.copy(alpha = 0.8f)
    val clickHandler = remember(lesson, onLessonClick) { { onLessonClick(lesson) } }

    Surface(
        onClick = clickHandler,
        shape = LessonCardShape,
        color = containerColor,
        border = borderStroke,
        modifier = modifier
            .fillMaxWidth()
            .testTag("lesson_card_${lesson.number}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = when {
                            isOngoing -> StatusOngoing
                            isNextLesson && isToday -> colorScheme.primary
                            else -> colorScheme.surfaceVariant
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${lesson.number}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = if (isOngoing || (isNextLesson && isToday)) Color.White else colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Время занимает всё свободное место, а статус справа сохраняет свою ширину
            // (иначе на узких экранах «Следующая пара» переносилась на вторую строку)
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = AppIcons.Schedule,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = lesson.timeRange.ifEmpty { "${lesson.startTime} — ${lesson.endTime}" },
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (isToday) {
                when {
                    isOngoing -> {
                        Row(
                            modifier = Modifier
                                .background(StatusOngoing.copy(alpha = 0.15f), StatusPillShape)
                                .border(1.dp, StatusOngoing.copy(alpha = 0.4f), StatusPillShape)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(StatusOngoing, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Идёт сейчас",
                                color = StatusOngoing,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    isNextLesson -> {
                        Text(
                            text = "Следующая пара",
                            modifier = Modifier
                                .background(colorScheme.primary.copy(alpha = 0.12f), StatusPillShape)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            color = colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    isFinished -> {
                        Text(
                            text = "Завершена",
                            color = StatusFinished,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = lesson.subject,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = colorScheme.onSurface.copy(alpha = cardAlpha),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )

        if (lesson.topic.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = lesson.topic,
                fontSize = 13.sp,
                color = colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (lesson.lessonType != LessonType.OTHER || lesson.auditorium.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (lesson.lessonType != LessonType.OTHER) {
                    val badgeColor = when (lesson.lessonType) {
                        LessonType.LECTURE -> BadgeLecture
                        LessonType.PRACTICE -> BadgePractice
                        LessonType.LAB -> BadgeLab
                        LessonType.EXAM -> BadgeExam
                        LessonType.CREDIT -> BadgeCredit
                        else -> colorScheme.secondary
                    }
                    Text(
                        text = lesson.lessonType.displayName,
                        modifier = Modifier
                            .background(badgeColor.copy(alpha = 0.15f), TagShape)
                            .border(1.dp, badgeColor.copy(alpha = 0.3f), TagShape)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        color = badgeColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (lesson.auditorium.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .background(tagBackground, TagShape)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = AppIcons.MeetingRoom,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Ауд. ${lesson.auditorium}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        if (lesson.teacher.isNotBlank() || lesson.groups.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .background(tagBackground, TagShape)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (lesson.teacher.isNotBlank()) Icons.Default.Person else AppIcons.Groups,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp),
                    tint = if (lesson.teacher.isNotBlank()) colorScheme.secondary else colorScheme.primary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = lesson.teacher.ifBlank { lesson.groups },
                    fontSize = 12.sp,
                    color = colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
    }
}
