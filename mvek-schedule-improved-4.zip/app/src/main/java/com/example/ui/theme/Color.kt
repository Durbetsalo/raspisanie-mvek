package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette: Deep Blue + Violet
val DeepBlue = Color(0xFF1E3A8A)
val RoyalBlue = Color(0xFF2563EB)
val LightRoyalBlue = Color(0xFF60A5FA)
val SoftBlueContainer = Color(0xFFEFF6FF)

val ElectricViolet = Color(0xFF7C3AED)
val SoftViolet = Color(0xFF8B5CF6)
val LightVioletContainer = Color(0xFFF5F3FF)

// Status colors
val StatusOngoing = Color(0xFF10B981)
val StatusOngoingContainer = Color(0xFFD1FAE5)
val StatusUpcoming = Color(0xFF3B82F6)
val StatusUpcomingContainer = Color(0xFFDBEAFE)
val StatusFinished = Color(0xFF94A3B8)
val StatusFinishedContainer = Color(0xFFF1F5F9)

// Lesson type badges
val BadgeLecture = Color(0xFF2563EB)
val BadgePractice = Color(0xFF7C3AED)
val BadgeLab = Color(0xFF059669)
val BadgeExam = Color(0xFFDC2626)
val BadgeCredit = Color(0xFFD97706)

// Dark theme colors
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131C2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF2E3D56)

// Light theme colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
