package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Group
import com.example.ui.theme.AppIcons
import com.example.ui.theme.RoyalBlue

private val QUICK_DIRECTIONS = listOf("ДИС", "ДГД", "ДБ", "ДНГ", "ДП", "ДР", "ДТГ", "ДТД", "ДК")
private val MainCardShape = RoundedCornerShape(24.dp)
private val FieldShape = RoundedCornerShape(16.dp)
private val GroupItemShape = RoundedCornerShape(14.dp)
private val ChipShape = RoundedCornerShape(10.dp)
private val BadgeCountShape = RoundedCornerShape(8.dp)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupSelectScreen(
    groups: List<Group>,
    currentGroup: String?,
    recentGroups: List<String>,
    onGroupSelected: (String) -> Unit,
    onBackClick: (() -> Unit)? = null
) {
    val initialDirection = remember(currentGroup) {
        if (!currentGroup.isNullOrBlank()) {
            val trimmed = currentGroup.trim()
            val dashIdx = trimmed.indexOf('-')
            if (dashIdx > 0) trimmed.substring(0, dashIdx).uppercase()
            else trimmed.takeWhile { it.isLetter() }.uppercase()
        } else "ДИС"
    }

    val initialNumber = remember(currentGroup) {
        if (!currentGroup.isNullOrBlank()) {
            val trimmed = currentGroup.trim()
            val dashIdx = trimmed.indexOf('-')
            if (dashIdx >= 0 && dashIdx + 1 < trimmed.length) trimmed.substring(dashIdx + 1).trim()
            else trimmed.dropWhile { it.isLetter() }.trim()
        } else ""
    }

    var selectedDirection by remember { mutableStateOf(initialDirection) }
    var selectedNumber by remember { mutableStateOf(initialNumber) }

    var isDirectionDropdownExpanded by remember { mutableStateOf(false) }
    var isNumberDropdownExpanded by remember { mutableStateOf(false) }

    val directionItems = remember(groups) {
        val groupedByDir = groups.groupBy { it.directionCode }
        val distinct = groupedByDir.keys.filter { it.isNotBlank() }
        val keys = if (distinct.isEmpty()) QUICK_DIRECTIONS else distinct.sorted()
        keys.map { dirCode ->
            DirectionItem(
                code = dirCode,
                title = Group.getDirectionTitle(dirCode),
                count = groupedByDir[dirCode]?.size ?: 0
            )
        }
    }

    val currentDirectionGroups = remember(groups, selectedDirection) {
        groups.filter { it.directionCode.equals(selectedDirection, ignoreCase = true) }
    }

    val numbersForDirection = remember(currentDirectionGroups) {
        currentDirectionGroups.map { it.numberPart }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val computedGroupName = remember(selectedDirection, selectedNumber, currentDirectionGroups) {
        val dir = selectedDirection.trim().uppercase()
        val num = selectedNumber.trim()
        if (dir.isEmpty() || num.isEmpty()) ""
        else {
            val exact = currentDirectionGroups.firstOrNull {
                it.numberPart.equals(num, ignoreCase = true)
            }
            exact?.name ?: "$dir-$num"
        }
    }

    val colorScheme = MaterialTheme.colorScheme

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Выбор группы",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Колледж МВЕК • Расписание занятий",
                            fontSize = 12.sp,
                            color = colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("group_select_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Назад к расписанию"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "main_card", contentType = "main_card") {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("direction_and_number_card"),
                    shape = MainCardShape,
                    colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(colorScheme.primaryContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = AppIcons.School,
                                    contentDescription = null,
                                    tint = colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Выберите направление и группу",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = colorScheme.onSurface
                                )
                                Text(
                                    text = "Например: ДИС и 252.2/21",
                                    fontSize = 12.sp,
                                    color = colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "1. Направление подготовки:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        ExposedDropdownMenuBox(
                            expanded = isDirectionDropdownExpanded,
                            onExpandedChange = { isDirectionDropdownExpanded = it },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = if (selectedDirection.isNotBlank()) {
                                    "$selectedDirection — ${Group.getDirectionTitle(selectedDirection)}"
                                } else "",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDirectionDropdownExpanded)
                                },
                                placeholder = { Text("Выберите направление (ДИС, ДГД, ДБ...)") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled = true)
                                    .testTag("direction_dropdown"),
                                shape = FieldShape,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = colorScheme.primary,
                                    unfocusedBorderColor = colorScheme.outline.copy(alpha = 0.5f)
                                )
                            )

                            ExposedDropdownMenu(
                                expanded = isDirectionDropdownExpanded,
                                onDismissRequest = { isDirectionDropdownExpanded = false }
                            ) {
                                directionItems.forEach { item ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = item.code,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = colorScheme.primary
                                                    )
                                                    Text(
                                                        text = item.title,
                                                        fontSize = 12.sp,
                                                        color = colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                                if (item.count > 0) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = "${item.count} гр.",
                                                        fontSize = 11.sp,
                                                        modifier = Modifier
                                                            .background(colorScheme.surfaceVariant, BadgeCountShape)
                                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                                        color = colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            selectedDirection = item.code
                                            selectedNumber = ""
                                            isDirectionDropdownExpanded = false
                                        },
                                        modifier = Modifier.testTag("direction_item_${item.code}")
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            QUICK_DIRECTIONS.forEach { dir ->
                                val isSelected = selectedDirection == dir
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedDirection = dir
                                        selectedNumber = ""
                                    },
                                    label = {
                                        Text(
                                            dir,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = colorScheme.primaryContainer
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "2. Номер группы:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        ExposedDropdownMenuBox(
                            expanded = isNumberDropdownExpanded,
                            onExpandedChange = { isNumberDropdownExpanded = it },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedNumber,
                                onValueChange = {
                                    selectedNumber = it
                                    isNumberDropdownExpanded = true
                                },
                                placeholder = {
                                    Text(
                                        if (selectedDirection.isNotBlank()) "Выберите или введите (напр. 252.2/21)"
                                        else "Сначала выберите направление выше"
                                    )
                                },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (selectedNumber.isNotEmpty()) {
                                            IconButton(onClick = { selectedNumber = "" }) {
                                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Очистить")
                                            }
                                        }
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isNumberDropdownExpanded)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(MenuAnchorType.PrimaryEditable, enabled = selectedDirection.isNotBlank())
                                    .testTag("group_number_dropdown"),
                                shape = FieldShape,
                                enabled = selectedDirection.isNotBlank()
                            )

                            val filteredNumbers = remember(numbersForDirection, selectedNumber) {
                                if (selectedNumber.isBlank()) numbersForDirection
                                else numbersForDirection.filter { it.contains(selectedNumber.trim(), ignoreCase = true) }
                            }

                            if (filteredNumbers.isNotEmpty()) {
                                ExposedDropdownMenu(
                                    expanded = isNumberDropdownExpanded,
                                    onDismissRequest = { isNumberDropdownExpanded = false }
                                ) {
                                    filteredNumbers.forEach { num ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = num,
                                                        fontWeight = FontWeight.SemiBold,
                                                        fontSize = 14.sp
                                                    )
                                                    Text(
                                                        text = "$selectedDirection-$num",
                                                        fontSize = 12.sp,
                                                        color = colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            },
                                            onClick = {
                                                selectedNumber = num
                                                isNumberDropdownExpanded = false
                                            },
                                            modifier = Modifier.testTag("number_item_$num")
                                        )
                                    }
                                }
                            }
                        }

                        if (numbersForDirection.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Группы направления $selectedDirection:",
                                fontSize = 12.sp,
                                color = colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                numbersForDirection.take(10).forEach { num ->
                                    val isSelected = selectedNumber.equals(num, ignoreCase = true)
                                    Text(
                                        text = num,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .clip(ChipShape)
                                            .background(if (isSelected) colorScheme.primary else colorScheme.surfaceVariant)
                                            .clickable { selectedNumber = num }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (computedGroupName.isNotBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(colorScheme.primaryContainer.copy(alpha = 0.45f), GroupItemShape)
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Выбранная группа: $computedGroupName",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = colorScheme.onSurface
                                    )
                                    Text(
                                        text = Group.getDirectionTitle(selectedDirection),
                                        fontSize = 12.sp,
                                        color = colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        Button(
                            onClick = {
                                if (computedGroupName.isNotBlank()) {
                                    onGroupSelected(computedGroupName)
                                }
                            },
                            enabled = computedGroupName.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("show_schedule_button"),
                            shape = FieldShape,
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                        ) {
                            Icon(
                                imageVector = AppIcons.CalendarMonth,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Показать расписание",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            if (recentGroups.isNotEmpty()) {
                item(key = "recent_groups", contentType = "recent") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = AppIcons.History,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Недавно просмотренные группы",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            recentGroups.forEach { groupName ->
                                val isSelected = groupName == currentGroup
                                Surface(
                                    onClick = { onGroupSelected(groupName) },
                                    shape = GroupItemShape,
                                    color = if (isSelected) colorScheme.primaryContainer else colorScheme.surface,
                                    modifier = Modifier.testTag("recent_group_$groupName")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = groupName,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp,
                                            color = colorScheme.onSurface
                                        )
                                        if (isSelected) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (currentDirectionGroups.isNotEmpty()) {
                item(key = "all_groups_header", contentType = "header") {
                    Text(
                        text = "Все группы направления $selectedDirection (${currentDirectionGroups.size}):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = colorScheme.onSurface
                    )
                }

                items(
                    items = currentDirectionGroups,
                    key = { it.name },
                    contentType = { "group_item" }
                ) { grp ->
                    val isSelected = grp.name == currentGroup || grp.name == computedGroupName
                    Surface(
                        onClick = {
                            selectedDirection = grp.directionCode
                            selectedNumber = grp.numberPart
                            onGroupSelected(grp.name)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("group_item_${grp.name}"),
                        shape = GroupItemShape,
                        border = if (isSelected) BorderStroke(1.5.dp, colorScheme.primary) else null,
                        color = if (isSelected) colorScheme.primaryContainer.copy(alpha = 0.5f) else colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        color = if (isSelected) RoyalBlue else colorScheme.surfaceVariant,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = grp.directionCode.take(2),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = grp.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = colorScheme.onSurface
                                )
                                Text(
                                    text = "Номер: ${grp.numberPart} • ${grp.course} курс",
                                    fontSize = 12.sp,
                                    color = colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "Выбрать",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

private data class DirectionItem(
    val code: String,
    val title: String,
    val count: Int
)
