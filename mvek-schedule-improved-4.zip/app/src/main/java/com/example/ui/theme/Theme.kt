package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.local.AppThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = LightRoyalBlue,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),

    secondary = SoftViolet,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF4C1D95),
    onSecondaryContainer = Color(0xFFEDE9FE),

    tertiary = Color(0xFF38BDF8),
    onTertiary = Color.Black,

    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),

    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),

    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),

    outline = DarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = Color.White,
    primaryContainer = SoftBlueContainer,
    onPrimaryContainer = DeepBlue,

    secondary = ElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = LightVioletContainer,
    onSecondaryContainer = Color(0xFF4C1D95),

    tertiary = Color(0xFF0284C7),
    onTertiary = Color.White,

    background = LightBackground,
    onBackground = Color(0xFF0F172A),

    surface = LightSurface,
    onSurface = Color(0xFF0F172A),

    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),

    outline = LightBorder
)

@Composable
fun MyApplicationTheme(
    appThemeMode: AppThemeMode = AppThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val darkTheme = when (appThemeMode) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
