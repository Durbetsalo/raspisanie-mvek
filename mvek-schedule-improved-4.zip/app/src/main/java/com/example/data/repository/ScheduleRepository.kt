package com.example.data.repository

import com.example.data.api.MvekApiClient
import com.example.data.local.OfflineFallbackData
import com.example.data.local.PreferencesManager
import com.example.data.model.DaySchedule
import com.example.data.model.Group
import com.example.data.model.Lesson
import com.example.data.model.LessonType
import com.example.data.model.WeekSchedule
import com.example.data.parser.MvekHtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Результат загрузки недели. [isFresh] = true, если данные только что получены с сервера;
 * false — сеть не помогла, показано сохранённое расписание, [syncedAtMillis] — когда оно было актуальным.
 */
data class FetchedSchedule(
    val schedule: WeekSchedule,
    val isFresh: Boolean,
    val syncedAtMillis: Long? = null
)

class ScheduleRepository(
    private val apiClient: MvekApiClient,
    private val prefs: PreferencesManager
) {

    @Volatile
    private var cachedGroups: List<Group>? = null
    private val memoryScheduleCache = ConcurrentHashMap<String, WeekSchedule>()
    private val lastSyncTimes = ConcurrentHashMap<String, Long>()

    private fun cacheKey(group: String, skip: Int): String = "group_${group}_skip_$skip"

    suspend fun clearLegacyCacheIfNeeded() = withContext(Dispatchers.IO) {
        prefs.clearLegacyHtmlFromPrefs()
    }

    fun getMemorySchedule(group: String, skip: Int): WeekSchedule? {
        return memoryScheduleCache[cacheKey(group, skip)]
    }

    /** Время (мс) последней успешной сверки расписания с сервером; null — данных нет. */
    fun lastSyncMillis(group: String, skip: Int): Long? {
        val key = cacheKey(group, skip)
        return lastSyncTimes[key] ?: prefs.getParsedScheduleTimestamp(key)
    }

    suspend fun getDiskSchedule(group: String, skip: Int): WeekSchedule? = withContext(Dispatchers.IO) {
        val key = cacheKey(group, skip)
        memoryScheduleCache[key]?.let { return@withContext it }

        // 1. Fast binary parsed cache (~1-2 KB, <1ms, zero regex parsing on cold start)
        prefs.getParsedScheduleBytes(key)?.let { bytes ->
            deserializeWeekSchedule(bytes)?.takeIf { it.days.isNotEmpty() }?.let { parsed ->
                memoryScheduleCache[key] = parsed
                return@withContext parsed
            }
        }

        // 2. Fallback to legacy HTML file cache if binary doesn't exist yet
        val cachedHtml = prefs.getScheduleCache(key) ?: return@withContext null
        val parsed = MvekHtmlParser.parseSchedule(cachedHtml, skip, "Расписание для группы $group")
        if (parsed.days.isNotEmpty()) {
            memoryScheduleCache[key] = parsed
            prefs.saveParsedScheduleBytes(key, serializeWeekSchedule(parsed))
            parsed
        } else {
            null
        }
    }

    suspend fun fetchGroupScheduleFromNetwork(group: String, skip: Int): Result<FetchedSchedule> = withContext(Dispatchers.IO) {
        val key = cacheKey(group, skip)
        val networkResult = apiClient.fetchGroupSchedule(group, skip)
        if (networkResult.isSuccess) {
            val html = networkResult.getOrThrow()

            // Сервер вернул тот же HTML, что и в кэше — разбирать его заново не нужно.
            val existing = memoryScheduleCache[key]
            val previousHtml = if (existing != null) prefs.getScheduleCache(key) else null
            if (existing != null && previousHtml == html) {
                lastSyncTimes[key] = System.currentTimeMillis()
                prefs.touchParsedSchedule(key)
                return@withContext Result.success(FetchedSchedule(existing, isFresh = true, syncedAtMillis = lastSyncTimes[key]))
            }

            val parsed = MvekHtmlParser.parseSchedule(html, skip, "Расписание для группы $group")
            if (parsed.days.isNotEmpty()) {
                prefs.saveScheduleCache(key, html)
                prefs.saveParsedScheduleBytes(key, serializeWeekSchedule(parsed))
                memoryScheduleCache[key] = parsed
                val now = System.currentTimeMillis()
                lastSyncTimes[key] = now
                return@withContext Result.success(FetchedSchedule(parsed, isFresh = true, syncedAtMillis = now))
            }
        }

        // Сеть недоступна или страница не разобралась — показываем сохранённое расписание, если оно есть
        val disk = getDiskSchedule(group, skip)
        if (disk != null) {
            return@withContext Result.success(
                FetchedSchedule(disk, isFresh = false, syncedAtMillis = lastSyncMillis(group, skip))
            )
        }

        // Сайт ответил, но расписания в ответе нет — скорее всего, такой группы не существует
        networkResult.exceptionOrNull()?.let { Result.failure(it) }
            ?: Result.failure(
                IOException("Не удалось найти расписание для группы «$group». Проверьте название группы или попробуйте позже.")
            )
    }

    fun getInstantGroups(): List<Group> {
        return cachedGroups ?: OfflineFallbackData.fallbackGroups
    }

    suspend fun getGroups(forceRefresh: Boolean = false): Result<List<Group>> = withContext(Dispatchers.IO) {
        if (!forceRefresh && cachedGroups != null) {
            return@withContext Result.success(cachedGroups!!)
        }

        val networkResult = apiClient.fetchMainPage()
        if (networkResult.isSuccess) {
            val html = networkResult.getOrThrow()
            val groups = MvekHtmlParser.parseGroups(html)
            if (groups.isNotEmpty()) {
                prefs.saveMainPageCache(html)
                cachedGroups = groups
                return@withContext Result.success(groups)
            }
        }

        val cachedHtml = prefs.getMainPageCache()
        if (cachedHtml != null) {
            val groups = MvekHtmlParser.parseGroups(cachedHtml)
            if (groups.isNotEmpty()) {
                cachedGroups = groups
                return@withContext Result.success(groups)
            }
        }

        cachedGroups = OfflineFallbackData.fallbackGroups
        Result.success(cachedGroups!!)
    }

    private fun serializeWeekSchedule(schedule: WeekSchedule): ByteArray {
        val baos = ByteArrayOutputStream(2048)
        DataOutputStream(baos).use { out ->
            out.writeInt(BINARY_CACHE_VERSION)
            writeString(out, schedule.title)
            writeString(out, schedule.weekRange)
            out.writeInt(schedule.currentSkip)
            out.writeInt(schedule.days.size)
            for (day in schedule.days) {
                writeString(out, day.dayOfWeek)
                writeString(out, day.dayNameFull)
                writeString(out, day.dateString)
                out.writeBoolean(day.isToday)
                out.writeInt(day.lessons.size)
                for (lesson in day.lessons) {
                    out.writeInt(lesson.number)
                    writeString(out, lesson.timeRange)
                    writeString(out, lesson.startTime)
                    writeString(out, lesson.endTime)
                    writeString(out, lesson.subject)
                    writeString(out, lesson.topic)
                    writeString(out, lesson.teacher)
                    writeString(out, lesson.auditorium)
                    writeString(out, lesson.groups)
                    out.writeInt(lesson.lessonType.ordinal)
                }
            }
        }
        return baos.toByteArray()
    }

    private fun deserializeWeekSchedule(bytes: ByteArray): WeekSchedule? {
        return runCatching {
            DataInputStream(ByteArrayInputStream(bytes)).use { input ->
                if (input.readInt() != BINARY_CACHE_VERSION) return@use null
                val title = readString(input)
                val weekRange = readString(input)
                val currentSkip = input.readInt()
                val dayCount = input.readInt()
                val days = ArrayList<DaySchedule>(dayCount.coerceAtLeast(0))
                val lessonTypes = LessonType.entries
                repeat(dayCount) {
                    val dayOfWeek = readString(input)
                    val dayNameFull = readString(input)
                    val dateString = readString(input)
                    val isToday = input.readBoolean()
                    val lessonCount = input.readInt()
                    val lessons = ArrayList<Lesson>(lessonCount.coerceAtLeast(0))
                    repeat(lessonCount) {
                        val number = input.readInt()
                        val timeRange = readString(input)
                        val startTime = readString(input)
                        val endTime = readString(input)
                        val subject = readString(input)
                        val topic = readString(input)
                        val teacher = readString(input)
                        val auditorium = readString(input)
                        val groups = readString(input)
                        val typeOrdinal = input.readInt()
                        val lessonType = lessonTypes.getOrElse(typeOrdinal) { LessonType.OTHER }
                        lessons.add(
                            Lesson(
                                number = number,
                                timeRange = timeRange,
                                startTime = startTime,
                                endTime = endTime,
                                subject = subject,
                                topic = topic,
                                teacher = teacher,
                                auditorium = auditorium,
                                groups = groups,
                                lessonType = lessonType
                            )
                        )
                    }
                    days.add(
                        DaySchedule(
                            dayOfWeek = dayOfWeek,
                            dayNameFull = dayNameFull,
                            dateString = dateString,
                            isToday = isToday,
                            lessons = lessons
                        )
                    )
                }
                WeekSchedule(
                    title = title,
                    weekRange = weekRange,
                    currentSkip = currentSkip,
                    days = days
                )
            }
        }.getOrNull()
    }

    private fun writeString(out: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        out.writeInt(bytes.size)
        out.write(bytes)
    }

    private fun readString(input: DataInputStream): String {
        val len = input.readInt()
        if (len <= 0) return ""
        val buf = ByteArray(len)
        input.readFully(buf)
        return String(buf, Charsets.UTF_8)
    }

    companion object {
        private const val BINARY_CACHE_VERSION = 1
    }
}
