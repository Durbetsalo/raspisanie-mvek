package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.security.MessageDigest

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

class PreferencesManager(context: Context) {

    private val appContext: Context = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("mvek_schedule_prefs", Context.MODE_PRIVATE)
    private val cacheDir: File by lazy {
        File(appContext.cacheDir, "mvek_html_cache").apply { mkdirs() }
    }

    private val _selectedGroup = MutableStateFlow<String?>(prefs.getString(KEY_SELECTED_GROUP, null))
    val selectedGroup: StateFlow<String?> = _selectedGroup.asStateFlow()

    private val _recentGroups = MutableStateFlow<List<String>>(loadRecentGroups())
    val recentGroups: StateFlow<List<String>> = _recentGroups.asStateFlow()

    private val _themeMode = MutableStateFlow(
        try {
            AppThemeMode.valueOf(
                prefs.getString(KEY_THEME_MODE, AppThemeMode.SYSTEM.name) ?: AppThemeMode.SYSTEM.name
            )
        } catch (_: Exception) {
            AppThemeMode.SYSTEM
        }
    )
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    fun setSelectedGroup(group: String) {
        prefs.edit().putString(KEY_SELECTED_GROUP, group).apply()
        _selectedGroup.value = group
        addRecentGroup(group)
    }

    fun clearSelectedGroup() {
        prefs.edit().remove(KEY_SELECTED_GROUP).apply()
        _selectedGroup.value = null
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeMode.value = mode
    }

    private fun addRecentGroup(group: String) {
        val current = _recentGroups.value.toMutableList()
        current.remove(group)
        current.add(0, group)
        val limited = current.take(6)
        prefs.edit().putString(KEY_RECENT_GROUPS, limited.joinToString(",")).apply()
        _recentGroups.value = limited
    }

    private fun loadRecentGroups(): List<String> {
        val raw = prefs.getString(KEY_RECENT_GROUPS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    /**
     * One-time cleanup (must be called off the main thread) to strip huge HTML blobs
     * stored in SharedPreferences by earlier builds.
     */
    fun clearLegacyHtmlFromPrefs() {
        if (prefs.getBoolean(KEY_LEGACY_CACHE_CLEANED, false)) return
        val keysToRemove = prefs.all.keys.filter { it.startsWith("cache_") }
        prefs.edit().apply {
            keysToRemove.forEach { remove(it) }
            putBoolean(KEY_LEGACY_CACHE_CLEANED, true)
        }.apply()
    }

    // File-based HTML & fast binary parsed cache (non-blocking when called on Dispatchers.IO)
    fun saveScheduleCache(key: String, html: String) {
        runCatching {
            cacheFileFor("sched_$key", "html").writeText(html, Charsets.UTF_8)
        }
    }

    fun getScheduleCache(key: String): String? {
        return runCatching {
            val file = cacheFileFor("sched_$key", "html")
            if (file.exists()) file.readText(Charsets.UTF_8) else null
        }.getOrNull()
    }

    fun saveParsedScheduleBytes(key: String, bytes: ByteArray) {
        runCatching {
            cacheFileFor("sched_bin_$key", "bin").writeBytes(bytes)
        }
    }

    fun getParsedScheduleBytes(key: String): ByteArray? {
        return runCatching {
            val file = cacheFileFor("sched_bin_$key", "bin")
            if (file.exists()) file.readBytes() else null
        }.getOrNull()
    }

    /** Когда расписание в кэше последний раз сверялось с сервером (время изменения файла). */
    fun getParsedScheduleTimestamp(key: String): Long? {
        return runCatching {
            val file = cacheFileFor("sched_bin_$key", "bin")
            if (file.exists()) file.lastModified().takeIf { it > 0L } else null
        }.getOrNull()
    }

    /** Отмечает кэш как свежий, не переписывая файл (сервер вернул тот же HTML). */
    fun touchParsedSchedule(key: String) {
        runCatching {
            val file = cacheFileFor("sched_bin_$key", "bin")
            if (file.exists()) file.setLastModified(System.currentTimeMillis())
        }
    }

    fun saveMainPageCache(html: String) {
        runCatching {
            cacheFileFor("main_page", "html").writeText(html, Charsets.UTF_8)
        }
    }

    fun getMainPageCache(): String? {
        return runCatching {
            val file = cacheFileFor("main_page", "html")
            if (file.exists()) file.readText(Charsets.UTF_8) else null
        }.getOrNull()
    }

    private fun cacheFileFor(rawKey: String, ext: String): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(rawKey.toByteArray(Charsets.UTF_8))
        val hexChars = CharArray(digest.size * 2)
        for (i in digest.indices) {
            val v = digest[i].toInt() and 0xFF
            hexChars[i * 2] = HEX_ARRAY[v ushr 4]
            hexChars[i * 2 + 1] = HEX_ARRAY[v and 0x0F]
        }
        return File(cacheDir, "${String(hexChars)}.$ext")
    }

    companion object {
        private val HEX_ARRAY = "0123456789abcdef".toCharArray()
        private const val KEY_SELECTED_GROUP = "selected_group"
        private const val KEY_RECENT_GROUPS = "recent_groups"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_LEGACY_CACHE_CLEANED = "legacy_html_cache_cleaned_v1"
    }
}
