package com.example.data.parser

import com.example.data.model.DaySchedule
import com.example.data.model.Group
import com.example.data.model.Lesson
import com.example.data.model.RoomOccupancy
import com.example.data.model.RoomSlot
import com.example.data.model.Teacher
import com.example.data.model.WeekSchedule
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.regex.Pattern

object MvekHtmlParser {

    // Precompiled Regex & Pattern constants (avoids compiling patterns inside parsing loops)
    private val HTML_TAG_REGEX = Regex("<[^>]+>")
    private val WHITESPACE_REGEX = Regex("\\s+")
    private val WRAP_SPLIT_REGEX = Regex("""<div\s+class=["']lessons_wrap["']\s+id=["']""")
    private val LESSON_BLOCK_SPLIT_REGEX = Regex("""<div\s+class=["']lesson_block["'][^>]*>""")

    private val GROUP_LINK_PATTERN = Pattern.compile(
        """href=["']/schedule/table\?group=([^"'&]+)["'][^>]*>(.*?)</a>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val SPECIALTY_PATTERN = Pattern.compile("""specialty-([a-zA-Z0-9_\-]+)""")
    private val TEACHER_LINK_PATTERN = Pattern.compile(
        """href=["']/schedule/table\?teacher=([^"'&]+)&(?:amp;)?teacher_id=([^"'&]+)["'][^>]*>(.*?)</a>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val H1_PATTERN = Pattern.compile("""<h1>(.*?)</h1>""", Pattern.CASE_INSENSITIVE)
    private val SCHEDULE_NAV_PATTERN = Pattern.compile(
        """<div class=["']schedule-nav["'][^>]*>(.*?)</div>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val DATE_AND_WDAY_PATTERN = Pattern.compile(
        """<div class=["']date_and_wday["'][^>]*>\s*<div class=["']day_of_the_week["']>(.*?)</div>.*?<label[^>]*class=["']single_date["']>(.*?)</label>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val LESSON_TITLE_PATTERN = Pattern.compile(
        """<b class=["']lesson_title["'][^>]*>(\d+)\s*пара,?(.*?)</b>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val TABLE_ROW_PAIR_PATTERN = Pattern.compile(
        """<tr[^>]*>\s*<th[^>]*>(.*?)</th>\s*<td[^>]*>(.*?)</td>\s*</tr>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val TEACHER_DIV_PATTERN = Pattern.compile(
        """<div class=["']teacher["'][^>]*>(.*?)</div>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val DESKTOP_TABLE_PATTERN = Pattern.compile(
        """<table[^>]*class=["']crud["'][^>]*>(.*?)</table>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val GENERIC_TR_PATTERN = Pattern.compile(
        """<tr[^>]*>(.*?)</tr>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val GENERIC_CELL_PATTERN = Pattern.compile(
        """<t[dh][^>]*>(.*?)</t[dh]>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )
    private val DAY_HEADER_PATTERN = Pattern.compile(
        """(Понедельник|Вторник|Среда|Четверг|Пятница|Суббота|Воскресенье)\s*(\d{2}\.\d{2})?""",
        Pattern.CASE_INSENSITIVE
    )
    private val ROOM_HEADER_PATTERN = Pattern.compile(
        """<th[^>]*data-room=["']([^"']+)["'][^>]*>""",
        Pattern.CASE_INSENSITIVE
    )
    private val ROOM_TABLE_PATTERN = Pattern.compile(
        """<table id=["']roomOccupancyTable["'][^>]*>(.*?)</table>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )

    private val ENTITY_REGEX = Regex("&(#[xX][0-9a-fA-F]+|#\\d+|[a-zA-Z]+);")
    private val NAMED_ENTITIES = mapOf(
        "mdash" to "—", "ndash" to "–", "nbsp" to " ", "quot" to "\"", "apos" to "'",
        "laquo" to "«", "raquo" to "»", "hellip" to "…", "lt" to "<", "gt" to ">", "amp" to "&"
    )

    /** Декодирует HTML-сущности за один проход: «&amp;lt;» остаётся «&lt;», а не превращается в «<». */
    private fun decodeEntities(text: String): String =
        ENTITY_REGEX.replace(text) { m ->
            val body = m.groupValues[1]
            val codePoint = when {
                body.startsWith("#x") || body.startsWith("#X") -> body.substring(2).toIntOrNull(16)
                body.startsWith("#") -> body.substring(1).toIntOrNull()
                else -> return@replace NAMED_ENTITIES[body] ?: m.value
            }
            if (codePoint == null || codePoint !in 1..0x10FFFF || codePoint in 0xD800..0xDFFF) m.value
            else String(Character.toChars(codePoint))
        }

    private fun cleanHtml(text: String): String {
        if (text.isEmpty()) return ""
        var result = text
        // Сначала убираем теги, и только потом декодируем сущности — иначе «&lt;b&gt;» был бы принят за тег.
        if (result.indexOf('<') != -1) {
            result = result.replace(HTML_TAG_REGEX, " ")
        }
        if (result.indexOf('&') != -1) {
            result = decodeEntities(result)
        }
        return result.replace('\u00A0', ' ').replace(WHITESPACE_REGEX, " ").trim()
    }

    private fun decodeUrl(url: String): String {
        return try {
            URLDecoder.decode(url, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            url
        }
    }

    fun parseGroups(html: String): List<Group> {
        val groups = mutableListOf<Group>()
        val seen = mutableSetOf<String>()

        val matcher = GROUP_LINK_PATTERN.matcher(html)
        while (matcher.find()) {
            val rawName = matcher.group(1)?.let { decodeUrl(it) }?.trim() ?: continue
            val innerHtml = matcher.group(2) ?: ""

            val specMatcher = SPECIALTY_PATTERN.matcher(innerHtml)
            val specCode = if (specMatcher.find()) specMatcher.group(1) ?: "" else ""

            val displayName = cleanHtml(innerHtml).ifEmpty { rawName }
            if (displayName.isNotEmpty() && seen.add(displayName)) {
                groups.add(Group(name = displayName, specialtyCode = specCode))
            }
        }

        return groups.sortedBy { it.name }
    }

    fun parseTeachers(html: String): List<Teacher> {
        val teachers = mutableListOf<Teacher>()
        val seen = mutableSetOf<String>()

        val matcher = TEACHER_LINK_PATTERN.matcher(html)
        while (matcher.find()) {
            val nameRaw = matcher.group(1) ?: continue
            val id = matcher.group(2) ?: continue
            val innerHtml = matcher.group(3) ?: ""
            val cleanInner = cleanHtml(innerHtml)
            val name = if (cleanInner.isNotBlank()) cleanInner else cleanHtml(decodeUrl(nameRaw))

            if (name.isNotEmpty() && seen.add(name)) {
                teachers.add(Teacher(id = id.trim(), name = name))
            }
        }

        return teachers.sortedBy { it.name }
    }

    fun parseSchedule(html: String, skip: Int, defaultTitle: String = ""): WeekSchedule {
        var title = defaultTitle
        val titleMatcher = H1_PATTERN.matcher(html)
        if (titleMatcher.find()) {
            title = cleanHtml(titleMatcher.group(1) ?: "")
        }

        var weekRange = ""
        val navMatcher = SCHEDULE_NAV_PATTERN.matcher(html)
        if (navMatcher.find()) {
            val navText = cleanHtml(navMatcher.group(1) ?: "")
            weekRange = navText.replace("<", "").replace(">", "").trim()
        }

        val days = mutableListOf<DaySchedule>()

        // 1. Parse dates header: <div class="date_and_wday">
        val dateItems = mutableListOf<Triple<String, String, Boolean>>()
        val dMatcher = DATE_AND_WDAY_PATTERN.matcher(html)
        while (dMatcher.find()) {
            val dow = cleanHtml(dMatcher.group(1) ?: "")
            val dt = cleanHtml(dMatcher.group(2) ?: "")
            val marker = """id="date$dt""""
            val idx = html.indexOf(marker)
            val isToday = if (idx != -1) {
                val closeTag = html.indexOf('>', idx)
                closeTag != -1 && html.substring(idx, closeTag).contains("checked")
            } else false
            dateItems.add(Triple(dow, dt, isToday))
        }

        // 2. Parse lessons per date wrap by splitting on <div class="lessons_wrap" id="
        val dateLessonsMap = mutableMapOf<String, MutableList<Lesson>>()
        val lastWrapIdx = html.lastIndexOf("lessons_wrap")
        val scriptAfterWrap = if (lastWrapIdx != -1) html.indexOf("<script", startIndex = lastWrapIdx) else -1
        val mobileHtml = if (scriptAfterWrap > lastWrapIdx) html.substring(0, scriptAfterWrap) else html
        val wrapSplits = mobileHtml.split(WRAP_SPLIT_REGEX)
        val isGroupSchedule = title.contains("групп", ignoreCase = true)

        for (i in 1 until wrapSplits.size) {
            val part = wrapSplits[i]
            val quoteIdx = part.indexOf('"')
            if (quoteIdx == -1) continue
            val dateId = part.substring(0, quoteIdx).trim()
            val wrapContent = part.substring(quoteIdx + 1)

            val lessonList = mutableListOf<Lesson>()
            val blocks = wrapContent.split(LESSON_BLOCK_SPLIT_REGEX)

            for (bIdx in 1 until blocks.size) {
                val block = blocks[bIdx]

                var pairNum = 1
                var auditorium = ""
                val titlePat = LESSON_TITLE_PATTERN.matcher(block)
                if (titlePat.find()) {
                    pairNum = titlePat.group(1)?.toIntOrNull() ?: 1
                    val audPart = cleanHtml(titlePat.group(2) ?: "")
                    auditorium = audPart.replace("Ауд.", "").trim()
                }

                var timeRange = ""
                var startTime = ""
                var endTime = ""
                var subject = ""
                var topic = ""

                val rowMatcher = TABLE_ROW_PAIR_PATTERN.matcher(block)
                while (rowMatcher.find()) {
                    val th = cleanHtml(rowMatcher.group(1) ?: "").lowercase()
                    val td = cleanHtml(rowMatcher.group(2) ?: "")
                    when {
                        th.contains("время") -> {
                            timeRange = td
                            val parts = td.split("—", "-", "–")
                            if (parts.size == 2) {
                                startTime = parts[0].trim()
                                endTime = parts[1].trim()
                            }
                        }
                        th.contains("предмет") -> subject = td
                        th.contains("тема") -> topic = td
                    }
                }

                var teacherOrGroups = ""
                val teacherMatcher = TEACHER_DIV_PATTERN.matcher(block)
                if (teacherMatcher.find()) {
                    teacherOrGroups = cleanHtml(teacherMatcher.group(1) ?: "")
                }

                if (subject.isNotEmpty() || auditorium.isNotEmpty() || teacherOrGroups.isNotEmpty()) {
                    val lessonType = Lesson.detectLessonType(subject, topic)
                    lessonList.add(
                        Lesson(
                            number = pairNum,
                            timeRange = timeRange,
                            startTime = startTime,
                            endTime = endTime,
                            subject = subject,
                            topic = topic,
                            teacher = if (isGroupSchedule) teacherOrGroups else "",
                            groups = if (isGroupSchedule) "" else teacherOrGroups,
                            auditorium = auditorium,
                            lessonType = lessonType
                        )
                    )
                }
            }
            dateLessonsMap[dateId] = lessonList
        }

        for (item in dateItems) {
            val dow = item.first
            val dt = item.second
            val isToday = item.third
            val fullDow = when (dow) {
                "Пн" -> "Понедельник"
                "Вт" -> "Вторник"
                "Ср" -> "Среда"
                "Чт" -> "Четверг"
                "Пт" -> "Пятница"
                "Сб" -> "Суббота"
                "Вс" -> "Воскресенье"
                else -> dow
            }
            val lessons = dateLessonsMap[dt]?.sortedBy { it.number } ?: emptyList()
            days.add(
                DaySchedule(
                    dayOfWeek = dow,
                    dayNameFull = fullDow,
                    dateString = dt,
                    isToday = isToday,
                    lessons = lessons
                )
            )
        }

        // Fallback to desktop table if needed
        if (days.isEmpty()) {
            val desktopDays = parseDesktopScheduleTable(html, title)
            days.addAll(desktopDays)
        }

        val filteredDays = days.filterNot {
            it.dayOfWeek.equals("Вс", ignoreCase = true) ||
                it.dayNameFull.equals("Воскресенье", ignoreCase = true)
        }

        return WeekSchedule(
            title = title,
            weekRange = weekRange,
            currentSkip = skip,
            days = filteredDays
        )
    }

    private fun parseDesktopScheduleTable(html: String, title: String): List<DaySchedule> {
        val days = mutableListOf<DaySchedule>()
        val tableMatcher = DESKTOP_TABLE_PATTERN.matcher(html)
        if (!tableMatcher.find()) return days

        val tableContent = tableMatcher.group(1) ?: ""
        val rowMatcher = GENERIC_TR_PATTERN.matcher(tableContent)
        val isGroupSchedule = title.contains("групп", ignoreCase = true)

        var currentDayName = ""
        var currentDateStr = ""
        var currentLessons = mutableListOf<Lesson>()

        while (rowMatcher.find()) {
            val row = rowMatcher.group(1) ?: continue
            val cells = mutableListOf<String>()
            val cellMatcher = GENERIC_CELL_PATTERN.matcher(row)
            while (cellMatcher.find()) {
                cells.add(cleanHtml(cellMatcher.group(1) ?: ""))
            }

            if (cells.isEmpty()) continue

            val firstCell = cells[0]
            val dayHeaderMatch = DAY_HEADER_PATTERN.matcher(firstCell)
            if (dayHeaderMatch.find()) {
                if (currentDayName.isNotEmpty()) {
                    days.add(
                        DaySchedule(
                            dayOfWeek = currentDayName.take(2),
                            dayNameFull = currentDayName,
                            dateString = currentDateStr,
                            lessons = currentLessons
                        )
                    )
                    currentLessons = mutableListOf()
                }
                currentDayName = dayHeaderMatch.group(1) ?: ""
                currentDateStr = dayHeaderMatch.group(2) ?: ""
            }

            val pairNumIndex = cells.indexOfFirst { it.toIntOrNull() in 1..10 }
            if (pairNumIndex != -1 && pairNumIndex + 1 < cells.size) {
                val pairNum = cells[pairNumIndex].toIntOrNull() ?: 1
                val timeRange = cells.getOrNull(pairNumIndex + 1) ?: ""
                val subject = cells.getOrNull(pairNumIndex + 2) ?: ""
                val topic = cells.getOrNull(pairNumIndex + 3) ?: ""
                val teacherOrGroup = cells.getOrNull(pairNumIndex + 4) ?: ""
                val aud = cells.getOrNull(pairNumIndex + 5) ?: ""

                if (subject.isNotEmpty() || aud.isNotEmpty()) {
                    val parts = timeRange.split("—", "-", "–")
                    val startTime = if (parts.size == 2) parts[0].trim() else ""
                    val endTime = if (parts.size == 2) parts[1].trim() else ""
                    val lessonType = Lesson.detectLessonType(subject, topic)

                    currentLessons.add(
                        Lesson(
                            number = pairNum,
                            timeRange = timeRange,
                            startTime = startTime,
                            endTime = endTime,
                            subject = subject,
                            topic = topic,
                            teacher = if (isGroupSchedule) teacherOrGroup else "",
                            groups = if (isGroupSchedule) "" else teacherOrGroup,
                            auditorium = aud,
                            lessonType = lessonType
                        )
                    )
                }
            }
        }

        if (currentDayName.isNotEmpty()) {
            days.add(
                DaySchedule(
                    dayOfWeek = currentDayName.take(2),
                    dayNameFull = currentDayName,
                    dateString = currentDateStr,
                    lessons = currentLessons
                )
            )
        }

        return days
    }

    fun parseClassroomOccupancy(html: String): List<RoomOccupancy> {
        val result = mutableListOf<RoomOccupancy>()

        val roomHeaders = mutableListOf<String>()
        val headerMatcher = ROOM_HEADER_PATTERN.matcher(html)

        while (headerMatcher.find()) {
            val room = headerMatcher.group(1)?.trim() ?: continue
            roomHeaders.add(room)
        }

        if (roomHeaders.isEmpty()) return emptyList()

        val roomMap = mutableMapOf<String, MutableMap<String, MutableList<RoomSlot>>>()
        for (r in roomHeaders) {
            roomMap[r] = mutableMapOf()
        }

        val tableMatcher = ROOM_TABLE_PATTERN.matcher(html)
        if (!tableMatcher.find()) return emptyList()

        val tableBody = tableMatcher.group(1) ?: ""
        val rowMatcher = GENERIC_TR_PATTERN.matcher(tableBody)

        var currentDay = "Понедельник"
        var currentDateStr = ""

        while (rowMatcher.find()) {
            val rowContent = rowMatcher.group(1) ?: continue
            val cells = mutableListOf<String>()
            val cellMatcher = GENERIC_CELL_PATTERN.matcher(rowContent)
            while (cellMatcher.find()) {
                cells.add(cleanHtml(cellMatcher.group(1) ?: ""))
            }

            if (cells.isEmpty()) continue

            val dayCheck = DAY_HEADER_PATTERN.matcher(cells[0])
            if (dayCheck.find()) {
                currentDay = dayCheck.group(1) ?: "Понедельник"
                currentDateStr = dayCheck.group(2) ?: ""
                continue
            }

            val pairNum = cells.getOrNull(0)?.toIntOrNull()
            if (pairNum != null && cells.size >= 2) {
                val timeRange = cells.getOrNull(1) ?: ""
                val roomCells = cells.drop(2)

                for (i in roomCells.indices) {
                    if (i < roomHeaders.size) {
                        val room = roomHeaders[i]
                        val info = roomCells[i].trim()
                        val isOccupied = info.isNotEmpty() && info != "№" && info != "Время"

                        val slot = RoomSlot(
                            lessonNumber = pairNum,
                            timeRange = timeRange,
                            info = info,
                            isOccupied = isOccupied
                        )
                        val dayMap = roomMap[room] ?: mutableMapOf()
                        val list = dayMap.getOrPut("$currentDay $currentDateStr".trim()) { mutableListOf() }
                        list.add(slot)
                    }
                }
            }
        }

        for (room in roomHeaders) {
            val dayMap = roomMap[room] ?: continue
            for ((dayDate, slots) in dayMap) {
                val dayParts = dayDate.split(" ")
                val dName = dayParts.firstOrNull() ?: dayDate
                val dDate = if (dayParts.size > 1) dayParts[1] else ""
                result.add(
                    RoomOccupancy(
                        roomNumber = room,
                        dayName = dName,
                        dateStr = dDate,
                        slots = slots
                    )
                )
            }
        }

        return result
    }
}
