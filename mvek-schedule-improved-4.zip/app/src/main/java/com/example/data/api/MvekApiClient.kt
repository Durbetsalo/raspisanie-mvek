package com.example.data.api

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.net.UnknownHostException
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Сервер ответил кодом ошибки; [code] позволяет отличить, например, «не найдено» (404) от сбоя сети. */
class HttpException(val code: Int, message: String) : IOException(message)

class MvekApiClient(
    clientOverride: OkHttpClient? = null
) {
    private val client: OkHttpClient = clientOverride ?: sharedClient

    companion object {
        const val BASE_URL = "https://timeo.mveu.ru"
        private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14; MVEK-Schedule/1.0)"
        private const val HTML_ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        private const val JSON_ACCEPT = "application/vnd.github+json, application/json;q=0.9"
        private const val MAX_ATTEMPTS = 2
        private const val RETRY_DELAY_MS = 400L

        // Один клиент на всё приложение: общий пул соединений и кэш TLS-сессий
        // ускоряют повторные запросы (текущая неделя + предзагрузка следующей).
        private val sharedClient: OkHttpClient by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
            OkHttpClient.Builder()
                .connectTimeout(12, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .callTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()
        }
    }

    private fun urlEncode(value: String): String {
        return try {
            URLEncoder.encode(value, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            value
        }
    }

    /**
     * Выполняет запрос так, чтобы он честно отменялся вместе с корутиной: если пользователь
     * переключил неделю или группу, старый запрос обрывается, а не докачивается впустую.
     */
    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { runCatching { cancel() } }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }

    private class RetryableFailure(message: String, cause: Throwable? = null) : IOException(message, cause)

    private suspend fun executeOnce(url: String, accept: String): Result<String> {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", accept)
            .header("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7")
            .build()

        return try {
            client.newCall(request).await().use { response ->
                // Чтение тела блокирующее — executeOnce вызывается из Dispatchers.IO (см. getHtml).
                val body = response.body?.string() ?: ""

                // Примечание: timeo.mveu.ru иногда отвечает HTTP 500 на classroomoccupancy,
                // но тело при этом содержит полную валидную таблицу.
                when {
                    response.isSuccessful || (response.code == 500 && body.contains("roomOccupancyTable")) ->
                        Result.success(body)
                    response.code in 502..504 ->
                        Result.failure(RetryableFailure("Сервер расписания временно недоступен (код ${response.code})"))
                    else ->
                        Result.failure(HttpException(response.code, "Ошибка сервера: код ${response.code}"))
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(IOException("Нет подключения к интернету или не удаётся найти сервер расписания", e))
        } catch (e: SocketTimeoutException) {
            Result.failure(RetryableFailure("Сервер расписания слишком долго отвечает", e))
        } catch (e: Exception) {
            Result.failure(RetryableFailure("Не удалось связаться с сервером расписания: ${e.localizedMessage ?: "ошибка сети"}", e))
        }
    }

    suspend fun getHtml(pathAndQuery: String): Result<String> {
        val url = if (pathAndQuery.startsWith("http")) pathAndQuery else "$BASE_URL$pathAndQuery"
        return getWithRetry(url, HTML_ACCEPT)
    }

    /** GET-запрос к JSON API (используется для проверки обновлений на GitHub). */
    suspend fun getJson(url: String): Result<String> = getWithRetry(url, JSON_ACCEPT)

    private suspend fun getWithRetry(url: String, accept: String): Result<String> {
        var result: Result<String> = Result.failure(IOException("Запрос не выполнен"))
        for (attempt in 1..MAX_ATTEMPTS) {
            result = withContext(Dispatchers.IO) { executeOnce(url, accept) }
            val error = result.exceptionOrNull()
            // Повторяем только временные сбои; «нет интернета» и 4xx повторять бессмысленно.
            if (error !is RetryableFailure || attempt == MAX_ATTEMPTS) break
            delay(RETRY_DELAY_MS)
        }
        return result
    }

    /**
     * Скачивает файл потоком во временный `.part`, сообщая прогресс, и только после полной загрузки
     * переименовывает в [target]. Для больших файлов общий таймаут запроса отключён (остаётся
     * таймаут простоя 30 с), загрузка отменяется вместе с корутиной.
     */
    suspend fun download(
        url: String,
        target: File,
        onProgress: (downloaded: Long, total: Long) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val part = File(target.parentFile, target.name + ".part")
        try {
            val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).build()
            val downloadClient = client.newBuilder()
                .callTimeout(0, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()
            downloadClient.newCall(request).await().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(HttpException(response.code, "Ошибка сервера: код ${response.code}"))
                }
                val body = response.body
                    ?: return@withContext Result.failure(IOException("Сервер вернул пустой ответ"))
                val total = body.contentLength()
                body.byteStream().use { input ->
                    part.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024)
                        var downloaded = 0L
                        while (true) {
                            ensureActive()
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            onProgress(downloaded, total)
                        }
                    }
                }
            }
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) {
                part.delete()
                return@withContext Result.failure(IOException("Не удалось сохранить файл обновления"))
            }
            Result.success(target)
        } catch (e: CancellationException) {
            part.delete()
            throw e
        } catch (e: Exception) {
            part.delete()
            Result.failure(IOException("Не удалось скачать обновление: ${e.localizedMessage ?: "ошибка сети"}", e))
        }
    }

    suspend fun fetchMainPage(): Result<String> {
        return getHtml("/")
    }

    suspend fun fetchGroupSchedule(group: String, skip: Int = 0): Result<String> {
        val encodedGroup = urlEncode(group)
        val path = if (skip != 0) {
            "/schedule/table?group=$encodedGroup&skip=$skip"
        } else {
            "/schedule/table?group=$encodedGroup"
        }
        return getHtml(path)
    }

    suspend fun fetchTeacherSchedule(teacher: String, teacherId: String, skip: Int = 0): Result<String> {
        val encodedTeacher = urlEncode(teacher)
        val encodedId = urlEncode(teacherId)
        val path = if (skip != 0) {
            "/schedule/table?teacher=$encodedTeacher&teacher_id=$encodedId&skip=$skip"
        } else {
            "/schedule/table?teacher=$encodedTeacher&teacher_id=$encodedId"
        }
        return getHtml(path)
    }

    suspend fun fetchClassroomsOccupancy(skip: Int = 0): Result<String> {
        val path = if (skip != 0) {
            "/schedule/classroomoccupancy?skip=$skip"
        } else {
            "/schedule/classroomoccupancy"
        }
        return getHtml(path)
    }
}
