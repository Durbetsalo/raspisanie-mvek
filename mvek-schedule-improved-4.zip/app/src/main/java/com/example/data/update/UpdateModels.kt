package com.example.data.update

import java.util.Locale

// ---------------------------------------------------------------------------------------------
// Чистая логика обновлений (без Android): разбор ответа GitHub, сравнение версий, проверка адреса.
// ---------------------------------------------------------------------------------------------

data class UpdateInfo(
    /** Версия без префикса «v»: "1.2". */
    val versionName: String,
    val tag: String,
    val notes: String,
    val apkUrl: String,
    /** Размер APK в байтах или -1, если неизвестен. */
    val sizeBytes: Long
)

/** Минимальный разборщик JSON: хватает для ответа GitHub и не тянет лишних библиотек. */
object MiniJson {

    private const val MAX_DEPTH = 64

    /** Возвращает Map / List / String / Double / Boolean / null; при ошибке бросает IllegalArgumentException. */
    fun parse(text: String): Any? {
        val reader = Reader(text)
        val value = reader.readValue(0)
        reader.skipWhitespace()
        if (!reader.atEnd()) throw IllegalArgumentException("Лишние данные после JSON")
        return value
    }

    private class Reader(private val s: String) {
        private var i = 0

        fun atEnd() = i >= s.length

        fun skipWhitespace() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        private fun peek(): Char {
            if (atEnd()) throw IllegalArgumentException("Неожиданный конец JSON")
            return s[i]
        }

        private fun next(): Char {
            val c = peek()
            i++
            return c
        }

        private fun expect(c: Char) {
            if (next() != c) throw IllegalArgumentException("Ожидался символ '$c' перед позицией $i")
        }

        fun readValue(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw IllegalArgumentException("Слишком глубокая вложенность")
            skipWhitespace()
            return when (val c = peek()) {
                '{' -> readObject(depth)
                '[' -> readArray(depth)
                '"' -> readString()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (c == '-' || c.isDigit()) readNumber()
                else throw IllegalArgumentException("Неожиданный символ '$c' на позиции $i")
            }
        }

        private fun literal(word: String, value: Any?): Any? {
            if (!s.startsWith(word, i)) throw IllegalArgumentException("Ожидалось '$word' на позиции $i")
            i += word.length
            return value
        }

        private fun readObject(depth: Int): Map<String, Any?> {
            expect('{')
            val map = LinkedHashMap<String, Any?>()
            skipWhitespace()
            if (peek() == '}') {
                i++
                return map
            }
            while (true) {
                skipWhitespace()
                val key = readString()
                skipWhitespace()
                expect(':')
                map[key] = readValue(depth + 1)
                skipWhitespace()
                when (val c = next()) {
                    ',' -> continue
                    '}' -> return map
                    else -> throw IllegalArgumentException("Неожиданный символ '$c' в объекте")
                }
            }
        }

        private fun readArray(depth: Int): List<Any?> {
            expect('[')
            val list = ArrayList<Any?>()
            skipWhitespace()
            if (peek() == ']') {
                i++
                return list
            }
            while (true) {
                list.add(readValue(depth + 1))
                skipWhitespace()
                when (val c = next()) {
                    ',' -> continue
                    ']' -> return list
                    else -> throw IllegalArgumentException("Неожиданный символ '$c' в массиве")
                }
            }
        }

        private fun readString(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                when (val c = next()) {
                    '"' -> return sb.toString()
                    '\\' -> when (val e = next()) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> {
                            if (i + 4 > s.length) throw IllegalArgumentException("Обрезанная escape-последовательность")
                            val code = s.substring(i, i + 4).toIntOrNull(16)
                                ?: throw IllegalArgumentException("Неверная escape-последовательность")
                            sb.append(code.toChar())
                            i += 4
                        }
                        else -> throw IllegalArgumentException("Неизвестная escape-последовательность '\\$e'")
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun readNumber(): Double {
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            return s.substring(start, i).toDoubleOrNull()
                ?: throw IllegalArgumentException("Неверное число на позиции $start")
        }
    }
}

object VersionComparator {

    private val NUMBER = Regex("""\d+""")

    /** «v1.2» -> «1.2». */
    fun normalize(tag: String): String = tag.trim().removePrefix("v").removePrefix("V").trim()

    fun parts(version: String): List<Int> =
        NUMBER.findAll(normalize(version)).map { it.value.toIntOrNull() ?: 0 }.toList()

    /** true, если [remote] строго новее [local]: числа сравниваются по частям, «1.10» новее «1.9». */
    fun isNewer(remote: String, local: String): Boolean {
        val r = parts(remote)
        val l = parts(local)
        if (r.isEmpty()) return false
        val size = maxOf(r.size, l.size)
        for (idx in 0 until size) {
            val a = r.getOrElse(idx) { 0 }
            val b = l.getOrElse(idx) { 0 }
            if (a != b) return a > b
        }
        return false
    }
}

object UpdatePolicy {

    /** Скачивать APK разрешаем только по HTTPS и только с GitHub. */
    fun isTrustedApkUrl(url: String): Boolean {
        if (!url.startsWith("https://")) return false
        val authority = url.removePrefix("https://").substringBefore('/').substringBefore('?').substringBefore('#')
        if (authority.contains('@')) return false
        val host = authority.substringBefore(':').lowercase()
        return host == "github.com" || host.endsWith(".github.com") ||
            host == "githubusercontent.com" || host.endsWith(".githubusercontent.com")
    }
}

object UpdateFormat {

    /** 6 543 210 -> «6,2 МБ»; для неизвестного размера — пустая строка. */
    fun size(bytes: Long): String {
        if (bytes <= 0) return ""
        return String.format(Locale.forLanguageTag("ru"), "%.1f МБ", bytes / 1_048_576.0)
    }

    /** Описание релиза из Markdown в читаемый текст: маркеры списков -> «•», убираем **, #, `. */
    fun notes(body: String, maxLength: Int = 700): String {
        val lines = body.replace("\r\n", "\n").lines().map { raw ->
            raw.trim()
                .replace(Regex("^#{1,6}\\s*"), "")
                .replace(Regex("^[-*+]\\s+"), "• ")
                .replace("**", "")
                .replace("__", "")
                .replace("`", "")
        }
        var text = lines.joinToString("\n").replace(Regex("\n{3,}"), "\n\n").trim()
        if (text.length > maxLength) text = text.take(maxLength).trimEnd() + "…"
        return text
    }
}

object GithubReleaseParser {

    /**
     * Разбирает ответ `GET /repos/{owner}/{repo}/releases/latest`. Возвращает null, если релиз —
     * черновик или пред-релиз, в нём нет тега или нет APK-файла.
     */
    fun parse(json: String): UpdateInfo? {
        val root = try {
            asObject(MiniJson.parse(json))
        } catch (_: IllegalArgumentException) {
            null
        } ?: return null

        if (root["draft"] == true || root["prerelease"] == true) return null
        val tag = (root["tag_name"] as? String)?.trim().orEmpty()
        if (tag.isEmpty()) return null

        val apkAssets = (root["assets"] as? List<*>).orEmpty()
            .mapNotNull { asObject(it) }
            .filter { (it["name"] as? String)?.endsWith(".apk", ignoreCase = true) == true }
        val apk = apkAssets.firstOrNull { (it["name"] as String).contains("release", ignoreCase = true) }
            ?: apkAssets.firstOrNull()
            ?: return null

        val url = apk["browser_download_url"] as? String ?: return null
        val size = (apk["size"] as? Number)?.toLong() ?: -1L
        return UpdateInfo(
            versionName = VersionComparator.normalize(tag),
            tag = tag,
            notes = UpdateFormat.notes(root["body"] as? String ?: ""),
            apkUrl = url,
            sizeBytes = size
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun asObject(value: Any?): Map<String, Any?>? = value as? Map<String, Any?>
}
