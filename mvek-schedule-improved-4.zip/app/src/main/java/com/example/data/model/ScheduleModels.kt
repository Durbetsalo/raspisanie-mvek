package com.example.data.model

import androidx.compose.runtime.Immutable
import java.util.Calendar

enum class LessonType(val displayName: String) {
    LECTURE("Лекция"),
    PRACTICE("Практика"),
    LAB("Лабораторная"),
    SEMINAR("Семинар"),
    EXAM("Экзамен"),
    CREDIT("Зачет"),
    CONSULTATION("Консультация"),
    OTHER("Занятие")
}

enum class LessonTimeStatus {
    ONGOING,
    UPCOMING,
    FINISHED
}

@Immutable
data class Lesson(
    val number: Int,
    val timeRange: String,
    val startTime: String,
    val endTime: String,
    val subject: String,
    val topic: String = "",
    val teacher: String = "",
    val auditorium: String = "",
    val groups: String = "",
    val lessonType: LessonType = LessonType.OTHER
) {
    // Precomputed once at parse time to avoid repeated String.split(":") during Compose scrolling
    val startMinutes: Int? = parseTimeToMinutes(startTime)
    val endMinutes: Int? = parseTimeToMinutes(endTime)

    fun getTimeStatus(currentTimeMinutes: Int): LessonTimeStatus {
        val startM = startMinutes ?: return LessonTimeStatus.UPCOMING
        val endM = endMinutes ?: return LessonTimeStatus.UPCOMING

        return when {
            currentTimeMinutes < startM -> LessonTimeStatus.UPCOMING
            currentTimeMinutes in startM..endM -> LessonTimeStatus.ONGOING
            else -> LessonTimeStatus.FINISHED
        }
    }

    fun getProgressFraction(currentTimeMinutes: Int): Float {
        val startM = startMinutes ?: return 0f
        val endM = endMinutes ?: return 0f
        if (endM <= startM) return 0f
        if (currentTimeMinutes <= startM) return 0f
        if (currentTimeMinutes >= endM) return 1f
        return (currentTimeMinutes - startM).toFloat() / (endM - startM).toFloat()
    }

    fun getRemainingMinutes(currentTimeMinutes: Int): Int {
        val endM = endMinutes ?: return 0
        return (endM - currentTimeMinutes).coerceAtLeast(0)
    }

    companion object {
        fun parseTimeToMinutes(timeStr: String): Int? {
            val trimmed = timeStr.trim()
            val colonIdx = trimmed.indexOf(':')
            if (colonIdx <= 0 || colonIdx >= trimmed.length - 1) return null
            val h = trimmed.substring(0, colonIdx).toIntOrNull() ?: return null
            val m = trimmed.substring(colonIdx + 1).toIntOrNull() ?: return null
            return h * 60 + m
        }

        fun detectLessonType(subject: String, topic: String): LessonType {
            val combined = "$subject $topic".lowercase()
            return when {
                combined.contains("лекци") -> LessonType.LECTURE
                combined.contains("практ") -> LessonType.PRACTICE
                combined.contains("лабор") -> LessonType.LAB
                combined.contains("семин") -> LessonType.SEMINAR
                combined.contains("экзам") -> LessonType.EXAM
                combined.contains("зачет") || combined.contains("зачёт") -> LessonType.CREDIT
                combined.contains("консульт") -> LessonType.CONSULTATION
                else -> LessonType.OTHER
            }
        }
    }
}

@Immutable
data class DaySchedule(
    val dayOfWeek: String,       // "Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"
    val dayNameFull: String,     // "Понедельник", "Вторник"...
    val dateString: String,      // "09.11", "10.11", etc.
    val isToday: Boolean = false,
    val lessons: List<Lesson> = emptyList()
)

@Immutable
data class WeekSchedule(
    val title: String,           // "Расписание для группы ДБ-243/21"
    val weekRange: String,       // "09 — 15 ноября"
    val currentSkip: Int = 0,
    val days: List<DaySchedule> = emptyList(),
    val sourceUrl: String = ""
)

@Immutable
data class Group(
    val name: String,
    val specialtyCode: String = "",
    // Курс считается по году набора из номера группы и текущей дате (см. courseFromName)
    val course: Int = courseFromName(name)
) {
    val directionCode: String = run {
        val trimmed = name.trim()
        val dashIdx = trimmed.indexOf('-')
        if (dashIdx > 0) {
            trimmed.substring(0, dashIdx).uppercase()
        } else {
            val letters = trimmed.takeWhile { it.isLetter() }.uppercase()
            if (letters.isNotEmpty()) letters else "ДРУГИЕ"
        }
    }

    val numberPart: String = run {
        val trimmed = name.trim()
        val dashIdx = trimmed.indexOf('-')
        if (dashIdx >= 0 && dashIdx + 1 < trimmed.length) {
            trimmed.substring(dashIdx + 1).trim()
        } else {
            trimmed.dropWhile { it.isLetter() }.trim()
        }
    }

    companion object {
        private val LEADING_YEAR_REGEX = Regex("""^(\d{2})""")
        private val FULL_YEAR_REGEX = Regex("""(?<!\d)20(\d{2})(?!\d)""")

        /**
         * Год набора, зашитый в номере группы: «ДИС-252.2/21» -> 2025, «ДБ-243/21» -> 2024,
         * старый формат «БД-О-11-2021» -> 2021. Если определить не удалось — null.
         */
        fun admissionYearOf(name: String): Int? {
            val number = name.trim().substringAfter('-', "").trim()
            LEADING_YEAR_REGEX.find(number)?.let { return 2000 + it.groupValues[1].toInt() }
            FULL_YEAR_REGEX.find(number)?.let { return 2000 + it.groupValues[1].toInt() }
            return null
        }

        /**
         * Курс на заданную дату. Учебный год начинается в сентябре, поэтому с сентября
         * к разнице лет прибавляется 1. Результат ограничен диапазоном 1..4.
         */
        fun courseFromName(
            name: String,
            year: Int = Calendar.getInstance().get(Calendar.YEAR),
            month: Int = Calendar.getInstance().get(Calendar.MONTH) + 1
        ): Int {
            val admission = admissionYearOf(name) ?: return 1
            val course = year - admission + if (month >= 9) 1 else 0
            return course.coerceIn(1, 4)
        }

        fun getDirectionTitle(code: String): String {
            return when (code.uppercase()) {
                "ДИС" -> "Информационные системы и программирование"
                "ДГД" -> "Графический дизайн"
                "ДБ", "БД" -> "Банковское дело"
                "ДД" -> "Дизайн (по отраслям)"
                "ДНГ" -> "Нефтегазовое дело"
                "ДП" -> "Право и соц. обеспечение"
                "ДЮ" -> "Юриспруденция"
                "ДР" -> "Реклама"
                "ДТГ" -> "Туризм и гостеприимство"
                "ДТД" -> "Туризм"
                "ДК" -> "Коммерция (по отраслям)"
                "ДРУ" -> "Связи с общественностью"
                "ДПО" -> "Правоохранительная деятельность"
                "ДОИС" -> "Информационная безопасность"
                "ДДО" -> "Дошкольное образование"
                "ДКТ" -> "Технология швейных изделий"
                "ДЛ" -> "Логистика"
                "ДЭ" -> "Экономика и бухучет"
                "ДИЗ" -> "Дизайн"
                "ДИИ" -> "Издательское дело"
                "ДПК" -> "Правоохранительная деятельность"
                "ДТ" -> "Технические специальности"
                else -> "Специальность колледжа МВЕК"
            }
        }
    }
}

@Immutable
data class Teacher(
    val id: String,
    val name: String,
    val department: String = ""
)

@Immutable
data class RoomSlot(
    val lessonNumber: Int,
    val timeRange: String,
    val info: String,
    val isOccupied: Boolean
)

@Immutable
data class RoomOccupancy(
    val roomNumber: String,
    val dayName: String,
    val dateStr: String,
    val slots: List<RoomSlot>
)
