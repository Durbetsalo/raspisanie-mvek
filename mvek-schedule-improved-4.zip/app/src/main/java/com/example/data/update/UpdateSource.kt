package com.example.data.update

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import com.example.data.api.HttpException
import com.example.data.api.MvekApiClient
import java.io.File
import java.io.IOException
import java.security.MessageDigest

/** Источник обновлений. Интерфейс нужен, чтобы логику ViewModel можно было проверять без сети. */
interface UpdateSource {
    val isConfigured: Boolean
    fun currentVersionName(): String
    fun shouldAutoCheck(nowMillis: Long): Boolean

    /** Результат: информация о более новой версии или null, если установлена последняя. */
    suspend fun check(): Result<UpdateInfo?>

    suspend fun download(
        info: UpdateInfo,
        onProgress: (downloaded: Long, total: Long) -> Unit
    ): Result<File>

    /** Удаляет ранее скачанные файлы обновлений. */
    fun cleanup()
}

class GithubUpdateSource(
    context: Context,
    private val api: MvekApiClient
) : UpdateSource {

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("update_prefs", Context.MODE_PRIVATE)

    override val isConfigured: Boolean get() = UpdateConfig.isConfigured

    override fun currentVersionName(): String = installedInfo(0)?.versionName.orEmpty()

    override fun shouldAutoCheck(nowMillis: Long): Boolean {
        val last = prefs.getString(KEY_LAST_CHECK, null)?.toLongOrNull() ?: 0L
        return nowMillis - last >= UpdateConfig.CHECK_INTERVAL_MS
    }

    override suspend fun check(): Result<UpdateInfo?> {
        val url = "https://api.github.com/repos/${UpdateConfig.GITHUB_REPO}/releases/latest"
        val json = api.getJson(url).getOrElse { error ->
            val friendly = when ((error as? HttpException)?.code) {
                404 -> "В репозитории ${UpdateConfig.GITHUB_REPO} пока нет опубликованных релизов"
                403, 429 -> "GitHub временно ограничил запросы. Попробуйте позже"
                else -> null
            }
            return Result.failure(if (friendly != null) IOException(friendly, error) else error)
        }
        prefs.edit().putString(KEY_LAST_CHECK, System.currentTimeMillis().toString()).apply()

        val info = GithubReleaseParser.parse(json) ?: return Result.success(null)
        val newer = VersionComparator.isNewer(info.versionName, currentVersionName())
        return Result.success(if (newer) info else null)
    }

    override suspend fun download(
        info: UpdateInfo,
        onProgress: (downloaded: Long, total: Long) -> Unit
    ): Result<File> {
        if (!UpdatePolicy.isTrustedApkUrl(info.apkUrl)) {
            return Result.failure(IOException("Адрес загрузки не похож на GitHub, обновление отменено"))
        }
        val dir = updatesDir()
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }

        val target = File(dir, "mvek-${info.versionName}.apk")
        val file = api.download(info.apkUrl, target, onProgress).getOrElse { return Result.failure(it) }

        if (info.sizeBytes > 0 && file.length() != info.sizeBytes) {
            file.delete()
            return Result.failure(IOException("Файл скачан не полностью. Попробуйте ещё раз"))
        }
        val problem = verifyApk(file)
        if (problem != null) {
            file.delete()
            return Result.failure(IOException(problem))
        }
        return Result.success(file)
    }

    override fun cleanup() {
        updatesDir().listFiles()?.forEach { it.delete() }
    }

    private fun updatesDir() = File(app.cacheDir, "updates")

    /**
     * Проверяет скачанный файл до установки, чтобы вместо невнятного «Приложение не установлено»
     * показать понятную причину: тот же пакет, версия новее, подпись совпадает с установленной.
     */
    private fun verifyApk(file: File): String? {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }
        val archive = app.packageManager.getPackageArchiveInfo(file.absolutePath, flags)
            ?: return "Скачанный файл повреждён или не является приложением"
        if (archive.packageName != app.packageName) {
            return "Скачанный файл относится к другому приложению"
        }

        val installed = installedInfo(flags) ?: return null
        if (PackageInfoCompat.getLongVersionCode(archive) <= PackageInfoCompat.getLongVersionCode(installed)) {
            return "В скачанном файле версия не новее установленной. При сборке обновите appVersionName в build.gradle.kts"
        }
        val newSigners = signingDigests(archive)
        val oldSigners = signingDigests(installed)
        if (newSigners.isNotEmpty() && oldSigners.isNotEmpty() && newSigners != oldSigners) {
            return "Подпись обновления не совпадает с подписью установленного приложения. " +
                "Удалите приложение и установите новую версию вручную — это нужно один раз"
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun installedInfo(flags: Int): PackageInfo? = try {
        app.packageManager.getPackageInfo(app.packageName, flags)
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }

    @Suppress("DEPRECATION")
    private fun signingDigests(info: PackageInfo): Set<String> {
        val signatures: Array<Signature>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners
        } else {
            info.signatures
        }
        return signatures.orEmpty().map { sig ->
            MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
                .joinToString("") { "%02x".format(it) }
        }.toSet()
    }

    private companion object {
        const val KEY_LAST_CHECK = "last_check_millis"
    }
}
