package com.example.data.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

/** Запуск системной установки скачанного APK. */
object ApkInstaller {

    private const val APK_MIME = "application/vnd.android.package-archive"

    /** С Android 8 приложению нужно отдельное разрешение «Установка неизвестных приложений». */
    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

    /** Открывает настройки, где пользователь включает установку из этого приложения. */
    fun openInstallPermissionSettings(context: Context): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        return try {
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            null
        } catch (e: Exception) {
            "Не удалось открыть настройки: ${e.localizedMessage ?: "ошибка"}"
        }
    }

    /** Возвращает текст ошибки или null, если установщик успешно открыт. */
    fun install(context: Context, apk: File): String? {
        return try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, APK_MIME)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            null
        } catch (e: Exception) {
            "Не удалось открыть установщик: ${e.localizedMessage ?: "ошибка"}"
        }
    }
}
