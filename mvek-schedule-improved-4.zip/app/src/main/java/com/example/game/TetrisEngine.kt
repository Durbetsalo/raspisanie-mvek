package com.example.game

import kotlin.math.max
import kotlin.random.Random

/** Фигуры. [base] — клетки в начальном повороте внутри квадрата [size] × [size]. */
enum class Tetromino(val size: Int, private val base: List<Pair<Int, Int>>) {
    I(4, listOf(0 to 1, 1 to 1, 2 to 1, 3 to 1)),
    O(2, listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1)),
    T(3, listOf(1 to 0, 0 to 1, 1 to 1, 2 to 1)),
    S(3, listOf(1 to 0, 2 to 0, 0 to 1, 1 to 1)),
    Z(3, listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1)),
    J(3, listOf(0 to 0, 0 to 1, 1 to 1, 2 to 1)),
    L(3, listOf(2 to 0, 0 to 1, 1 to 1, 2 to 1));

    /** Четыре поворота по часовой стрелке: (x, y) -> (size - 1 - y, x). */
    val rotations: List<List<Pair<Int, Int>>> = run {
        val result = ArrayList<List<Pair<Int, Int>>>()
        var current = base
        repeat(4) {
            result.add(current)
            current = current.map { (x, y) -> (size - 1 - y) to x }
        }
        result
    }

    /** Номер цвета на поле (0 — пустая клетка). */
    val colorId: Int get() = ordinal + 1
}

/**
 * Неизменяемый снимок состояния игры для интерфейса. Движок меняется «на месте», а Compose замечает
 * только смену значения состояния: поэтому после каждого действия интерфейс получает новый снимок.
 */
class TetrisSnapshot(
    val board: Array<IntArray>,
    val current: List<Pair<Int, Int>>,
    val ghost: List<Pair<Int, Int>>,
    val piece: Tetromino,
    val next: Tetromino,
    val score: Int,
    val lines: Int,
    val level: Int,
    val gameOver: Boolean
)

/**
 * Правила тетриса без привязки к интерфейсу: поле 10×20, «мешок» из 7 фигур (каждая выпадает раз за семёрку),
 * повороты с простым смещением от стенки, очки за линии и быстрое падение, уровни каждые 10 линий.
 */
class TetrisEngine(
    private val random: Random = Random.Default,
    val width: Int = 10,
    val height: Int = 20
) {
    /** Зафиксированные клетки: 0 — пусто, иначе [Tetromino.colorId]. */
    val board: Array<IntArray> = Array(height) { IntArray(width) }

    var piece: Tetromino = Tetromino.T
        private set
    var rotation: Int = 0
        private set
    var px: Int = 0
        private set
    var py: Int = 0
        private set
    var next: Tetromino = Tetromino.T
        private set

    var score: Int = 0
        private set
    var lines: Int = 0
        private set
    var level: Int = 1
        private set
    var gameOver: Boolean = false
        private set

    private val bag = ArrayDeque<Tetromino>()

    init {
        next = drawFromBag()
        spawn()
    }

    fun reset() {
        for (row in board) row.fill(0)
        score = 0
        lines = 0
        level = 1
        gameOver = false
        bag.clear()
        next = drawFromBag()
        spawn()
    }

    /** Следующая фигура из «мешка»: перемешанная семёрка, пока не опустеет. */
    fun drawFromBag(): Tetromino {
        if (bag.isEmpty()) bag.addAll(Tetromino.entries.shuffled(random))
        return bag.removeFirst()
    }

    /** Через сколько миллисекунд фигура опускается на клетку: чем выше уровень, тем быстрее. */
    fun dropIntervalMs(): Long = max(90L, 800L - (level - 1) * 70L)

    /** Абсолютные клетки фигуры в заданном положении. */
    fun cellsOf(kind: Tetromino, rot: Int, x: Int, y: Int): List<Pair<Int, Int>> =
        kind.rotations[((rot % 4) + 4) % 4].map { (cx, cy) -> (x + cx) to (y + cy) }

    fun currentCells(): List<Pair<Int, Int>> = cellsOf(piece, rotation, px, py)

    /** Где окажется фигура, если сбросить её вниз (для «призрака»). */
    fun ghostCells(): List<Pair<Int, Int>> {
        var y = py
        while (!collides(piece, rotation, px, y + 1)) y++
        return cellsOf(piece, rotation, px, y)
    }

    private fun collides(kind: Tetromino, rot: Int, x: Int, y: Int): Boolean {
        for ((cx, cy) in cellsOf(kind, rot, x, y)) {
            if (cx < 0 || cx >= width || cy < 0 || cy >= height) return true
            if (board[cy][cx] != 0) return true
        }
        return false
    }

    private fun spawn() {
        piece = next
        next = drawFromBag()
        rotation = 0
        px = (width - piece.size) / 2
        py = 0
        if (collides(piece, rotation, px, py)) gameOver = true
    }

    fun moveLeft(): Boolean = move(-1)

    fun moveRight(): Boolean = move(1)

    private fun move(dx: Int): Boolean {
        if (gameOver || collides(piece, rotation, px + dx, py)) return false
        px += dx
        return true
    }

    /** Поворот по часовой стрелке; если мешает стенка или стопка, пробуем сдвинуть на 1–2 клетки. */
    fun rotate(): Boolean {
        if (gameOver) return false
        val newRotation = (rotation + 1) % 4
        for (kick in KICKS) {
            if (!collides(piece, newRotation, px + kick, py)) {
                rotation = newRotation
                px += kick
                return true
            }
        }
        return false
    }

    /** Падение по таймеру: без очков. */
    fun tick(): Boolean = stepDown(scorePerCell = 0)

    /** Ускоренное падение кнопкой: +1 очко за клетку. */
    fun softDrop(): Boolean = stepDown(scorePerCell = 1)

    private fun stepDown(scorePerCell: Int): Boolean {
        if (gameOver) return false
        return if (!collides(piece, rotation, px, py + 1)) {
            py++
            score += scorePerCell
            true
        } else {
            lockPiece()
            false
        }
    }

    /** Мгновенный сброс вниз: +2 очка за клетку. */
    fun hardDrop() {
        if (gameOver) return
        while (!collides(piece, rotation, px, py + 1)) {
            py++
            score += 2
        }
        lockPiece()
    }

    private fun lockPiece() {
        for ((cx, cy) in currentCells()) board[cy][cx] = piece.colorId
        val cleared = clearLines()
        if (cleared > 0) {
            score += when (cleared) {
                1 -> 100
                2 -> 300
                3 -> 500
                else -> 800
            } * level
            lines += cleared
            level = lines / 10 + 1
        }
        spawn()
    }

    private fun clearLines(): Int {
        var cleared = 0
        var y = height - 1
        while (y >= 0) {
            if (board[y].all { it != 0 }) {
                for (row in y downTo 1) board[row - 1].copyInto(board[row])
                board[0].fill(0)
                cleared++
                // та же строка теперь содержит сдвинувшуюся сверху — проверяем её снова
            } else {
                y--
            }
        }
        return cleared
    }

    /** Копия текущего состояния: дальнейшие действия движка на неё не влияют. */
    fun snapshot(): TetrisSnapshot = TetrisSnapshot(
        board = Array(height) { board[it].copyOf() },
        current = currentCells(),
        ghost = ghostCells(),
        piece = piece,
        next = next,
        score = score,
        lines = lines,
        level = level,
        gameOver = gameOver
    )

    /** Для тестов: поставить фигуру в заданное положение. */
    fun forcePiece(kind: Tetromino, x: Int, y: Int, rot: Int = 0) {
        piece = kind
        rotation = rot
        px = x
        py = y
    }

    private companion object {
        val KICKS = intArrayOf(0, -1, 1, -2, 2)
    }
}
