package com.example.widget

import com.example.data.model.DaySchedule
import com.example.data.model.Lesson
import com.example.data.model.LessonTimeStatus
import com.example.data.model.WeekSchedule
import java.util.Calendar
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

// ---------------------------------------------------------------------------------------------
// Чистая логика виджетов (без Android-зависимостей): что показывать, сколько строк поместится,
// когда обновляться. Вынесена отдельно, чтобы её можно было проверить обычными юнит-тестами.
// ---------------------------------------------------------------------------------------------

enum class WidgetMode {
    /** «Сейчас и дальше»: крупная карточка текущей/ближайшей пары и несколько следующих. */
    NEXT,

    /** «Расписание на день»: список всех пар дня. */
    DAY
}

enum class WidthClass { NARROW, MEDIUM, WIDE }

/**
 * Тема виджета. SYSTEM — цвета берутся из ресурсов и сами меняются вместе с системной темой телефона.
 * LIGHT/DARK — пользователь выбрал тему в приложении: виджет следует ей, а не системной.
 */
enum class WidgetTheme { SYSTEM, LIGHT, DARK }

/** Цвета принудительной темы; значения совпадают с res/values(-night)/widget_colors.xml. */
data class WidgetPalette(
    val dark: Boolean,
    val textPrimary: Int,
    val textSecondary: Int,
    val textDim: Int,
    val accent: Int,
    val ongoing: Int
) {
    companion object {
        val LIGHT = WidgetPalette(
            dark = false,
            textPrimary = 0xFF0F172A.toInt(),
            textSecondary = 0xFF64748B.toInt(),
            textDim = 0xFF94A3B8.toInt(),
            accent = 0xFF2563EB.toInt(),
            ongoing = 0xFF10B981.toInt()
        )
        val DARK = WidgetPalette(
            dark = true,
            textPrimary = 0xFFF1F5F9.toInt(),
            textSecondary = 0xFF94A3B8.toInt(),
            textDim = 0xFF64748B.toInt(),
            accent = 0xFF60A5FA.toInt(),
            ongoing = 0xFF34D399.toInt()
        )

        /** null для SYSTEM: тогда ничего не переопределяем. */
        fun of(theme: WidgetTheme): WidgetPalette? = when (theme) {
            WidgetTheme.SYSTEM -> null
            WidgetTheme.LIGHT -> LIGHT
            WidgetTheme.DARK -> DARK
        }
    }
}

data class WidgetLessonItem(
    val number: Int,
    val start: String,
    val end: String,
    val subject: String,
    val teacher: String,
    val room: String,
    val status: LessonTimeStatus,
    val startMinutes: Int?,
    val endMinutes: Int?
)

sealed interface WidgetContent {
    /** Группа не выбрана. */
    data object NoGroup : WidgetContent

    /** Нет сохранённого расписания или оно устарело. */
    data class NoData(val groupName: String) : WidgetContent

    /** Расписание есть, но показать нечего (выходные, всё закончилось). */
    data class NoLessons(val groupName: String, val message: String) : WidgetContent

    /**
     * День, который показывает виджет: сегодня, пока есть пары, иначе ближайший учебный день.
     * [currentIndex] — первая идущая сейчас пара (или -1), [nextIndex] — первая ещё не начавшаяся (или -1).
     */
    data class Day(
        val groupName: String,
        val dayLabel: String,
        val dateLabel: String,
        val note: String?,
        val isToday: Boolean,
        val lessons: List<WidgetLessonItem>,
        val currentIndex: Int,
        val nextIndex: Int
    ) : WidgetContent
}

data class WidgetPlan(
    val widthClass: WidthClass,
    val showHeader: Boolean,
    val showSubtitle: Boolean,
    /** false — места мало: прячем строку с аудиторией/преподавателем и конец времени. */
    val showDetails: Boolean,
    /** Индекс пары для крупной карточки (только режим NEXT). */
    val heroIndex: Int?,
    val rowIndices: List<Int>,
    val hiddenCount: Int,
    val showMore: Boolean
)

object WidgetModelBuilder {

    private val MONTHS_GENITIVE = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val DATE_REGEX = Regex("""^(\d{1,2})\.(\d{1,2})$""")
    private const val MS_PER_DAY = 86_400_000.0

    fun build(
        group: String?,
        thisWeek: WeekSchedule?,
        nextWeek: WeekSchedule?,
        now: Calendar
    ): WidgetContent {
        if (group.isNullOrBlank()) return WidgetContent.NoGroup

        val dated = datedDays(thisWeek, nextWeek, now)
        if (dated.isEmpty()) return WidgetContent.NoData(group)

        val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val today = dated.firstOrNull { it.second == 0 }?.first
        val todayHasLeft = today != null &&
            today.lessons.any { it.getTimeStatus(nowMinutes) != LessonTimeStatus.FINISHED }

        if (today != null && todayHasLeft) {
            return dayContent(group, today, "Сегодня", null, true, nowMinutes)
        }

        // Сегодня занятий нет или они закончились — показываем ближайший учебный день
        val upcoming = dated
            .filter { it.second > 0 && it.first.lessons.isNotEmpty() }
            .minByOrNull { it.second }
        if (upcoming != null) {
            val day = upcoming.first
            val offset = upcoming.second
            val label = if (offset == 1) "Завтра" else "${day.dayOfWeek}, ${prettyDate(day.dateString)}"
            val note = when {
                today == null -> null
                today.lessons.isEmpty() -> "Сегодня занятий нет"
                else -> "Пары на сегодня закончились"
            }
            return dayContent(group, day, label, note, false, nowMinutes)
        }

        // Все известные дни остались в прошлом — расписание устарело
        if (dated.none { it.second >= 0 }) return WidgetContent.NoData(group)

        val message = if (today != null && today.lessons.isNotEmpty()) {
            "Пары на сегодня закончились"
        } else {
            "Сегодня занятий нет"
        }
        return WidgetContent.NoLessons(group, message)
    }

    private fun dayContent(
        group: String,
        day: DaySchedule,
        label: String,
        note: String?,
        isToday: Boolean,
        nowMinutes: Int
    ): WidgetContent.Day {
        val items = day.lessons.map { l: Lesson ->
            WidgetLessonItem(
                number = l.number,
                start = l.startTime,
                end = l.endTime,
                subject = l.subject.trim(),
                teacher = l.teacher.trim(),
                room = l.auditorium.trim(),
                status = if (isToday) l.getTimeStatus(nowMinutes) else LessonTimeStatus.UPCOMING,
                startMinutes = l.startMinutes,
                endMinutes = l.endMinutes
            )
        }
        return WidgetContent.Day(
            groupName = group,
            dayLabel = label,
            dateLabel = prettyDate(day.dateString),
            note = note,
            isToday = isToday,
            lessons = items,
            currentIndex = items.indexOfFirst { it.status == LessonTimeStatus.ONGOING },
            nextIndex = items.indexOfFirst { it.status == LessonTimeStatus.UPCOMING }
        )
    }

    /** Дни обеих недель вместе со смещением в днях относительно сегодняшней даты (0 — сегодня). */
    private fun datedDays(
        thisWeek: WeekSchedule?,
        nextWeek: WeekSchedule?,
        now: Calendar
    ): List<Pair<DaySchedule, Int>> {
        val all = thisWeek?.days.orEmpty() + nextWeek?.days.orEmpty()
        val byDate = all.mapNotNull { d -> dayOffset(d.dateString, now)?.let { d to it } }
        if (byDate.isNotEmpty()) return byDate

        // Запасной вариант: дат на странице нет — ориентируемся по дням недели
        val todayIdx = weekdayIndex(now)
        val result = ArrayList<Pair<DaySchedule, Int>>()
        thisWeek?.days.orEmpty().forEach { d ->
            val idx = weekdayIndexOf(d.dayOfWeek)
            if (idx >= 0) result.add(d to (idx - todayIdx))
        }
        nextWeek?.days.orEmpty().forEach { d ->
            val idx = weekdayIndexOf(d.dayOfWeek)
            if (idx >= 0) result.add(d to (idx - todayIdx + 7))
        }
        return result
    }

    /** Смещение даты «дд.мм» от сегодня в днях; год подбирается так, чтобы переход декабрь/январь работал. */
    private fun dayOffset(dateString: String, now: Calendar): Int? {
        val m = DATE_REGEX.matchEntire(dateString.trim()) ?: return null
        val day = m.groupValues[1].toInt()
        val month = m.groupValues[2].toInt()
        if (month !in 1..12 || day !in 1..31) return null

        val nowMonth = now.get(Calendar.MONTH) + 1
        var year = now.get(Calendar.YEAR)
        if (month - nowMonth > 6) year -= 1 else if (nowMonth - month > 6) year += 1

        val target = Calendar.getInstance().apply { clear(); set(year, month - 1, day) }
        val today = Calendar.getInstance().apply {
            clear()
            set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
        }
        return ((target.timeInMillis - today.timeInMillis) / MS_PER_DAY).roundToLong().toInt()
    }

    private fun weekdayIndex(now: Calendar): Int = when (now.get(Calendar.DAY_OF_WEEK)) {
        Calendar.MONDAY -> 0
        Calendar.TUESDAY -> 1
        Calendar.WEDNESDAY -> 2
        Calendar.THURSDAY -> 3
        Calendar.FRIDAY -> 4
        Calendar.SATURDAY -> 5
        else -> 6
    }

    private fun weekdayIndexOf(short: String): Int = when (short.trim().lowercase()) {
        "пн" -> 0
        "вт" -> 1
        "ср" -> 2
        "чт" -> 3
        "пт" -> 4
        "сб" -> 5
        "вс" -> 6
        else -> -1
    }

    fun prettyDate(dateString: String): String {
        val m = DATE_REGEX.matchEntire(dateString.trim()) ?: return dateString.trim()
        val day = m.groupValues[1].toInt()
        val month = m.groupValues[2].toInt()
        return if (month in 1..12) "$day ${MONTHS_GENITIVE[month - 1]}" else dateString.trim()
    }

    /**
     * Через сколько миллисекунд виджет надо перерисовать: на ближайшей границе пары (начало или
     * конец), в полночь, но не реже раза в 30 минут.
     */
    fun nextRefreshDelayMillis(content: WidgetContent, now: Calendar): Long {
        val nowMs = now.timeInMillis
        val dayStart = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val nowMin = ((nowMs - dayStart) / 60_000L).toInt()

        var nextMs = dayStart + 24 * 3_600_000L + 60_000L // 00:01 следующего дня
        if (content is WidgetContent.Day && content.isToday) {
            for (lesson in content.lessons) {
                // Пара идёт включительно до minute конца, поэтому «закончилась» наступает на минуту позже
                val boundaries = listOfNotNull(lesson.startMinutes, lesson.endMinutes?.plus(1))
                for (m in boundaries) {
                    if (m > nowMin) nextMs = min(nextMs, dayStart + m * 60_000L + 2_000L)
                }
            }
        }
        val cap = nowMs + 30 * 60_000L
        return (min(nextMs, cap) - nowMs).coerceAtLeast(60_000L)
    }
}

object WidgetTexts {

    /** «Касимова Мария Сергеевна» -> «Касимова М. С.» */
    fun shortTeacher(full: String): String {
        val parts = full.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.size < 2) return full.trim()
        if (parts[1].contains('.')) return full.trim() // уже сокращено
        val initials = parts.drop(1).take(2).joinToString(" ") { "${it.first().uppercaseChar()}." }
        return "${parts[0]} $initials"
    }

    /** Строка под названием предмета: аудитория и преподаватель — сколько позволяет ширина. */
    fun details(item: WidgetLessonItem, widthClass: WidthClass, fullTeacher: Boolean = false): String {
        val room = if (item.room.isNotBlank()) "ауд. ${item.room}" else ""
        val teacher = when {
            item.teacher.isBlank() -> ""
            fullTeacher && widthClass == WidthClass.WIDE -> item.teacher
            else -> shortTeacher(item.teacher)
        }
        return when (widthClass) {
            WidthClass.NARROW -> room.ifEmpty { teacher }
            else -> listOf(room, teacher).filter { it.isNotEmpty() }.joinToString(" · ")
        }
    }

    fun heroLabel(day: WidgetContent.Day, index: Int): String {
        val item = day.lessons.getOrNull(index) ?: return ""
        return when {
            item.status == LessonTimeStatus.ONGOING ->
                if (item.end.isNotBlank()) "СЕЙЧАС · ДО ${item.end}" else "СЕЙЧАС"
            index == 0 && (!day.isToday || day.currentIndex < 0) && day.lessons.none { it.status == LessonTimeStatus.FINISHED } ->
                "ПЕРВАЯ ПАРА · В ${item.start}"
            else -> "ДАЛЕЕ · В ${item.start}"
        }
    }
}

object WidgetLayoutPlanner {

    // Размеры в dp при масштабе шрифта 1.0 (при крупном шрифте умножаются на fontScale)
    private const val PADDING_DP = 16f
    private const val HEADER_TITLE_ONLY_DP = 20f
    private const val HEADER_FULL_DP = 36f
    private const val HERO_DP = 74f
    private const val ROW_DP = 38f
    private const val MORE_DP = 16f
    private const val COMPACT_HEIGHT_DP = 100f
    private const val DETAILS_MIN_HEIGHT_DP = 64f
    private const val SUBTITLE_MIN_HEIGHT_DP = 140f

    fun widthClassOf(widthDp: Int): WidthClass = when {
        widthDp < 170 -> WidthClass.NARROW
        widthDp < 260 -> WidthClass.MEDIUM
        else -> WidthClass.WIDE
    }

    fun plan(
        mode: WidgetMode,
        day: WidgetContent.Day,
        widthDp: Int,
        heightDp: Int,
        fontScale: Float = 1f
    ): WidgetPlan {
        val s = fontScale.coerceIn(1f, 1.6f)
        val widthClass = widthClassOf(widthDp)
        val count = day.lessons.size
        val relevant = when {
            day.currentIndex >= 0 -> day.currentIndex
            day.nextIndex >= 0 -> day.nextIndex
            else -> 0
        }.coerceIn(0, max(0, count - 1))
        val h = heightDp.toFloat()

        // Совсем низкий виджет (1 ячейка): одна строка с текущей или ближайшей парой
        if (h < COMPACT_HEIGHT_DP) {
            return WidgetPlan(
                widthClass = widthClass,
                showHeader = false,
                showSubtitle = false,
                showDetails = h >= DETAILS_MIN_HEIGHT_DP * s,
                heroIndex = null,
                rowIndices = if (count > 0) listOf(relevant) else emptyList(),
                hiddenCount = 0,
                showMore = false
            )
        }

        val showSubtitle = h >= SUBTITLE_MIN_HEIGHT_DP * s
        val headerH = (if (showSubtitle) HEADER_FULL_DP else HEADER_TITLE_ONLY_DP) * s
        var avail = h - PADDING_DP - headerH

        var heroIndex: Int? = null
        val candidates: List<Int>
        if (mode == WidgetMode.NEXT && count > 0 && avail >= HERO_DP * s) {
            heroIndex = relevant
            avail -= HERO_DP * s
            candidates = ((relevant + 1) until count).toList()
        } else {
            candidates = (0 until count).toList()
        }

        val rowH = ROW_DP * s
        var capacity = floor(avail / rowH).toInt().coerceAtLeast(0)
        if (capacity < candidates.size) {
            // Не всё помещается — оставляем место под строку «Ещё пар: N»
            capacity = floor((avail - MORE_DP * s) / rowH).toInt().coerceAtLeast(0)
        }
        if (heroIndex == null && candidates.isNotEmpty()) capacity = capacity.coerceAtLeast(1)
        capacity = capacity.coerceAtMost(candidates.size)

        val rows: List<Int> = if (heroIndex != null) {
            candidates.take(capacity)
        } else {
            // Окно начинается с текущей/ближайшей пары; если снизу остаётся место — подтягиваем предыдущие
            val firstPos = candidates.indexOf(relevant).coerceAtLeast(0)
            val start = min(firstPos, max(0, candidates.size - capacity))
            candidates.subList(start, start + capacity)
        }

        val hidden = candidates.size - rows.size
        val leftover = avail - rows.size * rowH
        return WidgetPlan(
            widthClass = widthClass,
            showHeader = true,
            showSubtitle = showSubtitle,
            showDetails = true,
            heroIndex = heroIndex,
            rowIndices = rows,
            hiddenCount = hidden,
            showMore = hidden > 0 && leftover >= MORE_DP * s
        )
    }
}
