package com.example.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle

/** Общая логика обоих виджетов; различаются они только режимом отображения (см. WidgetUpdater.TARGETS). */
abstract class BaseScheduleWidgetProvider : AppWidgetProvider() {

    // Добавление виджета, перезагрузка устройства и системное обновление раз в ~30 минут
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.update(context, goAsync(), refreshNetwork = true)
    }

    // Пользователь изменил размер виджета — перерисовываем под новый размер (без сети)
    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        WidgetUpdater.update(context, goAsync(), refreshNetwork = false)
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            WidgetUpdater.ACTION_REFRESH -> WidgetUpdater.update(context, goAsync(), refreshNetwork = true)
            WidgetUpdater.ACTION_TICK -> WidgetUpdater.update(context, goAsync(), refreshNetwork = false)
            else -> super.onReceive(context, intent)
        }
    }

    override fun onDisabled(context: Context) {
        WidgetUpdater.onProviderDisabled(context)
    }
}

/** «Сейчас и дальше»: крупная карточка текущей или ближайшей пары + следующие. */
class NextLessonWidgetProvider : BaseScheduleWidgetProvider()

/** «Расписание на день»: список всех пар дня. */
class DayScheduleWidgetProvider : BaseScheduleWidgetProvider()
