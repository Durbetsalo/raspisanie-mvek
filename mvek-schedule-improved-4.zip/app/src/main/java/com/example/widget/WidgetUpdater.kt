package com.example.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.example.data.api.MvekApiClient
import com.example.data.local.AppThemeMode
import com.example.data.local.PreferencesManager
import com.example.data.model.WeekSchedule
import com.example.data.repository.ScheduleRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Calendar

/**
 * Единая точка обновления всех виджетов: берёт сохранённое расписание выбранной группы,
 * при необходимости пытается обновить его с сайта (не дольше [NETWORK_BUDGET_MS]),
 * перерисовывает виджеты и ставит будильник на ближайшую границу пары.
 */
object WidgetUpdater {

    const val ACTION_REFRESH = "com.example.widget.ACTION_REFRESH"
    const val ACTION_TICK = "com.example.widget.ACTION_TICK"

    private const val TICK_REQUEST_CODE = 4242
    // Приёмник широковещательных сообщений живёт ~10 секунд, поэтому на сеть отводим не больше 7
    private const val NETWORK_BUDGET_MS = 7_000L

    private val TARGETS: List<Pair<Class<*>, WidgetMode>> = listOf(
        NextLessonWidgetProvider::class.java to WidgetMode.NEXT,
        DayScheduleWidgetProvider::class.java to WidgetMode.DAY
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()

    /**
     * @param pending результат от goAsync() — завершается, когда обновление закончено
     * @param refreshNetwork true — сначала попробовать скачать свежее расписание
     */
    fun update(context: Context, pending: BroadcastReceiver.PendingResult?, refreshNetwork: Boolean) {
        val app = context.applicationContext
        scope.launch {
            try {
                mutex.withLock { performUpdate(app, refreshNetwork) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Виджет не должен ронять приложение: в худшем случае останется прежняя картинка
            } finally {
                pending?.finish()
            }
        }
    }

    /** Вызывается из приложения, когда данные изменились: быстро перерисовать виджеты из кэша. */
    fun requestUpdate(context: Context) = update(context, null, refreshNetwork = false)

    /** Последний виджет одного из типов удалён: если виджетов больше нет, будильник не нужен. */
    fun onProviderDisabled(context: Context) {
        val app = context.applicationContext
        val manager = AppWidgetManager.getInstance(app)
        val any = TARGETS.any { (cls, _) -> manager.getAppWidgetIds(ComponentName(app, cls)).isNotEmpty() }
        if (!any) cancelTick(app)
    }

    private suspend fun performUpdate(app: Context, refreshNetwork: Boolean) {
        val manager = AppWidgetManager.getInstance(app)
        val targets = TARGETS.map { (cls, mode) ->
            Triple(cls, mode, manager.getAppWidgetIds(ComponentName(app, cls)))
        }
        if (targets.all { it.third.isEmpty() }) {
            cancelTick(app)
            return
        }

        val prefs = PreferencesManager(app)
        val group = prefs.selectedGroup.value
        var thisWeek: WeekSchedule? = null
        var nextWeek: WeekSchedule? = null

        if (group != null) {
            val repository = ScheduleRepository(MvekApiClient(), prefs)
            if (refreshNetwork) {
                withTimeoutOrNull(NETWORK_BUDGET_MS) {
                    repository.fetchGroupScheduleFromNetwork(group, 0)
                    if (needsNextWeek(Calendar.getInstance())) {
                        repository.fetchGroupScheduleFromNetwork(group, 1)
                    }
                }
            }
            thisWeek = repository.getDiskSchedule(group, 0)
            nextWeek = repository.getDiskSchedule(group, 1)
        }

        // Время берём после сетевого запроса, чтобы статусы пар были актуальны
        val now = Calendar.getInstance()
        val content = WidgetModelBuilder.build(group, thisWeek, nextWeek, now)
        // Виджет следует теме, выбранной в приложении (а при «как в системе» — системной)
        val theme = when (prefs.themeMode.value) {
            AppThemeMode.LIGHT -> WidgetTheme.LIGHT
            AppThemeMode.DARK -> WidgetTheme.DARK
            AppThemeMode.SYSTEM -> WidgetTheme.SYSTEM
        }

        for ((cls, mode, ids) in targets) {
            for (id in ids) {
                val views = WidgetRenderer.renderFor(app, manager, id, mode, content, cls, theme)
                manager.updateAppWidget(id, views)
            }
        }

        scheduleTick(app, WidgetModelBuilder.nextRefreshDelayMillis(content, now))
    }

    /** В пятницу–воскресенье нужна и следующая неделя: на ней первое занятие после выходных. */
    private fun needsNextWeek(now: Calendar): Boolean =
        now.get(Calendar.DAY_OF_WEEK) in setOf(Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)

    private fun tickIntent(app: Context): PendingIntent {
        val intent = Intent(app, NextLessonWidgetProvider::class.java).apply { action = ACTION_TICK }
        return PendingIntent.getBroadcast(
            app, TICK_REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Неточный будильник без разрешений: может сработать с небольшой задержкой, зато не требует
     * SCHEDULE_EXACT_ALARM и почти не расходует батарею (устройство им не будится).
     */
    private fun scheduleTick(app: Context, delayMillis: Long) {
        val alarmManager = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC,
            System.currentTimeMillis() + delayMillis,
            tickIntent(app)
        )
    }

    private fun cancelTick(app: Context) {
        val alarmManager = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(tickIntent(app))
    }
}
