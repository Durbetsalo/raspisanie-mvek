package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.model.LessonTimeStatus

/**
 * Превращает [WidgetContent] в RemoteViews под конкретный размер виджета.
 * Что и сколько показывать решает чистый [WidgetLayoutPlanner]; здесь только отрисовка.
 */
object WidgetRenderer {

    private const val DEFAULT_WIDTH_DP = 180
    private const val DEFAULT_HEIGHT_DP = 110

    /**
     * Android 12+: отдаём набор макетов под все размеры, в которых виджет может оказаться
     * (портрет/ландшафт), и лаунчер сам выбирает подходящий без обращения к нашему процессу.
     * Ниже: один макет по текущим размерам из опций виджета.
     */
    fun renderFor(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        mode: WidgetMode,
        content: WidgetContent,
        providerClass: Class<*>,
        theme: WidgetTheme = WidgetTheme.SYSTEM
    ): RemoteViews {
        val options = manager.getAppWidgetOptions(appWidgetId)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Список размеров приходит как ArrayList<SizeF>; читаем без привязки к типу контейнера
            @Suppress("DEPRECATION")
            val raw = options.get(AppWidgetManager.OPTION_APPWIDGET_SIZES)
            val sizes = (raw as? List<*>)?.filterIsInstance<SizeF>().orEmpty()
            if (sizes.isNotEmpty()) {
                val variants = HashMap<SizeF, RemoteViews>()
                for (size in sizes) {
                    variants[size] = render(
                        context, mode, content,
                        size.width.toInt(), size.height.toInt(),
                        appWidgetId, providerClass, theme
                    )
                }
                return RemoteViews(variants)
            }
        }

        val minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, DEFAULT_WIDTH_DP)
        val maxW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minW)
        val minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, DEFAULT_HEIGHT_DP)
        val maxH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minH)
        val landscape = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val widthDp = if (landscape) maxW else minW
        val heightDp = if (landscape) minH else maxH
        return render(context, mode, content, widthDp, heightDp, appWidgetId, providerClass, theme)
    }

    fun render(
        context: Context,
        mode: WidgetMode,
        content: WidgetContent,
        widthDp: Int,
        heightDp: Int,
        appWidgetId: Int,
        providerClass: Class<*>,
        theme: WidgetTheme = WidgetTheme.SYSTEM
    ): RemoteViews {
        val palette = WidgetPalette.of(theme)
        val rv = RemoteViews(context.packageName, R.layout.widget_root)
        if (palette != null) styleRoot(rv, palette)
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context))
        rv.setOnClickPendingIntent(R.id.widget_refresh, refreshIntent(context, providerClass, appWidgetId))

        when (content) {
            WidgetContent.NoGroup ->
                showMessage(rv, "Расписание МВЕК", "Выберите группу в приложении")
            is WidgetContent.NoData ->
                showMessage(rv, content.groupName, "Нет актуального расписания.\nОткройте приложение, чтобы обновить")
            is WidgetContent.NoLessons ->
                showMessage(rv, content.groupName, content.message)
            is WidgetContent.Day -> {
                val fontScale = context.resources.configuration.fontScale
                renderDay(context, rv, mode, content, widthDp, heightDp, fontScale, palette)
            }
        }
        return rv
    }

    private fun showMessage(rv: RemoteViews, title: String, text: String) {
        rv.setViewVisibility(R.id.widget_header, View.VISIBLE)
        rv.setTextViewText(R.id.widget_title, title)
        rv.setViewVisibility(R.id.widget_subtitle, View.GONE)
        rv.removeAllViews(R.id.widget_hero_container)
        rv.setViewVisibility(R.id.widget_hero_container, View.GONE)
        rv.removeAllViews(R.id.widget_rows_container)
        rv.setViewVisibility(R.id.widget_rows_container, View.GONE)
        rv.setViewVisibility(R.id.widget_more, View.GONE)
        rv.setTextViewText(R.id.widget_message, text)
        rv.setViewVisibility(R.id.widget_message, View.VISIBLE)
    }

    private fun renderDay(
        context: Context,
        rv: RemoteViews,
        mode: WidgetMode,
        day: WidgetContent.Day,
        widthDp: Int,
        heightDp: Int,
        fontScale: Float,
        palette: WidgetPalette?
    ) {
        val plan = WidgetLayoutPlanner.plan(mode, day, widthDp, heightDp, fontScale)

        rv.setViewVisibility(R.id.widget_message, View.GONE)

        // Заголовок
        rv.setViewVisibility(R.id.widget_header, if (plan.showHeader) View.VISIBLE else View.GONE)
        rv.setTextViewText(R.id.widget_title, day.dayLabel)
        if (plan.showSubtitle) {
            rv.setTextViewText(R.id.widget_subtitle, day.note ?: "${day.dateLabel} · ${day.groupName}")
            rv.setViewVisibility(R.id.widget_subtitle, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.widget_subtitle, View.GONE)
        }

        // Крупная карточка (режим «Сейчас и дальше»)
        rv.removeAllViews(R.id.widget_hero_container)
        val heroIndex = plan.heroIndex
        if (heroIndex != null) {
            rv.addView(R.id.widget_hero_container, buildHero(context, day, heroIndex, plan, palette))
            rv.setViewVisibility(R.id.widget_hero_container, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.widget_hero_container, View.GONE)
        }

        // Список пар
        rv.removeAllViews(R.id.widget_rows_container)
        if (plan.rowIndices.isEmpty()) {
            rv.setViewVisibility(R.id.widget_rows_container, View.GONE)
        } else {
            rv.setViewVisibility(R.id.widget_rows_container, View.VISIBLE)
            for (index in plan.rowIndices) {
                rv.addView(R.id.widget_rows_container, buildRow(context, day.lessons[index], plan, palette))
            }
        }

        // «Ещё пар: N»
        if (plan.showMore) {
            rv.setTextViewText(R.id.widget_more, "Ещё пар: ${plan.hiddenCount}")
            rv.setViewVisibility(R.id.widget_more, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.widget_more, View.GONE)
        }
    }

    private fun buildHero(
        context: Context,
        day: WidgetContent.Day,
        index: Int,
        plan: WidgetPlan,
        palette: WidgetPalette?
    ): RemoteViews {
        val item = day.lessons[index]
        val rv = RemoteViews(context.packageName, R.layout.widget_hero)
        if (palette != null) styleHero(rv, palette)
        rv.setTextViewText(R.id.hero_label, WidgetTexts.heroLabel(day, index))
        rv.setTextViewText(R.id.hero_subject, item.subject)

        val details = WidgetTexts.details(item, plan.widthClass, fullTeacher = true)
        if (details.isNotEmpty()) {
            rv.setTextViewText(R.id.hero_details, details)
            rv.setViewVisibility(R.id.hero_details, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.hero_details, View.GONE)
        }
        return rv
    }

    private fun buildRow(
        context: Context,
        item: WidgetLessonItem,
        plan: WidgetPlan,
        palette: WidgetPalette?
    ): RemoteViews {
        val layout = when (item.status) {
            LessonTimeStatus.ONGOING -> R.layout.widget_row_current
            LessonTimeStatus.FINISHED -> R.layout.widget_row_finished
            else -> R.layout.widget_row
        }
        val rv = RemoteViews(context.packageName, layout)
        if (palette != null) styleRow(rv, item.status, palette)

        rv.setTextViewText(R.id.row_time_start, item.start)
        if (plan.showDetails && item.end.isNotBlank()) {
            rv.setTextViewText(R.id.row_time_end, item.end)
            rv.setViewVisibility(R.id.row_time_end, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.row_time_end, View.GONE)
        }

        rv.setTextViewText(R.id.row_subject, item.subject)

        val details = if (plan.showDetails) WidgetTexts.details(item, plan.widthClass) else ""
        if (details.isNotEmpty()) {
            rv.setTextViewText(R.id.row_details, details)
            rv.setViewVisibility(R.id.row_details, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.row_details, View.GONE)
        }

        if (plan.widthClass == WidthClass.WIDE && item.number > 0) {
            rv.setTextViewText(R.id.row_number, "${item.number} пара")
            rv.setViewVisibility(R.id.row_number, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.row_number, View.GONE)
        }
        return rv
    }

    // --- Принудительная тема (выбрана в приложении). В режиме SYSTEM ничего не переопределяется,
    // и цвета берутся из ресурсов — их система меняет сама вместе со своей темой. ---

    private fun styleRoot(rv: RemoteViews, p: WidgetPalette) {
        rv.setInt(R.id.widget_root, "setBackgroundResource", if (p.dark) R.drawable.widget_bg_dark else R.drawable.widget_bg_light)
        rv.setTextColor(R.id.widget_title, p.textPrimary)
        rv.setTextColor(R.id.widget_subtitle, p.textSecondary)
        rv.setTextColor(R.id.widget_more, p.textSecondary)
        rv.setTextColor(R.id.widget_message, p.textSecondary)
        rv.setImageViewResource(
            R.id.widget_refresh,
            if (p.dark) R.drawable.ic_widget_refresh_dark else R.drawable.ic_widget_refresh_light
        )
    }

    private fun styleHero(rv: RemoteViews, p: WidgetPalette) {
        rv.setInt(R.id.hero_root, "setBackgroundResource", if (p.dark) R.drawable.widget_card_bg_dark else R.drawable.widget_card_bg_light)
        rv.setTextColor(R.id.hero_label, p.accent)
        rv.setTextColor(R.id.hero_subject, p.textPrimary)
        rv.setTextColor(R.id.hero_details, p.textSecondary)
    }

    private fun styleRow(rv: RemoteViews, status: LessonTimeStatus, p: WidgetPalette) {
        val finished = status == LessonTimeStatus.FINISHED
        val primary = if (finished) p.textDim else p.textPrimary
        val secondary = if (finished) p.textDim else p.textSecondary
        val strip = when (status) {
            LessonTimeStatus.ONGOING -> p.ongoing
            LessonTimeStatus.FINISHED -> p.textDim
            else -> p.accent
        }
        if (status == LessonTimeStatus.ONGOING) {
            rv.setInt(R.id.row_root, "setBackgroundResource", if (p.dark) R.drawable.widget_row_current_bg_dark else R.drawable.widget_row_current_bg_light)
        }
        rv.setInt(R.id.row_strip, "setBackgroundColor", strip)
        rv.setTextColor(R.id.row_time_start, primary)
        rv.setTextColor(R.id.row_time_end, secondary)
        rv.setTextColor(R.id.row_subject, primary)
        rv.setTextColor(R.id.row_details, secondary)
        rv.setTextColor(R.id.row_number, secondary)
    }

    private fun openAppIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun refreshIntent(context: Context, providerClass: Class<*>, appWidgetId: Int): PendingIntent {
        val intent = Intent(context, providerClass).apply {
            action = WidgetUpdater.ACTION_REFRESH
        }
        // requestCode = id виджета, чтобы у каждого экземпляра был свой PendingIntent
        return PendingIntent.getBroadcast(
            context, appWidgetId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
