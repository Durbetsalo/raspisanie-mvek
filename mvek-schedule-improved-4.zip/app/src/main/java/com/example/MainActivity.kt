package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.api.MvekApiClient
import com.example.data.local.AppThemeMode
import com.example.data.local.PreferencesManager
import com.example.data.repository.ScheduleRepository
import com.example.data.update.GithubUpdateSource
import com.example.ui.screens.GroupSelectScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.components.UpdateDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ScheduleViewModel
import com.example.ui.viewmodel.ScheduleViewModelFactory
import com.example.ui.viewmodel.UpdateViewModel
import com.example.ui.viewmodel.UpdateViewModelFactory
import com.example.widget.WidgetUpdater

private val NavBarLightScrim = Color.argb(0xE6, 0xFF, 0xFF, 0xFF)
private val NavBarDarkScrim = Color.argb(0x80, 0x1B, 0x1B, 0x1B)

class MainActivity : ComponentActivity() {

    private val updateViewModel: UpdateViewModel by viewModels {
        UpdateViewModelFactory(GithubUpdateSource(applicationContext, MvekApiClient()))
    }

    private val viewModel: ScheduleViewModel by viewModels {
        val prefs = PreferencesManager(applicationContext)
        val apiClient = MvekApiClient()
        val repository = ScheduleRepository(apiClient, prefs)
        ScheduleViewModelFactory(repository, prefs) {
            // Данные или группа изменились — сразу обновляем виджеты на рабочем столе
            WidgetUpdater.requestUpdate(applicationContext)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val darkTheme = when (themeMode) {
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
                AppThemeMode.SYSTEM -> systemDark
            }

            // Иконки статус-бара и панели навигации должны следовать теме приложения, а не системной:
            // иначе при ручном переключении темы тёмные иконки оказывались на тёмном фоне (и наоборот).
            DisposableEffect(darkTheme) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { darkTheme },
                    navigationBarStyle = SystemBarStyle.auto(NavBarLightScrim, NavBarDarkScrim) { darkTheme }
                )
                onDispose {}
            }

            MyApplicationTheme(appThemeMode = themeMode) {
                MainAppScreen(viewModel = viewModel, updateViewModel = updateViewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: ScheduleViewModel, updateViewModel: UpdateViewModel) {
    val selectedGroup by viewModel.selectedGroup.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    val isDarkTheme = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    var isSelectingGroupManual by rememberSaveable { mutableStateOf(false) }
    val showGroupSelection = selectedGroup == null || isSelectingGroupManual

    val onOpenGroupSelect = remember { { isSelectingGroupManual = true } }
    val onCloseGroupSelect = remember { { isSelectingGroupManual = false } }
    val onGroupSelected = remember(viewModel) {
        { grp: String ->
            viewModel.selectGroup(grp)
            isSelectingGroupManual = false
        }
    }
    val onToggleTheme = remember(viewModel, isDarkTheme) {
        { viewModel.toggleTheme(isDarkTheme) }
    }
    val onSelectWeek = remember(viewModel) { { weekIdx: Int -> viewModel.selectWeek(weekIdx) } }
    val onSelectDay = remember(viewModel) { { dayIdx: Int -> viewModel.selectDay(dayIdx) } }
    val onRefresh = remember(viewModel) { { viewModel.refreshSchedule() } }
    val onGoToToday = remember(viewModel) { { viewModel.goToToday() } }

    // При возврате в приложение пересчитываем «сейчас/сегодня» и обновляем устаревшее расписание
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        viewModel.onAppForeground()
        // Тихая проверка новой версии приложения (не чаще раза в несколько часов)
        updateViewModel.autoCheck()
    }

    val pendingUpdate by updateViewModel.pendingUpdate.collectAsStateWithLifecycle()
    val onCheckUpdates = remember(updateViewModel) { { updateViewModel.checkManually() } }

    LaunchedEffect(showGroupSelection) {
        if (showGroupSelection) {
            viewModel.loadGroupsIfNeeded()
        }
    }

    BackHandler(enabled = showGroupSelection && selectedGroup != null, onBack = onCloseGroupSelect)

    if (showGroupSelection) {
        val recentGroups by viewModel.recentGroups.collectAsStateWithLifecycle()
        val groupsUiState by viewModel.groupsUiState.collectAsStateWithLifecycle()
        GroupSelectScreen(
            groups = groupsUiState.groups,
            currentGroup = selectedGroup,
            recentGroups = recentGroups,
            onGroupSelected = onGroupSelected,
            onBackClick = if (selectedGroup != null) onCloseGroupSelect else null
        )
    } else {
        val scheduleUiState by viewModel.scheduleUiState.collectAsStateWithLifecycle()
        val selectedWeekIndex by viewModel.selectedWeekIndex.collectAsStateWithLifecycle()
        val selectedDayIndex by viewModel.selectedDayIndex.collectAsStateWithLifecycle()
        TodayScreen(
            currentGroup = selectedGroup,
            uiState = scheduleUiState,
            selectedWeekIndex = selectedWeekIndex,
            selectedDayIndex = selectedDayIndex,
            currentTimeMinutesFlow = viewModel.currentTimeMinutes,
            isDarkTheme = isDarkTheme,
            onSelectWeek = onSelectWeek,
            onSelectDay = onSelectDay,
            onChangeGroupClick = onOpenGroupSelect,
            onToggleThemeClick = onToggleTheme,
            onRefresh = onRefresh,
            onGoToToday = onGoToToday,
            appVersionName = updateViewModel.currentVersion,
            updatesEnabled = true,
            pendingUpdateVersion = pendingUpdate?.versionName,
            onCheckUpdates = onCheckUpdates
        )
    }

    // Окно обновления приложения (найдено / загрузка / установка / ошибка)
    val updateState by updateViewModel.state.collectAsStateWithLifecycle()
    UpdateDialog(
        state = updateState,
        onDownload = { updateViewModel.startDownload() },
        onCancelDownload = { updateViewModel.cancelDownload() },
        onDismiss = { updateViewModel.dismiss() }
    )
}
