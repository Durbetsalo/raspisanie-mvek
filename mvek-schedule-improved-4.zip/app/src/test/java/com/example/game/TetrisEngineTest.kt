package com.example.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class TetrisEngineTest {

    private fun engine(seed: Int = 1) = TetrisEngine(Random(seed))

    @Test
    fun testEveryPieceHasFourCellsInsideItsBoxAndFourDistinctRotationsCycle() {
        for (kind in Tetromino.entries) {
            assertEquals(4, kind.rotations.size)
            for (cells in kind.rotations) {
                assertEquals("${kind.name}: 4 клетки", 4, cells.toSet().size)
                assertTrue(cells.all { (x, y) -> x in 0 until kind.size && y in 0 until kind.size })
            }
            // пятый поворот совпадает с первым
            val fifth = kind.rotations[3].map { (x, y) -> (kind.size - 1 - y) to x }.toSet()
            assertEquals(kind.rotations[0].toSet(), fifth)
        }
        // квадрат при поворотах не меняется
        assertEquals(Tetromino.O.rotations[0].toSet(), Tetromino.O.rotations[1].toSet())
    }

    @Test
    fun testBagGivesEachPieceOncePerSeven() {
        val e = engine(7)
        // из первой семёрки две фигуры уже выданы при создании (текущая и «следующая»)
        val first = mutableListOf(e.piece, e.next)
        repeat(5) { first.add(e.drawFromBag()) }
        assertEquals(Tetromino.entries.toSet(), first.toSet())
        val second = List(7) { e.drawFromBag() }
        assertEquals(Tetromino.entries.toSet(), second.toSet())
    }

    @Test
    fun testPieceStopsAtWalls() {
        val e = engine()
        while (e.moveLeft()) { /* до стенки */ }
        assertFalse(e.moveLeft())
        assertTrue(e.currentCells().minOf { it.first } == 0)
        while (e.moveRight()) { /* до стенки */ }
        assertFalse(e.moveRight())
        assertTrue(e.currentCells().maxOf { it.first } == e.width - 1)
    }

    @Test
    fun testRotationKicksOffTheWall() {
        val e = engine()
        e.forcePiece(Tetromino.I, x = -1, y = 5, rot = 1) // вертикальная палка у левой стенки
        assertTrue(e.currentCells().all { it.first >= 0 })
        assertTrue(e.rotate())
        assertTrue(e.currentCells().all { it.first in 0 until e.width })
    }

    @Test
    fun testHardDropLocksPieceAndScores() {
        val e = engine()
        val kind = e.piece
        e.hardDrop()
        val filled = e.board.sumOf { row -> row.count { it == kind.colorId } }
        assertEquals(4, filled)
        assertTrue(e.score >= 2 * (e.height - 4)) // минимум 2 очка за клетку падения
        assertFalse(e.gameOver)
    }

    @Test
    fun testSoftDropAddsOnePointTickAddsNone() {
        val e = engine()
        assertTrue(e.softDrop())
        assertEquals(1, e.score)
        assertTrue(e.tick())
        assertEquals(1, e.score)
    }

    @Test
    fun testFullLineIsClearedAndScored() {
        val e = engine()
        val bottom = e.height - 1
        for (x in 0 until 6) e.board[bottom][x] = 1 // нижняя строка заполнена слева
        e.board[bottom - 1][0] = 2                  // клетка выше — должна съехать вниз
        e.forcePiece(Tetromino.I, x = 6, y = bottom - 1, rot = 0) // горизонтальная палка занимает x=6..9 в нижней строке
        assertFalse(e.tick()) // ниже некуда — фигура фиксируется
        assertEquals(1, e.lines)
        assertEquals(100, e.score)
        assertEquals(2, e.board[bottom][0]) // клетка сверху опустилась на место очищенной строки
        assertTrue((1 until e.width).all { e.board[bottom][it] == 0 })
    }

    @Test
    fun testMultipleLinesScoreMoreAndLevelRises() {
        val e = engine()
        val bottom = e.height - 1
        // 4 нижние строки заполнены, кроме столбца x=9 — вертикальная палка закроет все сразу («тетрис»)
        for (y in bottom - 3..bottom) for (x in 0 until 9) e.board[y][x] = 1
        e.forcePiece(Tetromino.I, x = 7, y = bottom - 3 - 0, rot = 1)
        // вертикальная палка во 2-м повороте занимает столбец x+2 = 9
        assertEquals(setOf(9), e.currentCells().map { it.first }.toSet())
        e.hardDrop()
        assertEquals(4, e.lines)
        assertTrue(e.score >= 800)
        assertTrue(e.board.all { row -> row.all { it == 0 } })
    }

    @Test
    fun testLevelsSpeedUpTheGame() {
        val e = engine()
        assertEquals(800L, e.dropIntervalMs())
        val bottom = e.height - 1
        // 10 очищенных линий -> уровень 2: проверяем через повторные «тетрисы» и одиночные линии
        var cleared = 0
        while (cleared < 10) {
            for (x in 0 until 6) e.board[bottom][x] = 1
            e.forcePiece(Tetromino.I, x = 6, y = bottom - 1, rot = 0)
            e.tick()
            cleared++
        }
        assertEquals(10, e.lines)
        assertEquals(2, e.level)
        assertEquals(730L, e.dropIntervalMs())
    }

    @Test
    fun testGameOverWhenStackReachesTheTop() {
        val e = engine()
        assertFalse(e.gameOver)
        // верхние строки забиты, но с пробелом в крайнем столбце (иначе они были бы полными линиями и очистились)
        for (y in 0 until 3) for (x in 1 until e.width) e.board[y][x] = 3
        e.hardDrop()
        assertTrue(e.gameOver)
        assertFalse(e.moveLeft())
        assertFalse(e.rotate())
        assertFalse(e.tick())
    }

    @Test
    fun testResetStartsNewGame() {
        val e = engine()
        e.hardDrop()
        e.hardDrop()
        e.reset()
        assertEquals(0, e.score)
        assertEquals(0, e.lines)
        assertEquals(1, e.level)
        assertFalse(e.gameOver)
        assertTrue(e.board.all { row -> row.all { it == 0 } })
    }

    @Test
    fun testGhostIsBelowOrAtPieceAndNeverCollides() {
        val e = engine()
        val ghost = e.ghostCells()
        val cur = e.currentCells()
        assertEquals(cur.map { it.first }, ghost.map { it.first })
        assertTrue(ghost.maxOf { it.second } == e.height - 1) // на пустом поле призрак стоит на дне
        assertTrue(ghost.minOf { it.second } >= cur.minOf { it.second })
    }

    @Test
    fun testRandomPlayNeverCorruptsTheBoard() {
        // «обезьяна»: случайные действия; поле всегда остаётся в границах, фигура не пересекает стопку
        val e = engine(42)
        val rnd = Random(5)
        var steps = 0
        while (!e.gameOver && steps < 4000) {
            when (rnd.nextInt(6)) {
                0 -> e.moveLeft()
                1 -> e.moveRight()
                2 -> e.rotate()
                3 -> e.softDrop()
                4 -> e.tick()
                else -> if (rnd.nextInt(8) == 0) e.hardDrop()
            }
            if (!e.gameOver) {
                for ((x, y) in e.currentCells()) {
                    assertTrue(x in 0 until e.width && y in 0 until e.height)
                    assertEquals(0, e.board[y][x])
                }
            }
            steps++
        }
        assertTrue(e.board.all { row -> row.all { it in 0..7 } })
        assertTrue(e.score >= 0)
    }

    @Test
    fun testSnapshotIsAnIndependentCopy() {
        val e = engine()
        val before = e.snapshot()
        val cellsBefore = before.current
        assertTrue(e.moveLeft())
        val after = e.snapshot()
        // старый снимок не изменился, новый отличается — по этому Compose и понимает, что экран надо перерисовать
        assertEquals(cellsBefore, before.current)
        assertTrue(before.current != after.current)
        assertTrue(before !== after)

        e.hardDrop()
        val locked = e.snapshot()
        assertTrue(locked.board.any { row -> row.any { it != 0 } })
        // правка поля движка не просачивается в уже сделанный снимок
        val filledBefore = locked.board.sumOf { row -> row.count { it != 0 } }
        e.hardDrop()
        assertEquals(filledBefore, locked.board.sumOf { row -> row.count { it != 0 } })
        assertEquals(e.score, e.snapshot().score)
    }
}
