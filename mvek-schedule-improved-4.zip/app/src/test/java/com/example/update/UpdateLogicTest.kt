package com.example.update

import com.example.data.update.GithubReleaseParser
import com.example.data.update.MiniJson
import com.example.data.update.UpdateFormat
import com.example.data.update.UpdatePolicy
import com.example.data.update.VersionComparator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdateLogicTest {

    private val releaseJson = """
        {
          "url": "https://api.github.com/repos/ivan/mvek/releases/1",
          "tag_name": "v1.2",
          "name": "Версия 1.2",
          "draft": false,
          "prerelease": false,
          "body": "## Что нового\r\n- **Виджеты** на рабочий стол\r\n- Обновления \"через приложение\"\r\n\r\n\r\n\u041f\u0440\u0438\u0432\u0435\u0442",
          "assets": [
            {"name": "notes.txt", "size": 12, "browser_download_url": "https://github.com/ivan/mvek/releases/download/v1.2/notes.txt"},
            {"name": "mvek-debug.apk", "size": 9999999, "browser_download_url": "https://github.com/ivan/mvek/releases/download/v1.2/mvek-debug.apk"},
            {"name": "mvek-release.apk", "size": 6543210, "browser_download_url": "https://github.com/ivan/mvek/releases/download/v1.2/mvek-release.apk"}
          ]
        }
    """.trimIndent()

    @Test
    fun testMiniJsonParsesValuesAndEscapes() {
        val v = MiniJson.parse("""{"a": [1, 2.5, -3e2, true, false, null], "s": "q\"\\\/\n\t\u0416", "o": {}}""") as Map<*, *>
        val list = v["a"] as List<*>
        assertEquals(1.0, list[0])
        assertEquals(2.5, list[1])
        assertEquals(-300.0, list[2])
        assertEquals(true, list[3])
        assertEquals(false, list[4])
        assertEquals(null, list[5])
        assertEquals("q\"\\/\n\tЖ", v["s"])
        assertEquals(emptyMap<String, Any?>(), v["o"])
    }

    @Test
    fun testMiniJsonRejectsMalformedInput() {
        val bad = listOf("", "{", "[1,", "{\"a\" 1}", "{\"a\":1} x", "tru", "\"abc", "{\"a\":\"\\u12\"}", "[1 2]")
        for (text in bad) {
            var rejected = false
            try { MiniJson.parse(text) } catch (_: IllegalArgumentException) { rejected = true }
            assertTrue("должно быть отклонено: $text", rejected)
        }
        // защита от слишком глубокой вложенности
        var rejected = false
        try { MiniJson.parse("[".repeat(200) + "]".repeat(200)) } catch (_: IllegalArgumentException) { rejected = true }
        assertTrue(rejected)
    }

    @Test
    fun testGithubReleaseIsParsed() {
        val info = GithubReleaseParser.parse(releaseJson)!!
        assertEquals("1.2", info.versionName)
        assertEquals("v1.2", info.tag)
        // из нескольких APK выбирается тот, где в имени есть «release»
        assertEquals("https://github.com/ivan/mvek/releases/download/v1.2/mvek-release.apk", info.apkUrl)
        assertEquals(6543210L, info.sizeBytes)
        assertEquals("Что нового\n• Виджеты на рабочий стол\n• Обновления \"через приложение\"\n\nПривет", info.notes)
    }

    @Test
    fun testGithubReleaseEdgeCases() {
        // единственный APK берётся, даже если «release» в имени нет
        val single = """{"tag_name":"1.3","assets":[{"name":"app.APK","size":5,"browser_download_url":"https://github.com/a/b/app.APK"}]}"""
        assertEquals("1.3", GithubReleaseParser.parse(single)!!.versionName)

        assertEquals(null, GithubReleaseParser.parse("""{"tag_name":"v1","draft":true,"assets":[{"name":"a.apk","browser_download_url":"https://github.com/a"}]}"""))
        assertEquals(null, GithubReleaseParser.parse("""{"tag_name":"v1","prerelease":true,"assets":[{"name":"a.apk","browser_download_url":"https://github.com/a"}]}"""))
        assertEquals(null, GithubReleaseParser.parse("""{"tag_name":"v1","assets":[]}"""))
        assertEquals(null, GithubReleaseParser.parse("""{"assets":[{"name":"a.apk","browser_download_url":"https://github.com/a"}]}"""))
        assertEquals(null, GithubReleaseParser.parse("не json"))
        assertEquals(null, GithubReleaseParser.parse("[]"))
    }

    @Test
    fun testVersionComparison() {
        assertTrue(VersionComparator.isNewer("1.2", "1.1"))
        assertTrue(VersionComparator.isNewer("v1.10", "1.9"))
        assertTrue(VersionComparator.isNewer("1.2.1", "1.2"))
        assertTrue(VersionComparator.isNewer("2.0", "1.99.9"))
        assertFalse(VersionComparator.isNewer("1.2", "1.2"))
        assertFalse(VersionComparator.isNewer("v1.2", "1.2.0"))
        assertFalse(VersionComparator.isNewer("1.1", "1.2"))
        assertFalse(VersionComparator.isNewer("beta", "1.0"))
        assertFalse(VersionComparator.isNewer("", "1.0"))
        assertEquals("1.2", VersionComparator.normalize("V1.2"))
    }

    @Test
    fun testOnlyTrustedDownloadUrlsAreAllowed() {
        assertTrue(UpdatePolicy.isTrustedApkUrl("https://github.com/ivan/mvek/releases/download/v1/app.apk"))
        assertTrue(UpdatePolicy.isTrustedApkUrl("https://objects.githubusercontent.com/github-production-release-asset/1"))
        assertTrue(UpdatePolicy.isTrustedApkUrl("https://release-assets.githubusercontent.com/x"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("http://github.com/ivan/mvek/app.apk"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("https://github.com.evil.com/app.apk"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("https://evilgithub.com/app.apk"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("https://github.com@evil.com/app.apk"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("https://example.com/github.com/app.apk"))
        assertFalse(UpdatePolicy.isTrustedApkUrl("ftp://github.com/app.apk"))
    }

    @Test
    fun testFormatting() {
        assertEquals("6,2 МБ", UpdateFormat.size(6_543_210))
        assertEquals("", UpdateFormat.size(-1))
        assertEquals("", UpdateFormat.size(0))

        val long = "а".repeat(1000)
        val cut = UpdateFormat.notes(long, maxLength = 700)
        assertEquals(701, cut.length)
        assertTrue(cut.endsWith("…"))
        assertEquals("Текст", UpdateFormat.notes("  Текст \n"))
    }
}
