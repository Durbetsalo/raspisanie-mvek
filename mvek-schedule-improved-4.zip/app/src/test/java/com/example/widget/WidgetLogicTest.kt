package com.example.widget

import com.example.data.model.DaySchedule
import com.example.data.model.Lesson
import com.example.data.model.LessonTimeStatus
import com.example.data.model.WeekSchedule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class WidgetLogicTest {

    private fun lesson(
        n: Int,
        start: String,
        end: String,
        teacher: String = "Касимова Мария Сергеевна",
        room: String = "214"
    ) = Lesson(
        number = n,
        timeRange = "$start — $end",
        startTime = start,
        endTime = end,
        subject = "Предмет $n",
        teacher = teacher,
        auditorium = room
    )

    private fun day(dow: String, full: String, date: String, vararg lessons: Lesson) =
        DaySchedule(dow, full, date, false, lessons.toList())

    private fun week(vararg days: DaySchedule) = WeekSchedule("t", "", 0, days.toList())

    private fun cal(y: Int, m: Int, d: Int, h: Int, min: Int): Calendar =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d, h, min, 0) }

    // 16–21 ноября 2026 (вторник 17.11 — три пары) и следующая неделя
    private val thisWeek = week(
        day("Пн", "Понедельник", "16.11", lesson(1, "08:20", "09:50")),
        day(
            "Вт", "Вторник", "17.11",
            lesson(1, "08:20", "09:50"), lesson(2, "10:00", "11:30"), lesson(3, "11:40", "13:10")
        ),
        day("Ср", "Среда", "18.11", lesson(1, "08:20", "09:50")),
        day("Чт", "Четверг", "19.11"),
        day("Пт", "Пятница", "20.11", lesson(1, "08:20", "09:50")),
        day("Сб", "Суббота", "21.11")
    )
    private val nextWeek = week(
        day("Пн", "Понедельник", "23.11", lesson(1, "10:00", "11:30")),
        day("Вт", "Вторник", "24.11", lesson(1, "08:20", "09:50"))
    )

    @Test
    fun testNoGroupAndNoData() {
        assertEquals(WidgetContent.NoGroup, WidgetModelBuilder.build(null, thisWeek, nextWeek, cal(2026, 11, 17, 9, 0)))
        assertEquals(WidgetContent.NoGroup, WidgetModelBuilder.build("  ", thisWeek, nextWeek, cal(2026, 11, 17, 9, 0)))
        assertEquals(WidgetContent.NoData("ДБ-243/21"), WidgetModelBuilder.build("ДБ-243/21", null, null, cal(2026, 11, 17, 9, 0)))
    }

    @Test
    fun testTodayWithOngoingLesson() {
        val c = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 8, 30)) as WidgetContent.Day
        assertEquals("Сегодня", c.dayLabel)
        assertEquals("17 ноября", c.dateLabel)
        assertTrue(c.isToday)
        assertEquals(3, c.lessons.size)
        assertEquals(0, c.currentIndex)
        assertEquals(1, c.nextIndex)
        assertEquals(LessonTimeStatus.UPCOMING, c.lessons[2].status)
    }

    @Test
    fun testTodayBetweenLessons() {
        val c = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 9, 55)) as WidgetContent.Day
        assertEquals(-1, c.currentIndex)
        assertEquals(1, c.nextIndex)
        assertEquals(LessonTimeStatus.FINISHED, c.lessons[0].status)
    }

    @Test
    fun testAfterLastLessonShowsTomorrow() {
        val c = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 14, 0)) as WidgetContent.Day
        assertEquals("Завтра", c.dayLabel)
        assertEquals("Пары на сегодня закончились", c.note)
        assertFalse(c.isToday)
        assertEquals(1, c.lessons.size)
        assertEquals(LessonTimeStatus.UPCOMING, c.lessons[0].status)
    }

    @Test
    fun testSkipsEmptyDaysAndNamesTheDate() {
        val wed = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 18, 14, 0)) as WidgetContent.Day
        assertEquals("Пт, 20 ноября", wed.dayLabel)

        val thu = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 19, 10, 0)) as WidgetContent.Day
        assertEquals("Завтра", thu.dayLabel)
        assertEquals("Сегодня занятий нет", thu.note)
    }

    @Test
    fun testWeekendShowsMondayOfNextWeek() {
        // Воскресенье: понедельник — «Завтра»; сегодняшнего дня в расписании нет, поэтому заметки нет
        val sun = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 22, 12, 0)) as WidgetContent.Day
        assertEquals("Завтра", sun.dayLabel)
        assertEquals("23 ноября", sun.dateLabel)
        assertEquals(null, sun.note)

        // Суббота вечером (занятий нет): понедельник через два дня — подписываем датой
        val sat = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 21, 18, 0)) as WidgetContent.Day
        assertEquals("Пн, 23 ноября", sat.dayLabel)
        assertEquals("Сегодня занятий нет", sat.note)
    }

    @Test
    fun testStaleScheduleIsNoData() {
        val c = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 12, 14, 10, 0))
        assertEquals(WidgetContent.NoData("ДБ-243/21"), c)
    }

    @Test
    fun testYearWrap() {
        val w = week(
            day("Пн", "Понедельник", "28.12", lesson(1, "08:20", "09:50")),
            day("Ср", "Среда", "30.12", lesson(1, "08:20", "09:50")),
            day("Пт", "Пятница", "01.01", lesson(1, "08:20", "09:50"))
        )
        val c = WidgetModelBuilder.build("ДБ-243/21", w, null, cal(2026, 12, 30, 10, 0)) as WidgetContent.Day
        assertEquals("Пт, 1 января", c.dayLabel)
    }

    @Test
    fun testRefreshDelayFollowsLessonBoundaries() {
        val at940 = cal(2026, 11, 17, 9, 40)
        val c940 = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, at940)
        val d940 = WidgetModelBuilder.nextRefreshDelayMillis(c940, at940)
        // ближайшая граница — 09:51 (пара до 09:50 включительно)
        assertTrue(d940 in (11 * 60_000L)..(12 * 60_000L))

        val at800 = cal(2026, 11, 17, 8, 0)
        val c800 = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, at800)
        val d800 = WidgetModelBuilder.nextRefreshDelayMillis(c800, at800)
        assertTrue(d800 in (20 * 60_000L)..(21 * 60_000L)) // начало первой пары

        val at900 = cal(2026, 11, 17, 9, 0)
        val c900 = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, at900)
        assertEquals(30 * 60_000L, WidgetModelBuilder.nextRefreshDelayMillis(c900, at900)) // не реже, чем раз в 30 минут
    }

    @Test
    fun testTeacherAndDetailsTexts() {
        assertEquals("Касимова М. С.", WidgetTexts.shortTeacher("Касимова Мария Сергеевна"))
        assertEquals("Касимова М.С.", WidgetTexts.shortTeacher("Касимова М.С."))
        assertEquals("Иванов", WidgetTexts.shortTeacher("Иванов"))

        val item = WidgetLessonItem(1, "08:20", "09:50", "Предмет", "Касимова Мария Сергеевна", "214", LessonTimeStatus.UPCOMING, 500, 590)
        assertEquals("ауд. 214", WidgetTexts.details(item, WidthClass.NARROW))
        assertEquals("ауд. 214 · Касимова М. С.", WidgetTexts.details(item, WidthClass.MEDIUM))
        assertEquals("ауд. 214 · Касимова Мария Сергеевна", WidgetTexts.details(item, WidthClass.WIDE, fullTeacher = true))
        assertEquals("Касимова М. С.", WidgetTexts.details(item.copy(room = ""), WidthClass.NARROW))
        assertEquals("", WidgetTexts.details(item.copy(room = "", teacher = ""), WidthClass.WIDE))
    }

    @Test
    fun testHeroLabels() {
        val ongoing = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 8, 30)) as WidgetContent.Day
        assertEquals("СЕЙЧАС · ДО 09:50", WidgetTexts.heroLabel(ongoing, 0))
        assertEquals("ДАЛЕЕ · В 10:00", WidgetTexts.heroLabel(ongoing, 1))

        val early = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 7, 0)) as WidgetContent.Day
        assertEquals("ПЕРВАЯ ПАРА · В 08:20", WidgetTexts.heroLabel(early, 0))

        val between = WidgetModelBuilder.build("ДБ-243/21", thisWeek, nextWeek, cal(2026, 11, 17, 9, 55)) as WidgetContent.Day
        assertEquals("ДАЛЕЕ · В 10:00", WidgetTexts.heroLabel(between, 1))
    }

    private fun dayWithLessons(count: Int, currentIndex: Int): WidgetContent.Day {
        val items = (0 until count).map {
            WidgetLessonItem(
                it + 1, "08:00", "09:00", "Предмет", "", "1",
                if (it == currentIndex) LessonTimeStatus.ONGOING else if (it < currentIndex) LessonTimeStatus.FINISHED else LessonTimeStatus.UPCOMING,
                480, 540
            )
        }
        return WidgetContent.Day(
            "Г", "Сегодня", "17 ноября", null, true, items, currentIndex,
            items.indexOfFirst { it.status == LessonTimeStatus.UPCOMING }
        )
    }

    @Test
    fun testWidthClasses() {
        assertEquals(WidthClass.NARROW, WidgetLayoutPlanner.widthClassOf(110))
        assertEquals(WidthClass.NARROW, WidgetLayoutPlanner.widthClassOf(169))
        assertEquals(WidthClass.MEDIUM, WidgetLayoutPlanner.widthClassOf(170))
        assertEquals(WidthClass.MEDIUM, WidgetLayoutPlanner.widthClassOf(259))
        assertEquals(WidthClass.WIDE, WidgetLayoutPlanner.widthClassOf(260))
    }

    @Test
    fun testCompactWidgetShowsSingleRow() {
        val day = dayWithLessons(4, 1)
        val tiny = WidgetLayoutPlanner.plan(WidgetMode.DAY, day, 180, 50)
        assertFalse(tiny.showHeader)
        assertEquals(listOf(1), tiny.rowIndices)
        assertFalse(tiny.showDetails)

        val low = WidgetLayoutPlanner.plan(WidgetMode.NEXT, day, 180, 80)
        assertFalse(low.showHeader)
        assertEquals(listOf(1), low.rowIndices)
        assertTrue(low.showDetails)
        assertEquals(null, low.heroIndex)
    }

    @Test
    fun testNextModeSmallestSquareShowsHero() {
        val day = dayWithLessons(3, 0)
        val p = WidgetLayoutPlanner.plan(WidgetMode.NEXT, day, 110, 110)
        assertEquals(0, p.heroIndex)
        assertTrue(p.rowIndices.isEmpty())
        assertEquals(2, p.hiddenCount)
        assertFalse(p.showMore)
    }

    @Test
    fun testNextModeWithMoreSpaceListsUpcoming() {
        val day = dayWithLessons(3, 0)
        val p = WidgetLayoutPlanner.plan(WidgetMode.NEXT, day, 250, 180)
        assertEquals(0, p.heroIndex)
        assertEquals(listOf(1), p.rowIndices)
        assertEquals(1, p.hiddenCount)
        assertTrue(p.showMore)

        val tall = WidgetLayoutPlanner.plan(WidgetMode.NEXT, day, 250, 300)
        assertEquals(listOf(1, 2), tall.rowIndices)
        assertEquals(0, tall.hiddenCount)
        assertFalse(tall.showMore)
    }

    @Test
    fun testDayModeFitsAllLessonsWhenTallEnough() {
        val p = WidgetLayoutPlanner.plan(WidgetMode.DAY, dayWithLessons(3, 0), 250, 180)
        assertEquals(listOf(0, 1, 2), p.rowIndices)
        assertEquals(0, p.hiddenCount)
        assertEquals(null, p.heroIndex)
    }

    @Test
    fun testDayModeWindowStartsAtCurrentLesson() {
        val mid = WidgetLayoutPlanner.plan(WidgetMode.DAY, dayWithLessons(6, 3), 250, 180)
        assertEquals(listOf(3, 4), mid.rowIndices)
        assertEquals(4, mid.hiddenCount)
        assertTrue(mid.showMore)

        // у последней пары окно подтягивает предыдущие, чтобы не оставлять пустоту
        val last = WidgetLayoutPlanner.plan(WidgetMode.DAY, dayWithLessons(6, 5), 250, 180)
        assertEquals(listOf(4, 5), last.rowIndices)
    }

    @Test
    fun testLargeFontReducesRows() {
        val normal = WidgetLayoutPlanner.plan(WidgetMode.DAY, dayWithLessons(8, 0), 250, 300, 1f)
        val big = WidgetLayoutPlanner.plan(WidgetMode.DAY, dayWithLessons(8, 0), 250, 300, 1.5f)
        assertTrue(big.rowIndices.size < normal.rowIndices.size)
    }
}
