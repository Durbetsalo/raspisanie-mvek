package com.example

import com.example.data.model.DaySchedule
import com.example.data.model.Group
import com.example.data.model.Lesson
import com.example.data.model.LessonTimeStatus
import com.example.data.model.LessonType
import com.example.data.model.WeekSchedule
import com.example.data.parser.MvekHtmlParser
import com.example.ui.viewmodel.withAccurateTodayFlags
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ExampleUnitTest {

    @Test
    fun testParseTimeToMinutes() {
        assertEquals(500, Lesson.parseTimeToMinutes("08:20"))
        assertEquals(600, Lesson.parseTimeToMinutes("10:00"))
        assertEquals(700, Lesson.parseTimeToMinutes("11:40"))
        assertEquals(null, Lesson.parseTimeToMinutes("invalid"))
    }

    @Test
    fun testLessonTimeStatus() {
        val lesson = Lesson(
            number = 1,
            timeRange = "08:20 — 09:50",
            startTime = "08:20",
            endTime = "09:50",
            subject = "Тестирование ПО"
        )

        // 8:00 AM (480 min) -> UPCOMING
        assertEquals(LessonTimeStatus.UPCOMING, lesson.getTimeStatus(480))

        // 8:30 AM (510 min) -> ONGOING
        assertEquals(LessonTimeStatus.ONGOING, lesson.getTimeStatus(510))

        // 10:00 AM (600 min) -> FINISHED
        assertEquals(LessonTimeStatus.FINISHED, lesson.getTimeStatus(600))
    }

    @Test
    fun testDetectLessonType() {
        assertEquals(LessonType.LECTURE, Lesson.detectLessonType("Высшая математика Лекции", ""))
        assertEquals(LessonType.PRACTICE, Lesson.detectLessonType("Организация кредитной работы", "Практическое занятие 1"))
        assertEquals(LessonType.LAB, Lesson.detectLessonType("Информационные технологии", "Лабораторная работа"))
        assertEquals(LessonType.EXAM, Lesson.detectLessonType("Экзамен по философии", ""))
        assertEquals(LessonType.CREDIT, Lesson.detectLessonType("Дифференцированный зачет", ""))
    }

    @Test
    fun testHtmlParserGroups() {
        val sampleHtml = """
            <div id="groupTilesContainer">
                <a href="/schedule/table?group=%D0%94%D0%91-243%2F21">
                    <div class="group-tile specialty-db">ДБ-243/21</div>
                </a>
                <a href="/schedule/table?group=ДИС-243/21">
                    <div class="group-tile specialty-dis">ДИС-243/21</div>
                </a>
            </div>
        """.trimIndent()

        val groups = MvekHtmlParser.parseGroups(sampleHtml)
        assertEquals(2, groups.size)
        assertEquals("ДБ-243/21", groups[0].name)
        assertEquals("ДИС-243/21", groups[1].name)
    }

    @Test
    fun testHtmlParserTeachers() {
        val sampleHtml = """
            <div id="teacherTilesContainer">
                <a href="/schedule/table?teacher=%D0%9A%D0%B0%D1%81%D0%B8%D0%BC%D0%BE%D0%B2%D0%B0&amp;teacher_id=23238">
                    <div class="teacher-tile">Касимова Мария Сергеевна</div>
                </a>
            </div>
        """.trimIndent()

        val teachers = MvekHtmlParser.parseTeachers(sampleHtml)
        assertEquals(1, teachers.size)
        assertEquals("Касимова Мария Сергеевна", teachers[0].name)
        assertEquals("23238", teachers[0].id)
    }

    @Test
    fun testHtmlParserMobileSchedule() {
        val sampleHtml = """
            <h1>Расписание для группы ДБ-243/21</h1>
            <div class="schedule-nav">
                <a href="#">&lt;</a> 09 &mdash; 15 ноября <a href="#">&gt;</a>
            </div>
            <div id="schedule_mob">
                <div class="dates">
                    <div class="date_and_wday">
                        <div class="day_of_the_week">Пн</div>
                        <label class="single_date">09.11</label>
                    </div>
                </div>
                <div class="lessons_wrap" id="09.11">
                    <div class="lesson_block">
                        <b class="lesson_title">1 пара, Ауд. 214</b>
                        <div class="lesson_info">
                            <table id="lesson_table">
                                <tr id="lesson_tr">
                                    <th id="lesson_th">Время</th>
                                    <td id="lesson_td">08:20 &mdash; 09:50</td>
                                </tr>
                                <tr id="lesson_tr">
                                    <th id="lesson_th">Предмет</th>
                                    <td class="lesson_name" id="lesson_td">Организация кредитной работы</td>
                                </tr>
                            </table>
                        </div>
                        <div class="teacher">Касимова Мария Сергеевна</div>
                    </div>
                </div>
            </div>
            <script></script>
        """.trimIndent()

        val schedule = MvekHtmlParser.parseSchedule(sampleHtml, 0)
        assertEquals("Расписание для группы ДБ-243/21", schedule.title)
        assertEquals("09 — 15 ноября", schedule.weekRange)
        assertEquals(1, schedule.days.size)

        val day = schedule.days[0]
        assertEquals("Пн", day.dayOfWeek)
        assertEquals("09.11", day.dateString)
        assertEquals(1, day.lessons.size)

        val lesson = day.lessons[0]
        assertEquals(1, lesson.number)
        assertEquals("08:20", lesson.startTime)
        assertEquals("09:50", lesson.endTime)
        assertEquals("214", lesson.auditorium)
        assertEquals("Касимова Мария Сергеевна", lesson.teacher)
        assertEquals("Организация кредитной работы", lesson.subject)
    }

    @Test
    fun testWithAccurateTodayFlagsOnSundayClearsAllTodayFlags() {
        val sampleWeek = WeekSchedule(
            title = "ДБ-243/21",
            weekRange = "09 — 14 ноября",
            currentSkip = 0,
            days = listOf(
                DaySchedule("Пн", "Понедельник", "09.11", isToday = true, lessons = emptyList()),
                DaySchedule("Сб", "Суббота", "14.11", isToday = true, lessons = emptyList())
            )
        )
        val sundayCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 15, 12, 0, 0) // Sunday 15.11.2026
        }
        assertEquals(Calendar.SUNDAY, sundayCal.get(Calendar.DAY_OF_WEEK))

        val normalizedReal = sampleWeek.withAccurateTodayFlags(skip = 0, now = sundayCal)
        assertTrue(normalizedReal.days.none { it.isToday })
    }

    @Test
    fun testWithAccurateTodayFlagsOnWeekdayAndNextWeek() {
        val sampleWeek = WeekSchedule(
            title = "ДБ-243/21",
            weekRange = "09 — 14 ноября",
            currentSkip = 0,
            days = listOf(
                DaySchedule("Пн", "Понедельник", "09.11", isToday = true, lessons = emptyList()),
                DaySchedule("Ср", "Среда", "11.11", isToday = false, lessons = emptyList()),
                DaySchedule("Сб", "Суббота", "14.11", isToday = false, lessons = emptyList())
            )
        )
        val wednesdayCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 11, 10, 0, 0) // Wednesday 11.11.2026
        }

        val normalizedCurrent = sampleWeek.withAccurateTodayFlags(skip = 0, now = wednesdayCal)
        assertFalse(normalizedCurrent.days[0].isToday)
        assertTrue(normalizedCurrent.days[1].isToday)
        assertFalse(normalizedCurrent.days[2].isToday)

        val normalizedNext = sampleWeek.withAccurateTodayFlags(skip = 1, now = wednesdayCal)
        assertTrue(normalizedNext.days.none { it.isToday })

        // Stale cached week from previous week should not falsely mark today
        val nextMondayCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 16, 9, 0, 0) // Monday 16.11.2026
        }
        val normalizedStale = sampleWeek.withAccurateTodayFlags(skip = 0, now = nextMondayCal)
        assertTrue(normalizedStale.days.none { it.isToday })
    }

    @Test
    fun testGroupCourseIsComputedFromAdmissionYear() {
        // Ноябрь 2026: учебный год уже начался (сентябрь), поэтому набор 2026 -> 1 курс
        assertEquals(1, Group.courseFromName("ДНГ-261/2", year = 2026, month = 11))
        assertEquals(2, Group.courseFromName("ДИС-252.2/21", year = 2026, month = 11))
        assertEquals(3, Group.courseFromName("ДБ-243/21", year = 2026, month = 11))
        assertEquals(4, Group.courseFromName("ДГД-232/2", year = 2026, month = 11))

        // До сентября курс ещё прошлый, с сентября — следующий
        assertEquals(1, Group.courseFromName("ДИС-252.2/21", year = 2026, month = 3))
        assertEquals(3, Group.courseFromName("ДИС-252.2/21", year = 2027, month = 9))

        // Старый формат с полным годом и группы без цифр
        assertEquals(4, Group.courseFromName("БД-О-11-2021", year = 2026, month = 11))
        assertEquals(1, Group.courseFromName("Тест", year = 2026, month = 11))
        assertEquals(2025, Group.admissionYearOf("ДИС-252.2/21"))
    }

    @Test
    fun testHtmlEntitiesAreDecodedCorrectly() {
        val html = """
            <h1>Расписание для группы ДБ-243/21</h1>
            <div class="date_and_wday"><div class="day_of_the_week">Пн</div><label class="single_date">09.11</label></div>
            <div class="lessons_wrap" id="09.11">
                <div class="lesson_block">
                    <b class="lesson_title">1 пара, Ауд. 214</b>
                    <table>
                        <tr><th>Время</th><td>08:20 &mdash; 09:50</td></tr>
                        <tr><th>Предмет</th><td>&laquo;Основы&raquo; &#8212; Q&amp;A &#x41;&nbsp;B &amp;lt;b&amp;gt;</td></tr>
                    </table>
                    <div class="teacher">Касимова Мария Сергеевна</div>
                </div>
            </div>
            <script></script>
        """.trimIndent()

        val lesson = MvekHtmlParser.parseSchedule(html, 0).days[0].lessons[0]
        // Кавычки-«ёлочки», числовые сущности и &nbsp; декодируются; «&amp;lt;» не превращается в тег
        assertEquals("«Основы» — Q&A A B &lt;b&gt;", lesson.subject)
    }

    @Test
    fun testParsedGroupsGetCourseAutomatically() {
        val groups = MvekHtmlParser.parseGroups(
            """<a href="/schedule/table?group=ДИС-243/21"><div class="group-tile specialty-dis">ДИС-243/21</div></a>"""
        )
        assertEquals(1, groups.size)
        assertTrue(groups[0].course in 1..4)
    }
}
